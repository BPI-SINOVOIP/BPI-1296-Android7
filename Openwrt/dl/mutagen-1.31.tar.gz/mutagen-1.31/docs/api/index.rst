API
===

.. toctree::

    base
    aac
    aiff
    ape
    asf
    flac
    id3
    monkeysaudio
    mp3
    mp4
    musepack
    ogg
    oggflac
    oggopus
    oggspeex
    oggtheora
    oggvorbis
    optimfrog
    trueaudio
    vcomment
    wavpack

