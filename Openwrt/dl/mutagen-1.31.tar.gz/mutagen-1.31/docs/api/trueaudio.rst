TrueAudio
=========

.. automodule:: mutagen.trueaudio

.. autoclass:: mutagen.trueaudio.TrueAudio(filename, ID3=None)
    :show-inheritance:
    :members:

.. autoclass:: mutagen.trueaudio.TrueAudioInfo()
    :members:

.. autoclass:: mutagen.trueaudio.EasyTrueAudio(filename, ID3=None)
    :show-inheritance:
    :members:
    :exclude-members: ID3
