OptimFROG
=========

.. automodule:: mutagen.optimfrog

.. autoclass:: mutagen.optimfrog.OptimFROG
    :show-inheritance:
    :members:

.. autoclass:: mutagen.optimfrog.OptimFROGInfo
    :members:
