Modification of or tampering with the product, including but not limited to any Open Source Software, is solely at Your own risk. Western Digital is not responsible for any such modification or tampering. Western Digital will not support any product in which You have or have attempted to modify the software or hardware supplied by Western Digital.

Samba Build Instructions:

Prepare build environment
------------------------------------------------------
- download toolchain from Linaro site https://launchpad.net/linaro-toolchain-binaries/trunk/2013.01/+download/gcc-linaro-arm-linux-gnueabihf-4.7-2013.01-20130125_linux.tar.bz2.
- untar provided toolchain to a directory.

Build samba
------------------------------------------------------
- make TOOLCHAIN_DIR=<path to toolchain root>
- after successful completion, compiled binaries are available under bin folder

Install samba
------------------------------------------------------
- determine location of existing binaries on device.  e.g., which nmbd
- copy compiled binaries to location on device.  e.g., /usr/sbin; /usr/bin