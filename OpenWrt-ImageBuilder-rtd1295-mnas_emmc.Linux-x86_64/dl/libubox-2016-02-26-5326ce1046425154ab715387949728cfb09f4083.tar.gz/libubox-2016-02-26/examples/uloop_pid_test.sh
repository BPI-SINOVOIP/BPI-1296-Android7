#!/bin/sh

echo $0 $* 
echo Environment:
env

sleep 2

echo "stopping child"

exit 5
