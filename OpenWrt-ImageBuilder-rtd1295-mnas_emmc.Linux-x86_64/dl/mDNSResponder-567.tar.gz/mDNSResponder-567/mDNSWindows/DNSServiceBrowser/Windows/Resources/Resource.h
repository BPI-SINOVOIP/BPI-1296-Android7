//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Application.rc
//
#define IDS_ABOUTBOX                    101
#define IDS_CHOOSER_DOMAIN_COLUMN_NAME  102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDS_CHOOSER_SERVICE_COLUMN_NAME 104
#define IDS_CHOOSER_SERVICE_COLUMN_TYPE 104
#define IDS_CHOOSER_CHOOSER_NAME_COLUMN_NAME 105
#define IDS_CHOOSER_CHOOSER_IP_COLUMN_NAME 106
#define IDS_CHOOSER_SERVICE_COLUMN_DESC 107
#define IDC_NAME_TEXT2                  124
#define IDC_INFO_NAME_TEXT              124
#define IDC_DESCRIPTION_TEXT2           125
#define IDC_INFO_TEXT_TEXT              125
#define IDC_IP_TEXT2                    126
#define IDC_INFO_IP_TEXT                126
#define IDC_IP_TEXT3                    127
#define IDC_INFO_INTERFACE_TEXT         127
#define IDR_MAIN_ICON                   128
#define IDC_INFO_INTERFACE_TEXT2        128
#define IDC_INFO_HOST_NAME_TEXT         128
#define IDR_CHOOSER_DIALOG_MENU         136
#define IDD_CHOOSER_DIALOG              143
#define IDD_ABOUT_DIALOG                144
#define IDD_LOGIN                       145
#define IDR_CHOOSER_DIALOG_MENU_ACCELERATORS 146
#define IDC_CHOOSER_LIST                1000
#define IDC_SERVICE_LIST2               1001
#define IDC_SERVICE_LIST                1001
#define IDC_SERVICE_LIST3               1002
#define IDC_DOMAIN_LIST                 1002
#define IDC_ABOUT_APP_NAME_TEXT         1105
#define IDC_ABOUT_APP_VERSION_TEXT      1106
#define IDC_ABOUT_COPYRIGHT_TEXT        1107
#define IDC_ABOUT_APP_ICON              1108
#define IDC_LOGIN_USERNAME_TEXT         1182
#define IDC_EDIT2                       1183
#define IDC_LOGIN_PASSWORD_TEXT         1183
#define ID_FILE_EXIT                    32771
#define ID_HELP_ABOUT                   32806

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        164
#define _APS_NEXT_COMMAND_VALUE         32809
#define _APS_NEXT_CONTROL_VALUE         1185
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
