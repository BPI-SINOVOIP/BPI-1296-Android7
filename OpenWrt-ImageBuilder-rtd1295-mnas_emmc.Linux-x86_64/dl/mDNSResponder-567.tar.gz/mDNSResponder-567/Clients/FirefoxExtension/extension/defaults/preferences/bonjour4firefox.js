// See http://kb.mozillazine.org/Localize_extension_descriptions
pref("extensions.bonjour4firefox@apple.com.description", "chrome://bonjour4firefox/locale/bonjour4firefox.properties");
