/*
 * Copyright (C) 2014, Sebastian Dröge <sebastian@centricular.com>
 * Copyright (C) 2014, LG Electronics, Inc. <jun.ji@lge.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation
 * version 2.1 of the License.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <gst/gst.h>
#include <string.h>
#include <stdlib.h>

#include "gstomxwmaprodec.h"
#include "gstomxaudiodec.h"

#define ASF_GUID_LEN  sizeof(ASF_GUID)

typedef struct _ASF_GUID {          // size is 16 bytes
    uint   Data1;
    unsigned short  Data2;
    unsigned short  Data3;
    unsigned char   Data4[8];
} ASF_GUID;
#define DEFINE_ASF_GUID(name, l, w1, w2, b1, b2, b3, b4, b5, b6, b7, b8) \
        const ASF_GUID name = { l, w1, w2, { b1, b2,  b3,  b4,  b5,  b6,  b7,  b8 } }
DEFINE_ASF_GUID(ASF_AUDIO_MEDIA, 0xF8699E40, 0x5B4D, 0x11CF, 0xA8, 0xFD, 0x00, 0x80, 0x5F, 0x5C, 0x44, 0x2B);

typedef struct
{
  short int wFormatTag;
  short int nChannels;
  unsigned int nSamplesPerSec;
  unsigned int nAvgBytesPerSec;
  short int nBlockAlign;
  short int wBitsPerSample;
  short int specificDataSize;
} WAVEFORMATEX;

GST_DEBUG_CATEGORY_STATIC (gst_omx_wmapro_dec_debug_category);
#define GST_CAT_DEFAULT gst_omx_wmapro_dec_debug_category

/* prototypes */
static gboolean gst_omx_wmapro_dec_set_format (GstOMXAudioDec * dec,
    GstOMXPort * port, GstCaps * caps);
static gboolean gst_omx_wmapro_dec_is_format_change (GstOMXAudioDec * dec,
    GstOMXPort * port, GstCaps * caps);
static gint gst_omx_wmapro_dec_get_samples_per_frame (GstOMXAudioDec * dec,
    GstOMXPort * port);
static gboolean gst_omx_wmapro_dec_get_channel_positions (GstOMXAudioDec * dec,
    GstOMXPort * port, GstAudioChannelPosition position[OMX_AUDIO_MAXCHANNELS]);

/* class initialization */

#define DEBUG_INIT \
  GST_DEBUG_CATEGORY_INIT (gst_omx_wmapro_dec_debug_category, "omxwmaprodec", 0, \
      "debug category for gst-omx wmapro audio decoder");

G_DEFINE_TYPE_WITH_CODE (GstOMXWMAPRODec, gst_omx_wmapro_dec,
    GST_TYPE_OMX_AUDIO_DEC, DEBUG_INIT);

static void
gst_omx_wmapro_dec_class_init (GstOMXWMAPRODecClass * klass)
{
  GstElementClass *element_class = GST_ELEMENT_CLASS (klass);
  GstOMXAudioDecClass *audiodec_class = GST_OMX_AUDIO_DEC_CLASS (klass);

  audiodec_class->set_format = GST_DEBUG_FUNCPTR (gst_omx_wmapro_dec_set_format);
  audiodec_class->is_format_change =
      GST_DEBUG_FUNCPTR (gst_omx_wmapro_dec_is_format_change);
  audiodec_class->get_samples_per_frame =
      GST_DEBUG_FUNCPTR (gst_omx_wmapro_dec_get_samples_per_frame);
  audiodec_class->get_channel_positions =
      GST_DEBUG_FUNCPTR (gst_omx_wmapro_dec_get_channel_positions);

  audiodec_class->cdata.default_sink_template_caps ="audio/x-wma, " "wmaversion=(int)3, " "rate=(int)[8000,96000], " "channels=(int)[1,6]";

  gst_element_class_set_static_metadata (element_class,
      "OpenMAX wmapro Audio Decoder",
      "Codec/Decoder/Audio",
      "Decode wmapro audio streams",
      "Sebastian Dröge <sebastian@centricular.com>");

  gst_omx_set_default_role (&audiodec_class->cdata, "audio_decoder.wmapro");
}

static void
gst_omx_wmapro_dec_init (GstOMXWMAPRODec * self)
{
  self->spf = 2048;
}

static gboolean
gst_omx_wmapro_dec_set_format (GstOMXAudioDec * dec, GstOMXPort * port,
    GstCaps * caps)
{
  GstOMXWMAPRODec *self = GST_OMX_WMAPRO_DEC (dec);
  OMX_PARAM_PORTDEFINITIONTYPE port_def;
  OMX_AUDIO_PARAM_WMAPROTYPE wmapro_param;
  WAVEFORMATEX wma_header;
  OMX_ERRORTYPE err;
  GstStructure *s;
  gint rate, channels,wmaversion;
  gst_omx_port_get_port_definition (port, &port_def);
  port_def.format.audio.eEncoding = OMX_AUDIO_CodingWMAPRO;        /* not tested for wmapro */
  err = gst_omx_port_update_port_definition (port, &port_def);
  if (err != OMX_ErrorNone) {
    GST_ERROR_OBJECT (self,
        "Failed to set wmapro format on component: %s (0x%08x)",
        gst_omx_error_to_string (err), err);
    return FALSE;
  }

  GST_OMX_INIT_STRUCT (&wmapro_param);
  wmapro_param.nPortIndex = port->index;

  err =
      gst_omx_component_get_parameter (dec->dec, OMX_IndexParamAudioWmaPro,
      &wmapro_param);
  if (err != OMX_ErrorNone) {
    GST_ERROR_OBJECT (self,
        "Failed to get wmapro parameters from component: %s (0x%08x)",
        gst_omx_error_to_string (err), err);
    return FALSE;
  }

  s = gst_caps_get_structure (caps, 0);

  if (!gst_structure_get_int (s, "wmaversion", &wmaversion)) {
    GST_ERROR_OBJECT (self, "Incomplete caps");
    return FALSE;
  }
    if(!gst_structure_get_int (s, "rate", &rate)){
   GST_ERROR_OBJECT (self, "[realtek] gstomxaacdec don't got rate info from Caps");
  rate = 48000;
  }

  if(!gst_structure_get_int (s, "channels", &channels)){
        GST_ERROR_OBJECT (self, "[realtek] gstomxaacdec don't got channels info from Caps");
  channels = 6;
  }
 
  wmapro_param.nChannels = channels;
  wmapro_param.nSamplingRate = rate;   
  wmapro_param.nBitRate = 0;
  
  err =
      gst_omx_component_set_parameter (dec->dec, OMX_IndexParamAudioWmaPro,
      &wmapro_param);
  if (err != OMX_ErrorNone) {
    GST_ERROR_OBJECT (self, "Error setting wmapro parameters: %s (0x%08x)",
        gst_omx_error_to_string (err), err);
    return FALSE;
  }
  
   if(dec->raw_out == TRUE){
        gst_omx_component_set_parameter (dec->dec, OMX_realtek_android_index_configureAudioTunnelMode, &dec->hw_avsync_fd);
  }
{
    const GValue *codec_data;
    GstBuffer *buffer;
    GstBuffer *final;
    GstMapInfo map, map2 ;
    char *WMAPrivateData = NULL;
    codec_data = gst_structure_get_value (s, "codec_data");
    if (codec_data) {
      int i, audio_mCodecPrivateLen;
      int data_size, depth, bitrate, block_align;
      
      //gst_structure_get_int (s, "channels", &channels);
      //gst_structure_get_int (s, "rate", &rate);
      //gst_structure_get_int (s, "wmaversion", &wmaversion);
      gst_structure_get_int (s, "depth", &depth);
      gst_structure_get_int (s, "bitrate", &bitrate);
      gst_structure_get_int (s, "block_align", &block_align);
      buffer = gst_value_get_buffer (codec_data);
      data_size = gst_buffer_get_size (buffer);
       gst_buffer_map (buffer, &map2, GST_MAP_WRITE);
      memset (&wma_header, 0, sizeof (WAVEFORMATEX));
      switch (wmaversion) {
        case 1:
          wma_header.wFormatTag = 0x160;
          break;
        case 2:
          wma_header.wFormatTag = 0x161;
          break;
        case 3:
          wma_header.wFormatTag = 0x162;
          break;
        case 4:
          wma_header.wFormatTag = 0x163;
          break;
        default:
          return GST_FLOW_ERROR;
      }
      wma_header.nChannels = channels;
      wma_header.nSamplesPerSec = rate;
      wma_header.nAvgBytesPerSec = bitrate / 8;
      wma_header.nBlockAlign = block_align;
      wma_header.wBitsPerSample = depth;
      wma_header.specificDataSize = data_size;

      audio_mCodecPrivateLen = ASF_GUID_LEN + 18 + wma_header.specificDataSize;    
      WMAPrivateData = (char *)malloc(audio_mCodecPrivateLen);
      memset((void *)&WMAPrivateData[0], 0, audio_mCodecPrivateLen);
      memcpy(&WMAPrivateData[0], &ASF_AUDIO_MEDIA, ASF_GUID_LEN);
      memcpy(&WMAPrivateData[ASF_GUID_LEN], (unsigned char*)&(wma_header), 18);
      for(i=0;i<wma_header.specificDataSize;i++)
        WMAPrivateData[ASF_GUID_LEN + 18 + i]=map2.data[i];
      gst_buffer_unmap (buffer, &map2);
      //memcpy(&WMAPrivateData[ASF_GUID_LEN + 18], (unsigned char*)&map2.data, wma_header.specificDataSize);
       final = gst_buffer_new_and_alloc (audio_mCodecPrivateLen);
      // GstMapInfo map = GST_MAP_INFO_INIT;
        gst_buffer_map (final, &map, GST_MAP_WRITE);
        memcpy (map.data,WMAPrivateData,audio_mCodecPrivateLen);

        gst_buffer_unmap (final, &map);

        dec->codec_data=final;
        gst_buffer_ref (final);

    }
  }
  return TRUE;
}

static gboolean
gst_omx_wmapro_dec_is_format_change (GstOMXAudioDec * dec, GstOMXPort * port,
    GstCaps * caps)
{
  GstOMXWMAPRODec *self = GST_OMX_WMAPRO_DEC (dec);
  OMX_AUDIO_PARAM_WMAPROTYPE wmapro_param;
  OMX_ERRORTYPE err;
  GstStructure *s;
  gint rate, channels;

  GST_OMX_INIT_STRUCT (&wmapro_param);
  wmapro_param.nPortIndex = port->index;

  err =
      gst_omx_component_get_parameter (dec->dec, OMX_IndexParamAudioWmaPro,
      &wmapro_param);
  if (err != OMX_ErrorNone) {
    GST_ERROR_OBJECT (self,
        "Failed to get wmapro parameters from component: %s (0x%08x)",
        gst_omx_error_to_string (err), err);
    return FALSE;
  }

  s = gst_caps_get_structure (caps, 0);

  if (!gst_structure_get_int (s, "rate", &rate) ||
      !gst_structure_get_int (s, "channels", &channels)) {
    GST_ERROR_OBJECT (self, "Incomplete caps");
    return FALSE;
  }
  if (wmapro_param.nSamplingRate != rate)
    return TRUE;

  if (wmapro_param.nChannels != channels)
    return TRUE;

  return FALSE;
}

static gint
gst_omx_wmapro_dec_get_samples_per_frame (GstOMXAudioDec * dec, GstOMXPort * port)
{
  return GST_OMX_WMAPRO_DEC (dec)->spf;
}

static gboolean
gst_omx_wmapro_dec_get_channel_positions (GstOMXAudioDec * dec,
    GstOMXPort * port, GstAudioChannelPosition position[OMX_AUDIO_MAXCHANNELS])
{
  OMX_AUDIO_PARAM_PCMMODETYPE pcm_param;
  OMX_ERRORTYPE err;

  GST_OMX_INIT_STRUCT (&pcm_param);
  pcm_param.nPortIndex = port->index;
  err =
      gst_omx_component_get_parameter (dec->dec, OMX_IndexParamAudioPcm,
      &pcm_param);
  if (err != OMX_ErrorNone) {
    GST_ERROR_OBJECT (dec, "Failed to get PCM parameters: %s (0x%08x)",
        gst_omx_error_to_string (err), err);
    return FALSE;
  }


    /* FIXME: Rather arbitrary values here, based on what we do in gstfaac.c */
  switch (pcm_param.nChannels) {
    case 1:
      position[0] = GST_AUDIO_CHANNEL_POSITION_MONO;
      break;
    case 2:
      position[0] = GST_AUDIO_CHANNEL_POSITION_FRONT_LEFT;
      position[1] = GST_AUDIO_CHANNEL_POSITION_FRONT_RIGHT;
      break;
    case 3:
      position[0] = GST_AUDIO_CHANNEL_POSITION_FRONT_CENTER;
      position[1] = GST_AUDIO_CHANNEL_POSITION_FRONT_LEFT;
      position[2] = GST_AUDIO_CHANNEL_POSITION_FRONT_RIGHT;
      break;
    case 4:
      position[0] = GST_AUDIO_CHANNEL_POSITION_FRONT_CENTER;
      position[1] = GST_AUDIO_CHANNEL_POSITION_FRONT_LEFT;
      position[2] = GST_AUDIO_CHANNEL_POSITION_FRONT_RIGHT;
      position[3] = GST_AUDIO_CHANNEL_POSITION_REAR_CENTER;
      break;
    case 5:
      position[0] = GST_AUDIO_CHANNEL_POSITION_FRONT_CENTER;
      position[1] = GST_AUDIO_CHANNEL_POSITION_FRONT_LEFT;
      position[2] = GST_AUDIO_CHANNEL_POSITION_FRONT_RIGHT;
      position[3] = GST_AUDIO_CHANNEL_POSITION_REAR_LEFT;
      position[4] = GST_AUDIO_CHANNEL_POSITION_REAR_RIGHT;
      break;
    case 6:
      position[0] = GST_AUDIO_CHANNEL_POSITION_FRONT_CENTER;
      position[1] = GST_AUDIO_CHANNEL_POSITION_FRONT_LEFT;
      position[2] = GST_AUDIO_CHANNEL_POSITION_FRONT_RIGHT;
      position[3] = GST_AUDIO_CHANNEL_POSITION_REAR_LEFT;
      position[4] = GST_AUDIO_CHANNEL_POSITION_REAR_RIGHT;
      position[5] = GST_AUDIO_CHANNEL_POSITION_LFE1;
      break;
    default:
      return FALSE;
  }

  return TRUE;
}
