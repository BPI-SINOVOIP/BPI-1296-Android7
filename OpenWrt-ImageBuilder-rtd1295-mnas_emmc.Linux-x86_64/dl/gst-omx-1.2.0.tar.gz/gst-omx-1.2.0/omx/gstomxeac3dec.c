/*
 * Copyright (C) 2014, Sebastian Dröge <sebastian@centricular.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation
 * version 2.1 of the License.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <gst/gst.h>

#include "gstomxeac3dec.h"

GST_DEBUG_CATEGORY_STATIC (gst_omx_eac3_dec_debug_category);
#define GST_CAT_DEFAULT gst_omx_eac3_dec_debug_category

/* prototypes */
static gboolean gst_omx_eac3_dec_set_format (GstOMXAudioDec * dec,
    GstOMXPort * port, GstCaps * caps);
static gboolean gst_omx_eac3_dec_is_format_change (GstOMXAudioDec * dec,
    GstOMXPort * port, GstCaps * caps);
static gint gst_omx_eac3_dec_get_samples_per_frame (GstOMXAudioDec * dec,
    GstOMXPort * port);
static gboolean gst_omx_eac3_dec_get_channel_positions (GstOMXAudioDec * dec,
    GstOMXPort * port, GstAudioChannelPosition position[OMX_AUDIO_MAXCHANNELS]);

/* class initialization */

#define DEBUG_INIT \
  GST_DEBUG_CATEGORY_INIT (gst_omx_eac3_dec_debug_category, "omxeac3dec", 0, \
      "debug category for gst-omx eac3 audio decoder");

G_DEFINE_TYPE_WITH_CODE (GstOMXEAC3Dec, gst_omx_eac3_dec,
    GST_TYPE_OMX_AUDIO_DEC, DEBUG_INIT);

static void
gst_omx_eac3_dec_class_init (GstOMXEAC3DecClass * klass)
{
  GstElementClass *element_class = GST_ELEMENT_CLASS (klass);
  GstOMXAudioDecClass *audiodec_class = GST_OMX_AUDIO_DEC_CLASS (klass);

  audiodec_class->set_format = GST_DEBUG_FUNCPTR (gst_omx_eac3_dec_set_format);
  audiodec_class->is_format_change =
      GST_DEBUG_FUNCPTR (gst_omx_eac3_dec_is_format_change);
  audiodec_class->get_samples_per_frame =
      GST_DEBUG_FUNCPTR (gst_omx_eac3_dec_get_samples_per_frame);
  audiodec_class->get_channel_positions =
      GST_DEBUG_FUNCPTR (gst_omx_eac3_dec_get_channel_positions);

  audiodec_class->cdata.default_sink_template_caps = "audio/x-eac3, "
       "framed=(boolean) true, "
       "channels=(int)[1,6], "
       "rate=(int)[8000,48000], "
       "alignment=(string){iec61937,frame}";

  gst_element_class_set_static_metadata (element_class,
      "OpenMAX EAC3 Audio Decoder",
      "Codec/Decoder/Audio",
      "Decode EAC3 audio streams",
      "kalyan<nkalyan99@gmail.com>");

  gst_omx_set_default_role (&audiodec_class->cdata, "audio_decoder.eac3");
}

static void
gst_omx_eac3_dec_init (GstOMXEAC3Dec * self)
{
  /* FIXME: Other values exist too! */
  self->spf = 1024;
}

static gboolean
gst_omx_eac3_dec_set_format (GstOMXAudioDec * dec, GstOMXPort * port,
    GstCaps * caps)
{
  GstOMXEAC3Dec *self = GST_OMX_EAC3_DEC (dec);
  OMX_PARAM_PORTDEFINITIONTYPE port_def;
  OMX_AUDIO_PARAM_ANDROID_EAC3TYPE eac3_param;
  OMX_ERRORTYPE err;
  GstStructure *s;
  gint rate, channels;

  gst_omx_port_get_port_definition (port, &port_def);
  port_def.format.audio.eEncoding = OMX_AUDIO_CodingAndroidEAC3;
  err = gst_omx_port_update_port_definition (port, &port_def);
  if (err != OMX_ErrorNone) {
    GST_ERROR_OBJECT (self,
        "Failed to set EAC3 format on component: %s (0x%08x)",
        gst_omx_error_to_string (err), err);
    return FALSE;
  }

  GST_OMX_INIT_STRUCT (&eac3_param);
  eac3_param.nPortIndex = port->index;

  err =
      gst_omx_component_get_parameter (dec->dec, OMX_IndexParamAudioAndroidEac3,
      &eac3_param);
  if (err != OMX_ErrorNone) {
    GST_ERROR_OBJECT (self,
        "Failed to get EAC3 parameters from component: %s (0x%08x)",
        gst_omx_error_to_string (err), err);
    return FALSE;
  }

  s = gst_caps_get_structure (caps, 0);
#if 0
  if (/*!gst_structure_get_int (s, "mpegversion", &mpegversion) ||*/
      !gst_structure_get_int (s, "rate", &rate) ||
      !gst_structure_get_int (s, "channels", &channels)) {
    GST_ERROR_OBJECT (self, "Incomplete caps");
    return FALSE;
  }
#else
  if(!gst_structure_get_int (s, "rate", &rate)){
	rate = 48000;
	GST_ERROR_OBJECT (self, "[realtek] gstomxeac3dec don't got rate info");
  }

  if(!gst_structure_get_int (s, "channels", &channels)){
	channels = 2;
        GST_ERROR_OBJECT (self, "[realtek] gstomxeac3dec don't got channels info");
  }
#endif
  eac3_param.nChannels = 2; //FIXME
  eac3_param.nSampleRate = 48000; //FIXME

 err =
      gst_omx_component_set_parameter (dec->dec, OMX_IndexParamAudioAndroidEac3,
      &eac3_param);
  if (err != OMX_ErrorNone) {
    GST_ERROR_OBJECT (self, "Error setting EAC3 parameters: %s (0x%08x)",
        gst_omx_error_to_string (err), err);
    return FALSE;
  }

  if(dec->raw_out == TRUE){
        gst_omx_component_set_parameter (dec->dec, OMX_realtek_android_index_configureAudioTunnelMode, &dec->hw_avsync_fd);
  }

  if(dec->ms12_param != NULL){
	  GST_DEBUG_OBJECT (self, "[realtek] EAC3 OMX_IndexParamAudioMS12");
	  gst_omx_component_set_parameter (dec->dec, OMX_IndexParamAudioMS12, dec->ms12_param);
  }
  return TRUE;
}

static gboolean
gst_omx_eac3_dec_is_format_change (GstOMXAudioDec * dec, GstOMXPort * port,
    GstCaps * caps)
{
  GstOMXEAC3Dec *self = GST_OMX_EAC3_DEC (dec);
  OMX_AUDIO_PARAM_ANDROID_EAC3TYPE eac3_param;
  OMX_ERRORTYPE err;
  GstStructure *s;
  gint rate, channels;

  GST_OMX_INIT_STRUCT (&eac3_param);
  eac3_param.nPortIndex = port->index;
  err =
      gst_omx_component_get_parameter (dec->dec, OMX_IndexParamAudioAndroidEac3,
      &eac3_param);
  if (err != OMX_ErrorNone) {
    GST_ERROR_OBJECT (self,
        "Failed to get EAC3 parameters from component: %s (0x%08x)",
        gst_omx_error_to_string (err), err);
    return FALSE;
  }

  s = gst_caps_get_structure (caps, 0);

  if (/*!gst_structure_get_int (s, "mpegversion", &mpegversion) ||*/
      !gst_structure_get_int (s, "rate", &rate) ||
      !gst_structure_get_int (s, "channels", &channels)) {
    GST_ERROR_OBJECT (self, "Incomplete caps");
    return FALSE;
  }

  if (eac3_param.nChannels != channels)
    return TRUE;

  if (eac3_param.nSampleRate != rate)
    return TRUE;

  return FALSE;
}

static gint
gst_omx_eac3_dec_get_samples_per_frame (GstOMXAudioDec * dec, GstOMXPort * port)
{
  return GST_OMX_EAC3_DEC (dec)->spf;
}

static gboolean
gst_omx_eac3_dec_get_channel_positions (GstOMXAudioDec * dec,
    GstOMXPort * port, GstAudioChannelPosition position[OMX_AUDIO_MAXCHANNELS])
{
  OMX_AUDIO_PARAM_PCMMODETYPE pcm_param;
  OMX_ERRORTYPE err;

  GST_OMX_INIT_STRUCT (&pcm_param);
  pcm_param.nPortIndex = port->index;
  err =
      gst_omx_component_get_parameter (dec->dec, OMX_IndexParamAudioPcm,
      &pcm_param);
  if (err != OMX_ErrorNone) {
    GST_ERROR_OBJECT (dec, "Failed to get PCM parameters: %s (0x%08x)",
        gst_omx_error_to_string (err), err);
    return FALSE;
  }

  /* FIXME: Rather arbitrary values here, based on what we do in gstfaac.c */
  switch (pcm_param.nChannels) {
    case 1:
      position[0] = GST_AUDIO_CHANNEL_POSITION_MONO;
      break;
    case 2:
      position[0] = GST_AUDIO_CHANNEL_POSITION_FRONT_LEFT;
      position[1] = GST_AUDIO_CHANNEL_POSITION_FRONT_RIGHT;
      break;
    case 3:
      position[0] = GST_AUDIO_CHANNEL_POSITION_FRONT_CENTER;
      position[1] = GST_AUDIO_CHANNEL_POSITION_FRONT_LEFT;
      position[2] = GST_AUDIO_CHANNEL_POSITION_FRONT_RIGHT;
      break;
    case 4:
      position[0] = GST_AUDIO_CHANNEL_POSITION_FRONT_CENTER;
      position[1] = GST_AUDIO_CHANNEL_POSITION_FRONT_LEFT;
      position[2] = GST_AUDIO_CHANNEL_POSITION_FRONT_RIGHT;
      position[3] = GST_AUDIO_CHANNEL_POSITION_REAR_CENTER;
      break;
    case 5:
      position[0] = GST_AUDIO_CHANNEL_POSITION_FRONT_CENTER;
      position[1] = GST_AUDIO_CHANNEL_POSITION_FRONT_LEFT;
      position[2] = GST_AUDIO_CHANNEL_POSITION_FRONT_RIGHT;
      position[3] = GST_AUDIO_CHANNEL_POSITION_REAR_LEFT;
      position[4] = GST_AUDIO_CHANNEL_POSITION_REAR_RIGHT;
      break;
    case 6:
      position[0] = GST_AUDIO_CHANNEL_POSITION_FRONT_CENTER;
      position[1] = GST_AUDIO_CHANNEL_POSITION_FRONT_LEFT;
      position[2] = GST_AUDIO_CHANNEL_POSITION_FRONT_RIGHT;
      position[3] = GST_AUDIO_CHANNEL_POSITION_REAR_LEFT;
      position[4] = GST_AUDIO_CHANNEL_POSITION_REAR_RIGHT;
      position[5] = GST_AUDIO_CHANNEL_POSITION_LFE1;
      break;
    default:
      return FALSE;
  }

  return TRUE;
}
