/*
 * Copyright (C) 2014, Sebastian Dröge <sebastian@centricular.com>
 * Copyright (C) 2014, LG Electronics, Inc. <jun.ji@lge.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation
 * version 2.1 of the License.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <gst/gst.h>

#include "gstomxadpcmdec.h"

GST_DEBUG_CATEGORY_STATIC (gst_omx_adpcm_dec_debug_category);
#define GST_CAT_DEFAULT gst_omx_adpcm_dec_debug_category

/* prototypes */
static gboolean gst_omx_adpcm_dec_set_format (GstOMXAudioDec * dec,
    GstOMXPort * port, GstCaps * caps);
static gboolean gst_omx_adpcm_dec_is_format_change (GstOMXAudioDec * dec,
    GstOMXPort * port, GstCaps * caps);
static gint gst_omx_adpcm_dec_get_samples_per_frame (GstOMXAudioDec * dec,
    GstOMXPort * port);
static gboolean gst_omx_adpcm_dec_get_channel_positions (GstOMXAudioDec * dec,
    GstOMXPort * port, GstAudioChannelPosition position[OMX_AUDIO_MAXCHANNELS]);

/* class initialization */

#define DEBUG_INIT \
  GST_DEBUG_CATEGORY_INIT (gst_omx_adpcm_dec_debug_category, "omxadpcmdec", 0, \
      "debug category for gst-omx adpcm audio decoder");

G_DEFINE_TYPE_WITH_CODE (GstOMXADPCMDec, gst_omx_adpcm_dec,
    GST_TYPE_OMX_AUDIO_DEC, DEBUG_INIT);

typedef struct _WAVEFORMATEX {
    uint16_t wFormatTag;
    uint16_t nChannels;
    uint32_t nSamplesPerSec;
    uint32_t nAvgBytesPerSec;
    uint16_t nBlockAlign;
    uint16_t wBitsPerSample;
    uint16_t cbSize;
    uint16_t reserved;
} WAVEFORMATEX;

static void
gst_omx_adpcm_dec_class_init (GstOMXADPCMDecClass * klass)
{
  GstElementClass *element_class = GST_ELEMENT_CLASS (klass);
  GstOMXAudioDecClass *audiodec_class = GST_OMX_AUDIO_DEC_CLASS (klass);

  audiodec_class->set_format = GST_DEBUG_FUNCPTR (gst_omx_adpcm_dec_set_format);
  audiodec_class->is_format_change =
      GST_DEBUG_FUNCPTR (gst_omx_adpcm_dec_is_format_change);
  audiodec_class->get_samples_per_frame =
      GST_DEBUG_FUNCPTR (gst_omx_adpcm_dec_get_samples_per_frame);
  audiodec_class->get_channel_positions =
      GST_DEBUG_FUNCPTR (gst_omx_adpcm_dec_get_channel_positions);

  audiodec_class->cdata.default_sink_template_caps =
      "audio/x-adpcm, rate=(int)[8000,96000], channels=(int)[1,2] ";

  gst_element_class_set_static_metadata (element_class,
      "OpenMAX adpcm Audio Decoder",
      "Codec/Decoder/Audio",
      "Decode adpcm audio streams",
      "Sebastian Dröge <sebastian@centricular.com>");

  gst_omx_set_default_role (&audiodec_class->cdata, "audio_decoder.adpcm");
}

static void
gst_omx_adpcm_dec_init (GstOMXADPCMDec * self)
{
  self->spf = -1;
}

static gboolean
gst_omx_adpcm_dec_set_format (GstOMXAudioDec * dec, GstOMXPort * port,
    GstCaps * caps)
{
  GstOMXADPCMDec *self = GST_OMX_ADPCM_DEC (dec);
  OMX_PARAM_PORTDEFINITIONTYPE port_def;
  OMX_AUDIO_PARAM_ADPCMTYPE adpcm_param;
  WAVEFORMATEX mWaveformat;
  OMX_ERRORTYPE err;
  GstStructure *s;
  GstBuffer *final;
  const gchar *layout;
  gint rate, channels;
  gint block_align, bitrate, bits_per_sample;
  GstMapInfo map = GST_MAP_INFO_INIT;

  gst_omx_port_get_port_definition (port, &port_def);
  port_def.format.audio.eEncoding = OMX_AUDIO_CodingADPCM;        
  err = gst_omx_port_update_port_definition (port, &port_def);
  if (err != OMX_ErrorNone) {
    GST_ERROR_OBJECT (self,
        "Failed to set adpcm format on component: %s (0x%08x)",
        gst_omx_error_to_string (err), err);
    return FALSE;
  }

  GST_OMX_INIT_STRUCT (&adpcm_param);
  adpcm_param.nPortIndex = port->index;

  err =
      gst_omx_component_get_parameter (dec->dec, OMX_IndexParamAudioAdpcm,
      &adpcm_param);
  if (err != OMX_ErrorNone) {
    GST_ERROR_OBJECT (self,
        "Failed to get adpcm parameters from component: %s (0x%08x)",
        gst_omx_error_to_string (err), err);
    return FALSE;
  }

  s = gst_caps_get_structure (caps, 0);
  if (!gst_structure_get_int (s, "rate", &rate) ||
      !gst_structure_get_int (s, "channels", &channels)) {
    GST_ERROR_OBJECT (self, "Incomplete caps");
    return FALSE;
  }
  layout = gst_structure_get_string (s, "layout");
  self->rate = rate;

  adpcm_param.nSampleRate = rate;
  adpcm_param.nChannels = channels;

  //gst_structure_get_int (s, "layout", &layout);
  gst_structure_get_int (s, "block_align", &block_align);
  gst_structure_get_int (s, "bitrate", &bitrate);
  gst_structure_get_int (s, "bits_per_sample", &bits_per_sample);

  memset(&mWaveformat, 0, sizeof(WAVEFORMATEX));
  mWaveformat.nBlockAlign=block_align;
  mWaveformat.nChannels=channels;
  mWaveformat.nSamplesPerSec=rate;
  if (strcmp (layout, "dvi") == 0) //WAVE_FORMAT_DVI_ADPCM;WAVE_FORMAT_IMA_ADPCM
      mWaveformat.wFormatTag = 0x0011;
  else if (strcmp (layout, "g726") == 0) //WAVE_FORMAT_G726_ADPCM
      mWaveformat.wFormatTag = 0x0045;
  mWaveformat.wBitsPerSample = bits_per_sample;
  mWaveformat.nAvgBytesPerSec = bitrate / 8;
  final = gst_buffer_new_and_alloc (sizeof (WAVEFORMATEX));
  //GstMapInfo map = GST_MAP_INFO_INIT;
  gst_buffer_map (final, &map, GST_MAP_WRITE);
  memcpy (map.data,&mWaveformat,sizeof (WAVEFORMATEX));
  gst_buffer_unmap (final, &map);
  dec->codec_data=final;
  gst_buffer_ref (final);

  err =
      gst_omx_component_set_parameter (dec->dec, OMX_IndexParamAudioAdpcm,
      &adpcm_param);
  if (err != OMX_ErrorNone) {
    GST_ERROR_OBJECT (self, "Error setting adpcm parameters: %s (0x%08x)",
        gst_omx_error_to_string (err), err);
    return FALSE;
  }
   if(dec->raw_out == TRUE){
        gst_omx_component_set_parameter (dec->dec, OMX_realtek_android_index_configureAudioTunnelMode, &dec->hw_avsync_fd);
  }

  return TRUE;
}

static gboolean
gst_omx_adpcm_dec_is_format_change (GstOMXAudioDec * dec, GstOMXPort * port,
    GstCaps * caps)
{
  GstOMXADPCMDec *self = GST_OMX_ADPCM_DEC (dec);
  OMX_AUDIO_PARAM_ADPCMTYPE adpcm_param;
  OMX_ERRORTYPE err;
  GstStructure *s;
  gint rate, channels;

  GST_OMX_INIT_STRUCT (&adpcm_param);
  adpcm_param.nPortIndex = port->index;

  err =
      gst_omx_component_get_parameter (dec->dec, OMX_IndexParamAudioAdpcm,
      &adpcm_param);
  if (err != OMX_ErrorNone) {
    GST_ERROR_OBJECT (self,
        "Failed to get adpcm parameters from component: %s (0x%08x)",
        gst_omx_error_to_string (err), err);
    return FALSE;
  }

  s = gst_caps_get_structure (caps, 0);

  if (!gst_structure_get_int (s, "rate", &rate) ||
      !gst_structure_get_int (s, "channels", &channels)) {
    GST_ERROR_OBJECT (self, "Incomplete caps");
    return FALSE;
  }

  if (self->rate != rate)
    return TRUE;

  if (adpcm_param.nChannels != channels)
    return TRUE;

  return FALSE;
}

static gint
gst_omx_adpcm_dec_get_samples_per_frame (GstOMXAudioDec * dec, GstOMXPort * port)
{
  return GST_OMX_ADPCM_DEC (dec)->spf;
}

static gboolean
gst_omx_adpcm_dec_get_channel_positions (GstOMXAudioDec * dec,
    GstOMXPort * port, GstAudioChannelPosition position[OMX_AUDIO_MAXCHANNELS])
{
  OMX_AUDIO_PARAM_PCMMODETYPE pcm_param;
  OMX_ERRORTYPE err;

  GST_OMX_INIT_STRUCT (&pcm_param);
  pcm_param.nPortIndex = port->index;
  err =
      gst_omx_component_get_parameter (dec->dec, OMX_IndexParamAudioPcm,
      &pcm_param);
  if (err != OMX_ErrorNone) {
    GST_ERROR_OBJECT (dec, "Failed to get PCM parameters: %s (0x%08x)",
        gst_omx_error_to_string (err), err);
    return FALSE;
  }


  //g_return_val_if_fail (pcm_param.nChannels == 1, FALSE);       /* adpcm supports only mono */

 // position[0] = GST_AUDIO_CHANNEL_POSITION_MONO;
  switch (pcm_param.nChannels) {
    case 1:
      position[0] = GST_AUDIO_CHANNEL_POSITION_MONO;
      break;
    case 2:
      position[0] = GST_AUDIO_CHANNEL_POSITION_FRONT_LEFT;
      position[1] = GST_AUDIO_CHANNEL_POSITION_FRONT_RIGHT;
      break;
    case 3:
      position[0] = GST_AUDIO_CHANNEL_POSITION_FRONT_CENTER;
      position[1] = GST_AUDIO_CHANNEL_POSITION_FRONT_LEFT;
      position[2] = GST_AUDIO_CHANNEL_POSITION_FRONT_RIGHT;
      break;
    case 4:
      position[0] = GST_AUDIO_CHANNEL_POSITION_FRONT_CENTER;
      position[1] = GST_AUDIO_CHANNEL_POSITION_FRONT_LEFT;
      position[2] = GST_AUDIO_CHANNEL_POSITION_FRONT_RIGHT;
      position[3] = GST_AUDIO_CHANNEL_POSITION_REAR_CENTER;
      break;
    case 5:
      position[0] = GST_AUDIO_CHANNEL_POSITION_FRONT_CENTER;
      position[1] = GST_AUDIO_CHANNEL_POSITION_FRONT_LEFT;
      position[2] = GST_AUDIO_CHANNEL_POSITION_FRONT_RIGHT;
      position[3] = GST_AUDIO_CHANNEL_POSITION_REAR_LEFT;
      position[4] = GST_AUDIO_CHANNEL_POSITION_REAR_RIGHT;
      break;
    case 6:
      position[0] = GST_AUDIO_CHANNEL_POSITION_FRONT_CENTER;
      position[1] = GST_AUDIO_CHANNEL_POSITION_FRONT_LEFT;
      position[2] = GST_AUDIO_CHANNEL_POSITION_FRONT_RIGHT;
      position[3] = GST_AUDIO_CHANNEL_POSITION_REAR_LEFT;
      position[4] = GST_AUDIO_CHANNEL_POSITION_REAR_RIGHT;
      position[5] = GST_AUDIO_CHANNEL_POSITION_LFE1;
      break;
    default:
      return FALSE;
  }

  return TRUE;
}
