#!/bin/bash

./configure CFLAGS=-D__LINUX_MEDIA_NAS__ --with-omx-header-path=$PWD/omx/khronos --with-omx-target=generic


