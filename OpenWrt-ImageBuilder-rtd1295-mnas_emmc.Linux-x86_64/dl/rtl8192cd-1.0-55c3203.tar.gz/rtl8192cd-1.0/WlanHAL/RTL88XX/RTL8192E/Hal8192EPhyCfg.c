/*++
Copyright (c) Realtek Semiconductor Corp. All rights reserved.

Module Name:
	Hal8192EPhyCfg.c
	
Abstract:
	Defined HAL 92E PHY BB setting functions
	    
Major Change History:
	When       Who               What
	---------- ---------------   -------------------------------
	2012-11-22 Eric              Create.	
--*/





