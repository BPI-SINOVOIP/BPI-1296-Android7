#ifndef __HAL8881APHYCFG_H__
#define __HAL8881APHYCFG_H__

/*++
Copyright (c) Realtek Semiconductor Corp. All rights reserved.

Module Name:
	Hal8881APhyCfg.h
	
Abstract:
	Defined HAL 88XX PHY BB setting functions
	    
Major Change History:
	When       Who               What
	---------- ---------------   -------------------------------
	2012-11-14 Eric              Create.	
--*/



// TODO: this function should be modified
void 
TXPowerTracking_ThermalMeter_Tmp8881A(
    IN  HAL_PADAPTER    Adapter
);




#endif // #ifndef __HAL8881APHYCFG_H__

