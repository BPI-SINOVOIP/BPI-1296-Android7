#ifndef __RTL88XX_REG_H__
#define __RTL88XX_REG_H__

/*++
Copyright (c) Realtek Semiconductor Corp. All rights reserved.

Module Name:
	Hal88XXReg.h
	
Abstract:
	Defined RTL88XX Register Offset & Marco & Bit define
	    
Major Change History:
	When            Who                      What
	---------- ---------------  -------------------------------
	2012-03-23  Filen                      Create.	
	2012-03-29  Lun-Wu Yeh          Add Tx/Rx Desc Reg
--*/

/*--------------------------Define -------------------------------------------*/



#endif  //__RTL88XX_REG_H__

