    $( document ).ready(function() {
        $(".language").show();
        $('.done').hide();
        $('.next').show();
        $('.back').hide();
        $('.content').hide();
        $($('.content')[0]).css('display','block');
        bindEvent();
        stepDoneUI();
    });

    function checkAPIError(data){
        if($("error", data).length > 0){
            var msg = $("reason", data).text() + '\n\n' + $("detail", data).text() + '\n\n\n';
            alert(msg);
            return true;
        }
        else return false;
    }

    function stepDoneUI(){
        //set language
        $('.pw').attr('placeholder',$.l10n.__('gmsg_enter_password'));
        $('.cfpw').attr('placeholder',$.l10n.__('gmsg_confirm_password'));
        $('#option').attr("checked",false);
        getdevicelist();
        getnetwork();
        listTimezone();
    };

    // Set language
    function  bindEvent(){
        var defaultlang=navigator.language.toLowerCase();
        setLang({lang:defaultlang});
    }

    function setLang(option){
        if(!option)option={};
        var lang=option.lang;
        if(!lang)lang=window.top.Lang;
        if(!lang)lang=window.navigator.systemLanguage || window.navigator.language;
        lang=lang.toLowerCase();
        // Set language to en-us if not supported
        var langs=['de','en-us','es','fr','it','ja','ko','nl','ru','zh-cn','zh-tw'];
        if($.inArray(lang,langs)<0)lang='en-us';
        window.top.Lang=lang;
        var $domain=$('[domain=l10n]');

        $domain.l10n({
            dir: window.location.protocol+"//"+window.location.host+"/wizard/languages"
            ,lang: lang
        });
    }

    function bindlang(langtype){
        setLang({lang:langtype});
        return langtype;
    }

    // Continue and back button
    function getCurrentSectionContent(){
        var content = $('.content')
        for (var i = 0; i < 4; i++) {
            $(content[i]);
            if ($(content[i]).css('display') !== 'none') {
                return i;
            };
        };
    };

    $('.next').click(function () {
        var current = getCurrentSectionContent();
        if(current === 0){	// Administrator
            if(!toValidatepass()) return;
            setpass();

            $($('.content')[current]).hide();
            $($('.content')[current+1]).show();
            $('.back').show();
        }
        else if(current === 1){	// RAID
            setraid();

            $($('.content')[current]).hide();
            $($('.content')[current+1]).show();
        }
        else if(current === 2){	// Network
            if(!$("#dhcp").hasClass('RadioTarget')){
                if(!toValidatenetwork()) return;
            }
            $('.focusStep1').find('.stepNetwork').addClass('stepDone');

            $('.next').hide();
            $('.done').show();
            $($('.content')[current]).hide();
            $($('.content')[current+1]).show();
        }
    });

    $('.back').click(function () {
        var current = getCurrentSectionContent();
        var nextPage = current - 1;
        $($('.content')[current]).hide();
        $($('.content')[nextPage]).show();
        $('.next').show();
        $('.done').hide();
        if (nextPage === 0) {
            $('.back').hide();
        }

        // set class: stepDone
        if(nextPage === 0)    // Administrator
            $('.focusStep1').find('.stepAdmin').removeClass('stepDone');
        else if(nextPage === 1)    // RAID
            $('.focusStep1').find('.stepRAID').removeClass('stepDone');
        else if(nextPage === 2)    // Network
            $('.focusStep1').find('.stepNetwork').removeClass('stepDone');
        else            // TimeZone
            $('.focusStep1').find('.stepTimeZone').removeClass('stepDone');
    });

    $('#option').click(function (){
        var check = $("#option:checked").length;
        if(check == 1){
            $("#option").addClass("ckecked");
            $('.pw').clone().attr('type','text').insertAfter('.pw').prev().remove();
            $('.cfpw').clone().attr('type','text').insertAfter('.cfpw').prev().remove();
        }
        else{
            $("#option").removeClass("ckecked");
            $('.pw').clone().attr('type','password').insertAfter('.pw').prev().remove();
            $('.cfpw').clone().attr('type','password').insertAfter('.cfpw').prev().remove();
        }
    });

    function toValidatepass(){
        var newpass = $(".pw").val();
        if( newpass.length === 0 ){
            alert( $.l10n.__("admin_password_notmatch") );
            return false;
        }
        if( newpass !== $(".cfpw").val() ){
            alert( $.l10n.__("admin_password_invalidchar") );
            return false;
        }
        if(newpass.match(/[\-_\.!#&@\$\*\^%]/)){
            alert( $.l10n.__("admin_password_symbol") );
            return false;
        }
    return true;
    };

    function toValidatenetwork(){
        var beforeip = $("#init_ip").text().split('.');
        var afterip = $("#ipaddr").val().split('.');
        if(beforeip[0] !== afterip[0] || beforeip[1] !== afterip[1] || beforeip[2] !== afterip[2]){
            alert("Wrong IP: " + $("#ipaddr").val() + ". Please input the same subnet.");
            return false;
        }
        if(!(parseInt(afterip[3]) > 0 && parseInt(afterip[3]) < 255)){
            alert("Wrong IP: "+ $("#ipaddr").val() + ". The last segment should be 1~254.");
            return false;
        }
        return true;
    }

    function getdevicelist(){
        $.ajax({
            url:window.location.protocol+"//"+window.location.host+"/nas/wizard/"
            ,cache:false
            ,data:{
                method:'getdevices'
            }
            ,type: "POST"
            ,cache:false
            ,dataType:"xml"
            ,success: function(data){
                if(checkAPIError(data)) return;
                parsedevice(data);
            }
            ,error:function(data){
                alert($.l10n.__("global_alert_getdataerror"));
            }
        });
    };

    function parsedevice(data){
        if (data === null)return;

        // keep
        var partmaxsize = 0;
        var partmaxpath = 0;
        var arraymaxsize = 0;
        var arraymaxpath = 0;
        $(data).find("partition").each(function(i){
            if($("flags",this).text() !== 'raid' && $("fs",this).text() !== 'swap'){
            // 取最大長度
                var node =  $("raid",this.parentNode);
                if($("raid",this.parentNode)){    // 具較高優先權
                    if(parseInt($("length",this).text()) > arraymaxsize){
                        arraymaxsize = parseInt($("length",this).text());
                        arraymaxpath = $("path",this).text();
                    }
                }
                else{
                    if(parseInt($("length",this).text) > partmaxsize){
                        partmaxsize = parseInt($("length",this).text());
                        partmaxpath = $("path",this).text();
                    }
                }
            }
        });

        if(arraymaxsize > 0)	// $('.RadioTarget label p') is mount path
            $('.RadioTarget label p').text(arraymaxpath);
        else
            $('.RadioTarget label p').text(arraymaxpath);

        // Raid0 and Raid1
        var diskminsize = 0;
        var numofdisk = 0;
        $(data).find("device").each(function(i){
            if($("external",this).text() !== 'yes' && $("raid",this).text() === ""){
                numofdisk++;
                if (diskminsize === 0) diskminsize = parseInt($(">length",this).text());
                if(parseInt($(">length", this).text()) < diskminsize)
                    diskminsize = parseInt($("length:last-child",this).text());
            }
        });

        var raid0SizeTb = diskminsize * numofdisk / (1024*1024*1024*1024/512);
        var raid1SizeTb = diskminsize / (1024*1024*1024*1024/512);

        $('.raid0 label .size').text(raid0SizeTb.toFixed(2));
        $('.raid1 label .size').text(raid1SizeTb.toFixed(2));

        // single device
        if(numofdisk === 1){
            $(".raid0").hide();
            $(".raid1").hide();
            $(".jbod").hide();
            $(".single").show();
        }
        else
            $(".single").hide();
    }

    function getnetwork(){
        $.ajax({
            url:window.location.protocol+"//"+window.location.host+"/nas/wizard/"
            ,data:{
                method:'getnetwork'
            }
            ,type: "POST"
            ,cache:false
            ,dataType:"xml"
            ,success: function(data){
                if(checkAPIError(data)) return;
                $("#ipaddr").val($("ipaddr",data).text());
                $("#init_ip").text($("ipaddr",data).text());
                $("#netmask").val($("netmask",data).text());
                $("#gateway").val($("gateway",data).text());
                $("#nameserver1").val($("dns1",data).text());
                $("#nameserver2").val($("dns2",data).text());
            }
            ,error:function(data){
                alert($.l10n.__("global_alert_getdataerror"));
            }
        });
    }

    function listTimezone(){
        $.ajax({
            url:window.location.protocol+"//"+window.location.host+"/nas/wizard/"
            ,data:{
                method:'getzones'
            }
            ,type: "POST"
            ,cache:false
            ,dataType:"xml"
            ,success: function(data){
                if(checkAPIError(data)) return;
                $("zone",data).each(function(){
                    $("#timezonelist").append("<option value='"+$(this).text()+"'>"+$(this).text()+"</option>");
                });
                getcurrentzone();
            }
            ,error:function(data){
                alert($.l10n.__("global_alert_getdataerror"));
            }
        });
    };

    function getcurrentzone(){
        $.ajax({
            url:window.location.protocol+"//"+window.location.host+"/nas/wizard/"
            ,data:{
                method:'getcurrentzone'
            }
            ,type: "POST"
            ,cache:false
            ,dataType:"xml"
            ,success: function(data){
                if(checkAPIError(data)) return;
                var zone = $("zone",data).text();
                if(zone)
                    $("#timezonelist").val(zone);
                else
                    $("#timezonelist")[0].selectedIndex = 0;
            }
            ,error:function(data){
                alert($.l10n.__("global_alert_getdataerror"));
            }
        });
    };

    function setpass(){
        var newpass = $(".pw").val();
        $.ajax({
            url:window.location.protocol+"//"+window.location.host+"/nas/wizard/"
            ,data:{
                method:'setpass'
                ,user:'admin'
                ,pass: newpass
            }
            ,type: "POST"
            ,cache:false
            ,dataType:"xml"
            ,success: function(data){
                if(checkAPIError(data)) return;
                $('.focusStep1').find('.stepAdmin').addClass('stepDone');
            }
            ,error:function(data){
                alert($.l10n.__("global_alert_getdataerror"));
            }
        });
    }

    function setraid(){
        var tpyeofraid = $('input[name=raid]:checked').val();
        if(tpyeofraid === 'keep') setraidmount();
        else if(tpyeofraid === 'raid0') setraidlevel("0");
        else if(tpyeofraid === 'raid1') setraidlevel("1");
        else if(tpyeofraid === 'jbod') setraidlevel("linear");
        else if(tpyeofraid === 'single')setraidlevel("1");
        else alert($.l10n.__("global_alert_getdataerror"));
    }

    function setraidmount(){
        $.ajax({
            url:window.location.protocol+"//"+window.location.host+"/nas/wizard/"
            ,data:{
                method:'raidmount'
            }
            ,type: "POST"
            ,cache:false
            ,dataType:"xml"
                ,success: function(result){
                    if(checkAPIError(data)) return;
                    getdevicelist();
                    $('.focusStep1').find('.stepRAID').addClass('stepDone');
                    return true;
                }
                ,error:function(data){
                    alert($.l10n.__("global_alert_getdataerror"));
                }
        });
    }

    function setraidlevel(level){
        $.ajax({
            url:window.location.protocol+"//"+window.location.host+"/nas/wizard/"
            ,data:{
                method:'raidsetup'
                ,raidlevel: level
            }
            ,type: "POST"
            ,cache:false
            ,dataType:"xml"
            ,success: function(result){
                if(checkAPIError(data)) return;
                getdevicelist();
                $('.focusStep1').find('.stepRAID').addClass('stepDone');
                return true;
            }
            ,error:function(data){
                alert($.l10n.__("global_alert_getdataerror"));
            }
        });
    }

    function settimezone(){
        $.ajax({
            url:window.location.protocol+"//"+window.location.host+"/nas/wizard/"
            ,data:{
                method:'setzone'
                ,zone:$("#timezonelist").val()
            }
            ,type: "POST"
            ,cache:false
            ,dataType:"xml"
            ,success: function(data){
                if(checkAPIError(data)) return;
                setNASInit();
            }
            ,error:function(data){
                $("#waiting").hide();
                alert($.l10n.__("global_alert_getdataerror"));
            }
        });
    }

    function setNASInit(){
        $.ajax({
            url:window.location.protocol+"//"+window.location.host+"/nas/wizard/"
            ,cache:false
            ,data:{
                method:'setinit'
                ,dhcp:($("#dhcp").hasClass('RadioTarget'))?'yes':'no'
                ,ipaddr:($("#dhcp").hasClass('RadioTarget'))?'':$("#ipaddr").val()
                ,netmask:($("#dhcp").hasClass('RadioTarget'))?'':$("#netmask").val()
                ,gateway:($("#dhcp").hasClass('RadioTarget'))?'':$("#gateway").val()
                ,dns1:($("#dhcp").hasClass('RadioTarget'))?'':$("#nameserver1").val()
                ,dns2:($("#dhcp").hasClass('RadioTarget'))?'':$("#nameserver2").val()
            }
            ,type: "POST"
            ,dataType:"xml"
            ,success: function(data){
                if(checkAPIError(data)) return;
                if(!$("#dhcp").hasClass('RadioTarget')){
                    window.setTimeout(function(){
                        window.setInterval( function(){window.open(window.location.protocol+"//"+$('#ipaddr').val()+"/index.html","_self");},3000);
                    },10000);
                }
                else window.open(window.location.protocol+"//"+window.location.host+"/index.html","_self");
            }
            ,error:function(data){
                $("#waiting").hide();
                alert ($.l10n.__("global_alert_getdataerror"));
            }
        });
    }

    $('.done').click(function (){
        $("#waiting").show();
        settimezone();
    });


    // Show and close languages menu : 20160504 update
    var scrollX = 0;
    var scrollY = 0;
    $('.menu-icon').click(function langChange(e) {
        var bodyContent = document.getElementById('bodyContent');
        var popup = document.getElementById('dropmenu');
        if ($('.menu-icon').hasClass('close')) {
            $(this).removeClass('close');
            $('#dropmenu').fadeOut().hide();
            popup.style.display = 'none';
            delete bodyContent.style.left;
            delete bodyContent.style.top;
            bodyContent.style.position = 'static';
            window.scrollTo(scrollX, scrollY);
        } else {
            $(this).addClass('close');
            $('#dropmenu').slideDown(300).show();
            popup.style.display = 'block';
            scrollX = window.pageXOffset || document.documentElement.scrollLeft;
            scrollY = window.pageYOffset || document.documentElement.scrollTop,
            bodyContent.style.position = 'fixed';
            bodyContent.style.left = -scrollX;
            bodyContent.style.top = -scrollY;
        }
    });

    var raidOption = 'radio-btn-current';
    $(".radio-btn").click(function(e) {
        $(".radio-btn").removeClass('RadioTarget');
        $(this).addClass('RadioTarget');
        $(this).find('input')[0].checked = true; // DOM API

        // TODO(RD): store the value and pass it when clicking "Next".
        var idName = $(this).attr('id');
        raidOption = idName;
    });

    //  IP address (jquery mask plugin)
    $('.ip_address').mask('099.099.099.099');
    // IE8 placeholder effect.
    $('input[placeholder], textarea[placeholder]').placeholder();
