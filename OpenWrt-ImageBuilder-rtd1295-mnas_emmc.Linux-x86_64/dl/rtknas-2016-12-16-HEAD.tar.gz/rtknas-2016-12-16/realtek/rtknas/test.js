﻿var commands=[
	  ['cls','null','clear screen']
	  ,['help','null','show help']
	  ,['version','get:version','Get FW name and version']
	  ,['sda','get:internal_diskcapacity','Get internal disk capacity']
	  ,['mac' ,'mpget:macaddress','Get Mac Address']
	  ,['key','mpget:seckey','Get Secret Key']
	  ,['usb','mpget:external_usbcapacity',' Get external USB capacity']
	  ,['hwclock' ,'mpget:hwclock','Get hardware clock']	  
	  ,['clock' ,'mpset:clock','clock YYYYMMDDHHmmSS']
	  ,['sdb','mpget:external_esatacapacity','Get external ESATA capcity.']
	  ,['leds on','mpset:testledson','Test LEDs by making them blink on.']
	  ,['leds off','mpset:testledsoff','Test LEDs by making them blink off.']
	  ,['leds blink','mpset:testledsblink',' Test LEDs by making them blink on.']
	  ,['button begin','mpset:testButtonBegin','To turn off the original function of all buttons.']
	  ,['button status','mpget:testButtonStatus','Return OK or FAIL for button pressed or released within 5 secconds.']
	  ,['button end','mpset:testButtonEnd','To turn on the original function of all buttons.']
	];

var records=[];
var position=null;

$(function(){
	newCommand();
	$(document.documentElement).keydown(function(event){
	   if(event.keyCode!=13)$('input:last').focus();
	   if(event.keyCode==38||event.keyCode==40)findCommand(event.keyCode);
	});
});

function newCommand(){
	$('body').append('<div class="q"><span>COMMAND&gt; </span><input type="text"/></div>');
	$('input:last').keyup(function(event){
	   if(event.keyCode==13){
		   exe(this.value);
		}	   
	}).focus();
}



function exe(c){
	var i=$('input:last');
	$('div:last').append('<label>'+i.val()+'</label>');
	i.remove();
	records.push(c);
	position=null;
	c=c.toLowerCase();
	var r=validCommand(c);
	if(r){
		if(c=="cls"){
			clear();
			return;
		}
		if(c=="help"){
			help();
			return;
		}
		$.ajax({
		   url: "/testonly/?"+r
		   ,type: "POST"
		   ,cache:false
		   ,dataType: "text"
		   ,success: function(data){
				$('body').append('<pre class="a">'+data+'</pre>');
				newCommand();
			}
		   ,error: function(data) { ;
				$('body').append('<pre class="a e">ERROR: '+ data.statusText+'</pre>');
				newCommand();
			}
		 });
	}
	else{
		$('body').append('<div class="a w">WRONG COMMAND!</div>');
		newCommand();
	}
}


function clear(){
	$('body').html('');
	newCommand();
}


function help(){
	var html=['<div class="a"><ol>'];
	for(var i=0,l=commands.length;i<l;i++){
		html.push('<li><label>'+commands[i][0]+'</label> : '+commands[i][2]+'</li>');
	}
	html.push('</ol></div>');
	$('body').append(html.join(''));
	newCommand();
}

function validCommand(c){
	var r=false;
	for(var i=0;i<commands.length;i++){
		if(c==commands[i][0]){
			r=commands[i][1];
			break;
		}
	}
	if(c.indexOf('clock')===0){
		r='mpset:clock='+c.replace('clock','').replace(/\s/g,'');
	}

	return r;
}

function findCommand(k){
	if(records.length==0)return; 
	if(position==null)position=records.length-1;
	if(k==38){
		$('input:last').val(records[position]);
		position --;
	}
	if(k==40){
		$('input:last').val(records[position]);
		position ++;
	}
	if(position>records.length-1)position=records.length-1;
	if(position<0)position=0;
}