﻿$(function(){
	window.App="Preference";
	loadLang();	
	loadData({hash:window.top.SessionID},"get");
	bindEvent();
});


//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){	
	$("#APPLY").click(function(){	toApply();	});
	$("#REFRESH").click(function(){	loadData();	});	
}





//解析数据函数-------------------------------------------------------------------------
function parseData(data){
	if($('enable',data).text().toLowerCase()=='yes'){
		$("#check").attr('checked','checked');
	}
	if($('enable',data).text().toLowerCase()=='no'){
		$("#check").removeAttr('checked');
	}
	if($('running',data).text().toLowerCase()=='yes'){
		$('#running').html('<label domain="l10n" msgid="Preference_main_text_servicerunning">'+$.l10n.__('Preference_main_text_servicerunning')+'</label>');
		// show icon for media playback
		$('#url_link').html("<div class='icon s81 dvdp'></div>");
	}
	if($('running',data).text().toLowerCase()=='no'){
		$('#running').html('<label domain="l10n" msgid="Preference_main_text_servicestopped">'+$.l10n.__('Preference_main_text_servicestopped')+'</label>');
		$('#url_link').html("");
	}
}



//-----------------------------------------------------------------------------------------------------------------------
function loadData(){	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+'nas/get/media'
		,cache:false
		,data:{hash:window.top.SessionID}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}


//-----------------------------------------------------------------------------------------------------------------------
function toApply(){
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+'nas/set/media'
		,cache:false
		,data:{
			hash:window.top.SessionID
			,enable:($("#check").attr('checked'))?'yes':'no'}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}
