﻿$(function(){
	window.App="Preference";
	loadLang();	
	loadData();
	bindEvent();
});



//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){	
	$("#APPLY").click(function(){	toApply();	});
}



function loadData(){	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/spindown/"
		,cache:false
		,data:{
			hash:window.top.SessionID
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			var s=$('seconds',data).text()-0;
			var t=$("#timeout")[0];
			if(s===0)t.selectedIndex=0;
			if(s>0&&s<600)t.selectedIndex=1;
			if(s>=600&&s<900)t.selectedIndex=2;
			if(s>=900&&s<1200)t.selectedIndex=3;
			if(s>=1200&&s<1800)t.selectedIndex=4;
			if(s>=1800&&s<3600)t.selectedIndex=5;
			if(s>=3600)t.selectedIndex=6;
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}



function toApply(){
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/spindown/disk"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,timeout:$("#timeout").val()+'m'
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}