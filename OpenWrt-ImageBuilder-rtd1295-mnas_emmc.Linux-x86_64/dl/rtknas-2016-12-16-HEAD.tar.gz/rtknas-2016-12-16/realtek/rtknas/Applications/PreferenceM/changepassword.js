﻿$(function(){
	window.App="Preference"; 
	loadLang();	
	bindEvent();
	$("#username").val(window.top.user);
});




//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){	
	$("#APPLY").click(function (){ toEdit(); });	
}



function toEdit(){
	if(!validate())return;
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/edit/user"
		,cache:false
		,data:{
			username:$("#username").val()
			,password:Crypt($("#oldpassword").val(),window.top.modulus,window.top.public)
			,newpassword:Crypt($("#password").val(),window.top.modulus,window.top.public)
			//,privilege:$("#privilege").val()
			,hash:window.top.SessionID
			//,time:new Date()
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			alert ($.l10n.__("Preference_changepwd_alert_ok")); 
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
	});
	
}



//---------------------------------------验证---------------------------------------------------------
function validate(){
	var fields = [
		{
			method : 'required',
			value : $('#password').val(), 
			element : $('#password')[0],
			param : null, 
			errParam : $.l10n.__('global_text_password')
		},
		{
			method : 'rangelength',
			value : $('#password').val(), 
			element : $('#password')[0],
			param : [1,16], 
			errParam : [$.l10n.__('global_text_password'),1,16]
		},		
		{
			method : 'required',
			value : $('#oldpassword').val(), 
			element : $('#oldpassword')[0],
			param : null, 
			errParam : $.l10n.__('Preference_accounts_text_oldpwd')
		},
		{
			method : 'equalTo',
			value : $('#confirmpassword').val(), 
			element : $('#confirmpassword')[0],
			param : $('#password').val(),
			errParam : [$.l10n.__('global_text_password'), $.l10n.__('Preference_accounts_text_cfmpass')]
		}
	];
	return validateFields(fields);
}