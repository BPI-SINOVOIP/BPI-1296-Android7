﻿/* Set some global variable values to make this page a standalone one. */
//if(!window.urlpath){
window.urlpath=(window.location.protocol+"//"+window.location.host+'/rtknas/');
//window.remoteDataUrl='/';
window.SessionID=getRequest("id");
window.remoteDataUrl=getRequest("remoteDataUrl");
window.Lang=getRequest("lang").replace('_','-');
window.user=getRequest("user");
window.privilege=getRequest("privilege");
window.modulus=getRequest("modulus");
window.public=getRequest("public");

/*var imported = document.createElement('script');
imported.src = '../../Library/Dean.library.js';
document.head.appendChild(imported);

var imported = document.createElement('script');
imported.src = '../../Library/Dean.desktop.js';
document.head.appendChild(imported);

var imported = document.createElement('script');
imported.src = '../../Library/Dean.windows.js';
document.head.appendChild(imported);*/

function loadNASinfo(){
    $.ajax({
        url: window.top.remoteDataUrl+"nas/get/info"
        ,cache:false
        ,async:false
        ,data:{hash:window.top.SessionID}
        ,type: "POST"
        ,dataType:"xml"
        ,success: function(data){
            if(window.top.checkAPIError(data))return;
            window.top.NASinfo={
                ip:$('ipaddr:first',data).text()
                ,vpnip:$('vpnip',data).text()
                ,upnp:$('upnpaddr',data).text()
                ,hostname:$('hostname',data).text()
                ,mac:$('hwaddr',data).text().replace(/:/g,'')
                ,time:$('date',data).text()
                ,registername:$('register',data).text()
                ,version:$('version',data).text()
                ,package:$('package',data).text()
                ,storage:{
                    available:$('storage available', data).text()
                    ,used:$('storage used', data).text()
                    ,blocks:$('storage blocks', data).text()
                    ,usedpercent:$('storage usedpercent', data).text()
                    ,writable:$('storage writable', data).text()
                }
            };
            window.top.document.title=window.top.NASinfo.registername;
        }
    });
}

loadNASinfo();

//}

$(function(){	
	window.App="Preference";
	layout();
	loadData();

});


function layout(){
	window.Layout = $('body').layout({ 
			center__paneSelector:"#main" 
		,	north__paneSelector:"#top" 
		,	north__size:48
		,	north__spacing_open:0
		,	resizable:false
	}); 
	$('.ui-layout-pane').css({overflow:'hidden'});
}

function bindEvent(){
	$(".program_toolbar a").click(function(){		
		$("#Setup").show();
		$("#All").hide();
	});
	
	/*$("#All li").click(function(){
		var t=$("label",this).attr("msgid");
		if(t&&t!=='')window.win.setTitle("<label domain='l10n' msgid='" + t+ "'>"+$.l10n.__(t)+"</label>");
		else window.win.setTitle("<label>"+$("label",this).text()+"</label>");
		window.win.resize(640,$(this).attr("_height")-0);
	});*/
	$("#SHOWALL").click(function(){	showAll();	});
	$("li").addClass('enabled');
}


function loadData(){
	$.ajax({
		url:window.top.urlpath+'Configurations/System/preferences.xml'
		,dataType:'xml'
		,success:parseData
		,error:function(){
		}
	});
}


function checkMNAS(){
$.ajax({
    url: window.top.remoteDataUrl+"nas/get/mnas"
    ,cache:false
    ,data:{
        hash:window.top.SessionID
        }
    ,type: "POST"
    ,dataType:"xml"
    ,success: function(data){
        if(window.top.checkAPIError(data))return;
        var d=$(data);
        if( d.find('enable').text() == 'yes' ){
        $('li.t25').show();
        }
    }
    ,error:function(data){
    }
});
}


function parseData(data){
	$('items',data).each(function(){
		var id=$(this).attr('id');
		var $ul=$('#'+id+' ul');
		$('item',this).each(function(){
			var i=$('icon',this).text();
			var h=$('height',this).text();
			var n=$('name',this).text();
			var l=$(this).attr('l10n');
			var L=$(this).attr('lang');
			if(L){
				L=L.split(',');
				if($.inArray(window.top.Lang,L)===-1)return;
			}
			$ul.append('<li class="t'+i+'" _height="'+h+'"><a href="'+n+'.html" target="Setup"><img src="../../Library/blank.gif"/><br/><label ' + (l==='no'?'':'domain="l10n"  msgid="Preference_main_text_'+n+'"')   +'>'+(l==='no'?n:'')+'</label></a></li>');
		});
	});
	//if(window.top.Lang!=='zh-tw')$('li.t23').hide();
	// Media Playback
	$('li.t25').hide();
	checkMNAS();

	loadLang();
	bindEvent();
}

function showAll(){
	$("#Setup").hide();
	$("#All").show();
	$("#Setup").attr('src','about:blank');
	var win=window.top.curWin;
	var t="System_application_Preference";
	//window.win.setTitle("<label domain='l10n' msgid='"+t+"'>"+window.top.$.l10n.__(t)+"</label>");
	//window.win.resize(640,365);
}
