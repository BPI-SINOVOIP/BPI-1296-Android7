﻿$(function(){
	window.App="Preference";
	loadLang();	
	layout();
	bindEvent();
});

function layout(){
	$('body').layout({ 
			center__paneSelector:"#main"
		,	west__paneSelector:"#left" 
		,	west__size:200
		,	west__spacing_open:0
		,	south__paneSelector:"#bottom"   
		,	south__size:60
		,	south__spacing_open:0
		,	contentSelector:".data"
	}); 
	
	$('#left li a').each(function(){
		this.href=window.top.remoteDataUrl+"nas/"+window.top.SessionID+"/"+this.id+".log";
		this.target='data';
	});

}



//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){	
	$("#left li a").click(function(){
		$("#left li a.selected").removeClass('selected');
		$(this).addClass('selected');
	});
	
	$("#CLEAR").click(function(){	toClear();	});
	$("#REFRESH").click(function(){	$('#data')[0].contentWindow.location.reload();	});
}



function toClear(){
	if(confirm($.l10n.__('Preference_log_alert_clear'))){
		var path=$("#left li a.selected");
		if(path.length==0)return;
		path=path[0].id;
		$("#waiting").show();
		$.ajax({
		   url: window.top.remoteDataUrl+"nas/clear/log"
		   ,cache:false
		   ,type: "POST"
		   ,data: {
			   hash:window.top.SessionID
			   ,cat:path
			}
		   ,dataType: "xml"
		   ,success: function(data){
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
				$("#REFRESH").click();
			}
		   ,error: function(data) {
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}
		   //,timeout: 10000
		 });
	}
}
