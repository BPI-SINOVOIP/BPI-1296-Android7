﻿$(function(){
	window.urlpath=(window.location.protocol+"//"+window.location.host+window.location.pathname).replace("Applications/Preference/shutdown.html","");
	window.hostpath=window.location.protocol+"//"+window.location.host+'/';
	window.remoteDataUrl=getRequest("remoteDataUrl");//系统数据目录
	window.SessionID=getRequest('id')
	window.Lang=getRequest('lang');
	window.App="Preference";
	loadLang();	
	//var dl=window.location.protocol+"//"+window.registername+'.'+$.l10n.__('global_link_domainname')+'/';
	var dl=window.location.protocol+"//"+window.registername;
	$("#domainlink").html(dl);
	loadData();
});



//-----------------------------------------------------------------------------------------------------------------------
function loadData(){	
	$.ajax({
		url: window.top.remoteDataUrl+"nas/leave"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,action:'poweroff'
			,time:0
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			//if(window.checkAPIError(data))return;
			//alert($('nas',data).text());
			countdown(40);
		}
		,error:function(data){
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}

var secs;
function countdown(second) {
    secs = second;
    var div_finished = document.getElementById('finished');
    div_finished.style.visibility = 'hidden';

	setTimeout('Decrement()',1000);
}
function Decrement() {
	if (document.getElementById){
		var seconds = document.getElementById("seconds");
		seconds.value = getseconds();
		secs--;
		if (secs > 0){
    		setTimeout('Decrement()',1000);
        }
        else{
             var div_timer = document.getElementById('timer');
             div_timer.style.visibility = 'hidden';

             var div_finished = document.getElementById('finished');
             div_finished.style.visibility = 'visible';
        }
	}
}

function getseconds() {
   return secs;
}
