﻿$(function(){
	window.App="Preference";
	loadLang();	
	bindEvent();
});








//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){	
	$("#SHUTDOWN").click(function(){	toShutdown();	});
	$("#RESTART").click(function(){	toRestart();	});
}


function toShutdown(){
	if(confirm($.l10n.__('Preference_shutdown_text_confirmpoweroff'))){
		window.top.location=window.top.urlpath+'Applications/Preference/shutdown.html?lang='+window.top.Lang+'&registername='+window.top.NASinfo.registername+'&id='+window.top.SessionID+"&remoteDataUrl="+window.top.remoteDataUrl+'&';
	}
}


function toRestart(){
	if(confirm($.l10n.__('Preference_shutdown_text_confirmrestart'))){
		window.top.location=window.top.urlpath+'Applications/Preference/restart.html?lang='+window.top.Lang+'&registername='+window.top.NASinfo.registername+'&id='+window.top.SessionID+"&remoteDataUrl="+window.top.remoteDataUrl+'&';
	}
}

