﻿$(function(){
	window.App="Preference";
	loadLang();	
	bindEvent();
	loadData();
});



//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){	
	$("#APPLY").click(function(){	toApply();	});
//	$("#SCAN").click(function(){	toScan();	});
	$("#check").click(function(){	enableService();	});
	$("#browse").click(function(){	showBrowse();	});	
	$("#REFRESH").click(function(){	loadData();	});
}



//-----------------------------------------------------------------------------------------------------------------------
function loadData(){	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/daap"
		,cache:false
		,data:{
			hash:window.top.SessionID
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}



function parseData(data){
	if($('enable',data).text().toLowerCase()=='yes'){
		$("#check").attr('checked','checked');
	}
	if($('enable',data).text().toLowerCase()=='no'){
		$("#check").removeAttr('checked');
	}
	if($('running',data).text().toLowerCase()=='yes'){
		$('#running').html('<label domain="l10n" msgid="Preference_main_text_servicerunning">'+$.l10n.__('Preference_main_text_servicerunning')+'</label>');
	}
	if($('running',data).text().toLowerCase()=='no'){
		$('#running').html('<label domain="l10n" msgid="Preference_main_text_servicestopped">'+$.l10n.__('Preference_main_text_servicestopped')+'</label>');
	}
	$("#servername").val($('servername',data).text()); 
	$("#scanfolder").val(   syspathToDavpath ( decodeURI ($('directory',data).text()  ) ) ); 
//	$("#scantime").val($('interval',data).text()/60); 
	enableService();
	

}


function toApply(){	
	if(!validate())return;	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/set/daap"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,enable:($("#check").attr('checked'))?'yes':'no'
			,servername:$("#servername").val()
			,directory:'/dav'+$("#scanfolder").val()
//			,interval:$("#scantime").val()*60
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}


function showBrowse(){
	window.top.System.selectDir({
		app:window.top.Preference
		,handler: function(path){
			$("#scanfolder").val(   decodeURI(path) );
		}
	}); 
}


/*function toScan(){
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/daap/scan"
		,data:{
			hash:window.top.SessionID
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			alert($.l10n.__('Preference_itunes_alert_scanning'));
			$("#SCAN").hide();
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}
*/

function enableService(){
	if(($("#check").is(':checked'))){
		$("table input").removeAttr('disabled');
	}
	else{
		$("table input").attr('disabled','disabled');
	}
	$('#scanfolder').attr('disabled','disabled');
}


function validate(){
	var fields = [];
	
	if($("#check").attr('checked')){
		fields.push(
		{
			method : 'required',
			value : $('#servername').val(), 
			element : $('#servername')[0],
			param : null, 
			errParam : $.l10n.__("Preference_itunes_text_servername")
		},
		{
			method : 'required',
			value : $('#scanfolder').val(), 
			element : $('#scanfolder')[0],
			param : null, 
			errParam : $.l10n.__("Preference_itunes_text_folder")
		}/*,
		{
			method : 'required',
			value : $('#scantime').val(), 
			element : $('#scantime')[0],
			param : null, 
			errParam : $.l10n.__("Preference_itunes_text_interval")
		},
		{
			method : 'digits',
			value : $('#scantime').val(), 
			element : $('#scantime')[0],
			param : null, 
			errParam : $.l10n.__("Preference_itunes_text_interval")
		}*/);
	}

	return validateFields(fields);
}
