﻿$(function(){
	window.App="Preference";
	loadLang();	
	setCalendar();
	loadData();
	bindEvent();
});


function setCalendar(){	
	$.datepicker.setDefaults($.extend({showMonthAfterYear: false}, $.datepicker.regional['']));
	$("#datepicker").datepicker({
		altField: '#date'
		//,dateFormat:"mm/dd/yy"
	}).datepicker('option',{dateFormat:'yy-mm-dd'});//,$.datepicker.regional[window.top.Lang]
	$("#ui-datepicker-div").hide();
}


function loadData(){
	loadDate();
	loadZones();
	loadNTP();
}


//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){	
	$("#SETDATE").click(function(){	setDatetime();	});
	$("#SETZONE").click(function(){	setZone();	});
	$("#SETSYNC").click(function(){	setSync();	});
}



function loadDate(){
		$("#waiting").show();
		$.ajax({
		   url: window.top.remoteDataUrl+"nas/get/date"
		   ,cache:false
		   ,type: "POST"
		   ,data: {
			   hash:window.top.SessionID
			}
		   ,dataType: "xml"
		   ,success: function(data){
			   //date=05/25/10 09:17:07 CST
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
				var d=$("date",data).text().split(' ');
				$("#date").val(d[0]);
				$("#time").val(d[1]);
				$("#datepicker").datepicker( "setDate", new Date(d[0].replace(/\-/g,'/')));
				window.top.loadNASinfo();
			}
		   ,error: function(data) {
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}
		   //,timeout: 10000
		 });
}

function loadZone(){	
		$("#waiting").show();
		$.ajax({
		   url: window.top.remoteDataUrl+"nas/get/zone"
		   ,cache:false
		   ,type: "POST"
		   ,data: {
			   hash:window.top.SessionID
			}
		   ,dataType: "xml"
		   ,success: function(data){
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
				$("#timezone").val($("zone",data).text());
			}
		   ,error: function(data) {
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}
		   //,timeout: 10000
		 });
}

function loadZones(){	
		$("#waiting").show();
		$.ajax({
		   url: window.top.remoteDataUrl+"nas/get/zones"
		   ,cache:false
		   ,type: "POST"
		   ,data: {
			   hash:window.top.SessionID
			}
		   ,dataType: "xml"
		   ,success: function(data){
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
				$("zone",data).each(function(){
					$("#zones").append("<option value='"+$(this).text()+"'>"+$(this).text()+"</option>");
				});
				loadZone();
			}
		   ,error: function(data) {
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}
		   //,timeout: 10000
		 });
}


function loadNTP(){	
		$("#waiting").show();
		$.ajax({
		   url: window.top.remoteDataUrl+"nas/get/ntp"
		   ,cache:false
		   ,type: "POST"
		   ,data: {
			   hash:window.top.SessionID
			}
		   ,dataType: "xml"
		   ,success: function(data){ 
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
				$("server",data).each(function(){
					$("#ntp").append("<option value='"+$(this).text()+"'>"+$(this).text()+"</option>");
				});
			}
		   ,error: function(data) {
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}
		   //,timeout: 10000
		 });
}


function setDatetime(){	
		if(!toValidate())return;
		$("#waiting").show();
		$.ajax({
		   url: window.top.remoteDataUrl+"nas/set/date"
		   ,cache:false
		   ,type: "POST"
		   ,data: {
			   hash:window.top.SessionID
			   ,date:$("#date").val()+" "+$("#time").val()
			}
		   ,dataType: "xml"
		   ,success: function(data){ 
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
				$("server",data).each(function(){
					$("#ntp").append("<option value='"+$(this).text()+"'>"+$(this).text()+"</option>");
				});
				window.top.loadNASinfo();
			}
		   ,error: function(data) {
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}
		   //,timeout: 10000
		 });
}

function setZone(){	
		$("#waiting").show();
		$.ajax({
		   url: window.top.remoteDataUrl+"nas/set/zone"
		   ,cache:false
		   ,type: "POST"
		   ,data: {
			   hash:window.top.SessionID
			   ,zone:$("#zones").val()
			}
		   ,dataType: "xml"
		   ,success: function(data){ 
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
				loadDate();
				loadZone();
			}
		   ,error: function(data) {
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}
		   //,timeout: 10000
		 });
	
}


function setSync(){	
		$("#waiting").show();
		$.ajax({
		   url: window.top.remoteDataUrl+"nas/syncdate"
		   ,cache:false
		   ,type: "POST"
		   ,data: {
			   hash:window.top.SessionID
			}
		   ,dataType: "xml"
		   ,success: function(data){ 
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
				loadDate();
			}
		   ,error: function(data) {
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}
		   //,timeout: 10000
		 });
	
}


function toValidate(){
	var fields = [
		{
			method : 'required',
			value : $('#time').val(), 
			element : $('#time')[0],
			param : null, 
			errParam : $.l10n.__("Preference_datetime_text_time")
		},
		{
			method : 'regex',
			value : $('#time').val(), 
			element : $('#time')[0],
			param : '^([0-1][0-9]|[2][0-3]):([0-5][0-9]):([0-5][0-9])$', 
			errParam : $.l10n.__("Preference_datetime_text_time")
		}
	];

	return validateFields(fields);
}