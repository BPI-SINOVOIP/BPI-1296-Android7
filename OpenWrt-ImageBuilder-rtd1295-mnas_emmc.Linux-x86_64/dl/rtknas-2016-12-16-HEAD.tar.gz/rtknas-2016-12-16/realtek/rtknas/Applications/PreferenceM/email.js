﻿$(function(){
	window.App="Preference";
	loadLang();	
	loadData()
	bindEvent();
});



function bindEvent(){
	$("#APPLY").click(function(){	toEdit();	});
	$("#send").click(function(){	toSend();	});
	$("#ssl").click(function(){	showSSL();	});
	$("#REFRESH").click(function(){	loadData();	});
}





//-----------------------------------------------------------------------------------------------------------------------
function loadData(){	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/smtp"
		,cache:false
		,data:{
			hash:window.top.SessionID
		}
		,type: "POST"
		,dataType:"xml"		
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
		
	});
}


function parseData(data){
	var d=$(data);
	$("#host").val(d.find('host').text()); 
	if(d.find('port').text()!=='')$("#port").val(d.find('port').text()); 
	$("#user").val(d.find('user').text());
	if(d.find('ssl').text()=="yes")$("#ssl").attr("checked","checked");
	if(d.find('notify').text()=="yes")$("#notify").attr("checked","checked");
	$("#email").val(d.find('email').text());
}



//-----------------------------------------------------------------------------------------------------------------------
function toEdit(){
	if(!toValidate())return;	
	$("#waiting").show();
	var ssl=($("#ssl").attr("checked"))?"yes":"no";
	var notify=($("#notify").attr("checked"))?"yes":"no";
	$.ajax({
		url: window.top.remoteDataUrl+"nas/set/smtp"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,host:$("#host").val()
			,port:$("#port").val()
			,username:$("#user").val()
			,password:Crypt($("#pass").val(),window.top.modulus,window.top.public)
			,ssl:ssl
			,notify:notify
			,email:$("#email").val()
		}
		,type: "POST"
		,dataType:"xml"		
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
		
	});
}


//-----------------------------------------------------------------------------------------------------------------------
function toSend(){	
	if(!toValidateEmail())return;
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/send/email"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,subject:"A test Email from your NAS"
			,body:"This is a test Email from your NAS."
			//,sender:''
			,receiver:$("#email").val()
		}
		,type: "POST"
		,dataType:"xml"		
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			alert ( $.l10n.__("Preference_email_alert_sendok") );
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
		
	});
}


function showSSL(){
	var s=$("#ssl");
	if(s.is(':checked'))$("#port").val('465');
	else $("#port").val('25');
}



function toValidate(){
	var fields = [
		{
			method : 'required',
			value : $('#host').val(), 
			element : $('#host')[0],
			param : null, 
			errParam : $.l10n.__("Preference_email_text_server")
		},
		{
			method : 'required',
			value : $('#port').val(), 
			element : $('#port')[0],
			param : null, 
			errParam : $.l10n.__("Preference_email_text_port")
		},
		{
			method : 'range',
			value : $('#port').val(), 
			element : $('#port')[0],
			param : [1,65535], 
			errParam : [$.l10n.__("Preference_email_text_port"),1,65535]
		}
	];

	return validateFields(fields);
}

function toValidateEmail(){
	
	var fields = [
		{
			method : 'required',
			value : $('#email').val(), 
			element : $('#email')[0],
			param : null, 
			errParam : $.l10n.__("Preference_email_text_email")
		},
		{
			method : 'email',
			value : $('#email').val(), 
			element : $('#email')[0],
			param : null, 
			errParam : $.l10n.__("Preference_email_text_email")
		}
	];

	return validateFields(fields);
}