﻿$(function(){
	window.App="Preference";
	loadLang();	
	bindEvent();
	loadData();
});

function bindEvent(){
	$("#REFRESH").click(function(){	loadData();	});
}

//-----------------------------------------------------------------------------------------------------------------------
function loadData(){	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/info"
		,cache:false
		,data:{
			hash:window.top.SessionID
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}


function parseData(data){
	var d=$(data);	
	//var l=window.top.location.protocol+"//"+d.find('register').text()+'.'+window.top.$.l10n.__('global_link_domainname')+'/';
	var l=window.top.location.protocol+"//"+d.find('register').text();
	var a=' <a href="'+l+'" target="_blank">'+d.find('register').text()+'</a>';
	//$("#register").html(d.find('register').text()); 
	$("#register").html(a); 
	$("#hostname").html(d.find('hostname').text()); 
	$("#workgroup").html(d.find('workgroup').text());
	l="http://"+d.find('ipaddr:first').text()+'/';
	a=' <a href="'+l+'" target="_blank">'+d.find('ipaddr:first').text()+'</a>';
	$("#ipaddr").html(a);
	$("#vpnip").html(d.find('vpnip').text());
	l="http://"+d.find('upnpaddr').text()+'/';
	a=' <a href="'+l+'" target="_blank">'+d.find('upnpaddr').text()+'</a>';	
	$("#upnpaddr").html(a);
	$("#hwaddr").html(d.find('hwaddr').text());
	$("#version").html(d.find('software').text());
	//$("#package").html(d.find('package').text());
	$("#date").html(d.find('date').text());
	$("#kernel").html(d.find('kernel').text());
	/*var storage=d.find('storage');
	$("#available").html( formatBytes (storage.find('available').text()) );
	$("#used"). html( formatBytes(storage.find('used').text()) );
	$("#usedpercent").html( storage.find('usedpercent').text() );
	$("#blocks").html( formatBytes( storage.find('blocks').text() ) );*/

    var bootcode_ver = d.find('bootcode_ver').text();
    if(bootcode_ver != '' && bootcode_ver != 'None'){
        $("#bootcode").show();
        $("#bootcode_ver").html(bootcode_ver);
    }
    else{
        $("#bootcode").hide();
    }
    var audio_fw_ver = d.find('audio_fw_ver').text();
    if(audio_fw_ver != '' && audio_fw_ver != 'None'){
        $("#audio_fw").show();
        $("#audio_fw_ver").html(audio_fw_ver);
    }
    else{
        $("#audio_fw").hide();
    }
    var video_fw_ver = d.find('video_fw_ver').text();
    if(video_fw_ver != '' && video_fw_ver != 'None'){
        $("#video_fw").show();
        $("#video_fw_ver").html(video_fw_ver);
    }
    else{
        $("#video_fw").hide();
    }
    var rootap_ver= d.find('rootap_ver').text();
    if(rootap_ver!= '' && rootap_ver != 'None'){
        $("#rootap").show();
        $("#rootap_ver").html(rootap_ver);
    }
    else{
        $("#rootap").hide();
    }
}

