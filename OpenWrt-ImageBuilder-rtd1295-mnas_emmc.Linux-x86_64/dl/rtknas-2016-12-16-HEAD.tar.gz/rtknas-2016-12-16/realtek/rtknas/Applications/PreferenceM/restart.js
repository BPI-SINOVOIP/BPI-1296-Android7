﻿$(function(){
	window.urlpath=(window.location.protocol+"//"+window.location.host+window.location.pathname).replace("Applications/Preference/restart.html","");
	window.hostpath=window.location.protocol+"//"+window.location.host+'/';
	window.remoteDataUrl=getRequest("remoteDataUrl");//系统数据目录
	window.registername=getRequest('registername')
	window.SessionID=getRequest('id')
	window.Lang=getRequest('lang');
	window.App="Preference"; 
	loadLang();
	//var dl=window.location.protocol+"//"+window.registername+'.'+$.l10n.__('global_link_domainname')+'/';
	var dl=window.location.protocol+"//"+window.registername;
	window.domainlink=dl;
	$('#domainlink').html(dl);
	loadData();
	window.setTimeout(function(){
		window.setInterval( function(){toLogin();},3000);
	},30000);
});








//-----------------------------------------------------------------------------------------------------------------------
function loadData(){	
	$.ajax({
		url: window.top.remoteDataUrl+"nas/leave"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,action:'reboot'
			,time:0
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			//if(window.checkAPIError(data))return;
			//alert($('nas',data).text());
		}
		,error:function(data){
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});	
}


function toLogin(){
	$.ajax({
		url: window.remoteDataUrl+"nas/gen/hash"
		,cache:false
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			window.location=window.hostpath;
		}
		,error:function(data){
		}
	});	
	
}
