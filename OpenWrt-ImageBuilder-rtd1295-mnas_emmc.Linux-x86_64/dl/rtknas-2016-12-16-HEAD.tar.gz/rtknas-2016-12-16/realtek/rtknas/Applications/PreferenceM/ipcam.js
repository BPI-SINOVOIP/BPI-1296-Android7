﻿$(function(){
	window.App="Preference";
	loadLang();	
	loadData({hash:window.top.SessionID},"get");
	bindEvent();
});


//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){	
	$("#APPLY").click(function(){	toApply();	});
	$("#REFRESH").click(function(){	loadData();	});	
	$("#browse").click(function(){  showBrowse();   });
	$("#start").click(function(){  Start();   });
	$("#stop").click(function(){  Stop();   });
}




//解析数据函数-------------------------------------------------------------------------
function parseData(data){
//	if($('enable',data).text().toLowerCase()=='yes'){
//		$("#check").attr('checked','checked');
//	}
//	if($('enable',data).text().toLowerCase()=='no'){
//		$("#check").removeAttr('checked');
//	}
	if($('running',data).text().toLowerCase()=='yes'){
		$("#check").attr('checked','checked');
		$('#running').html('<label domain="l10n" msgid="Preference_main_text_servicerunning">'+$.l10n.__('Preference_main_text_servicerunning')+'</label>');
		// show url link to IP Camera webpage
		// window.location.host
		//$('#url_link').html("<a href='ipcam_webvlc.html?port="+$('port', data).text()+"' target='_blank'><div class='icon ext ipcam'></div></a>");
		$('#url_link').html("<a href='http://"+window.location.host+":"+$('port', data).text()+"/?action=stream' target='_blank'><div class='icon s81 ipcam'></div></a>");
		$("#resolution").val($('resolution', data).text());
		$("#port").val($('port', data).text());
		$("#recorder").show();
	}
	if($('running',data).text().toLowerCase()=='no'){
		$("#check").removeAttr('checked');
		$('#running').html('<label domain="l10n" msgid="Preference_main_text_servicestopped">'+$.l10n.__('Preference_main_text_servicestopped')+'</label>');
		$('#url_link').html("");
		$("#resolution").val("480p");
		//$("#resolution").val("1080p");
		$("#port").val("8100");
		$("#recorder").hide();
	}
	parse_recording(data);
}



//-----------------------------------------------------------------------------------------------------------------------
function loadData(){	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+'nas/get/ipcam'
		,cache:false
		,data:{hash:window.top.SessionID}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}


//-----------------------------------------------------------------------------------------------------------------------
function toApply(){
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+'nas/set/ipcam'
		,cache:false
		,data:{
			hash:window.top.SessionID
			,enable:($("#check").attr('checked'))?'yes':'no'
			,resolution:$("#resolution").val()
			,port:($("#port").val())?$("#port").val():'8100'
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( "toApply: "+$.l10n.__("global_alert_getdataerror") );
		}
	});
}

function showBrowse() {
	window.top.System.selectDir({
		app:window.top.Preference
		,handler: function(path){
			$("#path").val(   decodeURI(path) );
		}
	});
}

function parse_recording(data) {
	if($('recorder', data).text()=='yes') {
		$("#start").attr('disabled', 'disabled');
		$("#stop").removeAttr('disabled');
		$("#recording").text('Recording...');
	}
	else if($('recorder', data).text()=='no') {
		$("#stop").attr('disabled', 'disabled');
		$("#start").removeAttr('disabled');
		$("#recording").text('');
	}
	else {
		alert('get recorder status error');
	}	
}

function Start() {
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+'nas/set/ipcam'
		,cache:false
		,data:{
			hash:window.top.SessionID
			,enable:'yes'
			,play:'yes'
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parse_recording(data);
			//alert($('service', data).text());
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( "Start: "+$.l10n.__("global_alert_getdataerror") );
		}
	});
}

function Stop() {
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+'nas/set/ipcam'
		,cache:false
		,data:{
			hash:window.top.SessionID
			,enable:'yes'
			,play:'no'
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parse_recording(data);
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( "Stop: "+ $.l10n.__("global_alert_getdataerror") );
		}
	});
}


//function Watch(bbb) {
//	H.264
/*	var a = false;
	for(var i = 0 ; i < navigator.plugins.length; i++)
	{
		if(navigator.plugins[i].name == "VLC Web Plugin")
			a = true
	}
	if(a)
	{
		//alert("Found VLC Web Plugin")
		//alert("ipcam_webvlc.html?port="+running_port)
		//bbb.href = "ipcam_webvlc.html?port="+running_port;
		return true;
	}
	else
	{
		alert("Cannot detect VLC Web Plugin\nPlease make sure you're using firefox/chrome with VLC plugin installed")
		bbb.href = "javascript: void(0)";
		return false;
	}
*/
	//alert(window.location.host);
// MJPEG
/*	bbb.href = "http://"+window.location.host+":"+running_port+"/?action=stream";
	return true;*/
//}
