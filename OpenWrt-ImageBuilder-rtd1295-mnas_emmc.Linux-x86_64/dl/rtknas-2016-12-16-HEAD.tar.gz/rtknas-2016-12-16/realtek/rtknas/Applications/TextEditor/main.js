﻿$(function(){
	window.win.setTitle('Untitled');
	window.App="TextEditor";
	window.app=window.top[window.App];
	window.app=window.top[window.App];
	layout();
	bindEvent();
	loadLang();
});


function layout(){	
	$('body').layout({ 
			center__paneSelector:"#editor"
		,	north__paneSelector:"#top"  
		,	north__size:60
		,	north__spacing_open:0
		//,	center__minWidth:400
		//,	contentSelector:".data"
		//,	center__onresize_end: function(){  }
	}); 
	if(window.win.fromWinObject&&window.win.fromWinObject.path){
		toOpen(window.win.fromWinObject.path);
	}
}

function bindEvent(){
	$("#NEWWIN").click(newWin);
	$("#NEW").click(newFile);
	$("#OPEN").click(showOpen);
	$("#SAVE").click(showSave);
	$("#SAVEAS").click(showSaveAs);
	$('#editor').change(function(){$(this).addClass('unsaved');});
	window.win.beforeclose=function(){
		if($('#editor').hasClass('unsaved')){
			return confirm($.l10n.__('global_alert_unsaved'));
		}
		return true;
	}
}


function newFile(){
	if($('#editor').hasClass('unsaved')){
		if(confirm($.l10n.__('global_alert_unsaved'))){clearFile();}
		else {return;}
	}else{
		clearFile();
	}
	/*	window.top.System.confirm({
			app:window.app
			,str:''
			,yes:function(){
				showSave(true);
			}
			,no:clearFile
		});
	*/
}

function clearFile(keep){
	$('#editor').val('').removeAttr('path').data({path:null}).removeClass('unsaved').unbind('change').change(function(){$(this).addClass('unsaved');});
	window.win.setTitle('Untitled');
}


function newWin(){
	window.app.newFile();
}


function showOpen(){
	if($('#editor').hasClass('unsaved')){
		if(!confirm($.l10n.__('global_alert_unsaved'))) return;
	}
	clearFile();
	window.top.System.opendialog({
		path:''
		,filter:'*.txt|*.*'
		,single:true
		,handler:toOpen
		,app:window.app
	});
}

function showSave(create){
	if($('#editor').attr('path')){
		toSave(null,create);
	}else{
		showSaveAs(create);
	}
}



function showSaveAs(create){
	window.top.System.opendialog({
		path:''
		,type:'save'
		,filter:'*.txt|*.*'
		,single:true
		,handler:function(path){toSave(path,create);}
		,app:window.app
	});
}


function toOpen(path){
	$.get(path+'?hash='+window.top.SessionID, function(data){
		$('#editor').val(data).attr('path',path).unbind('change').change(function(){$(this).addClass('unsaved');});
		var file=path.toString().split('/');
		file=file[file.length-1];
		window.win.setTitle(decodeURI( file ) );
	});
}


function toSave(path,create){
	if(!path)path=$('#editor').attr('path');
	$('#waiting').show();
	var options={
		content: $('#editor').val()
		,content_type:  'text/plain'
	}
	var handler = {
		onComplete: function(result){
			$('#waiting').hide();
			if(result.status===201||result.status===204||result.status===1223){
				if(create===true)clearFile();
				else $('#editor').attr('path',path).data({path:path}).removeClass('unsaved').unbind('change').change(function(){$(this).addClass('unsaved');});
			}else{
				alert($.l10n.__('global_webdav_requestfail').replace('{0}', result.status).replace('{1}', result.statusstring))
			}
			var file=path.toString().split('/');
			file=file[file.length-1];
			window.win.setTitle(decodeURI( file ) );
		}
	}; 
	window.top.webdav.PUT(handler,path,options);	
}

