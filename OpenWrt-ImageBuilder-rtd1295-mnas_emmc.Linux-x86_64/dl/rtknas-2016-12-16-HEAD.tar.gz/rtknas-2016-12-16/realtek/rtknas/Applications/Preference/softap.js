﻿$(function(){
	window.App="Preference";
	loadLang();
	bindEvent();
	//loadData();
	toScan();
	loadCurrentStation(true);
	$('#DISCONNECT').hide();
	$("#ssecurity").hide();
});



//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){	
	//$("#APPLY").click(function(){	toApply();	});
	//$("#check").click(function(){	enableService();	});
	//$("#REFRESH").click(function(){	loadData();	});
	$("#SCAN").click(function(){	toScan();	});
	$("#CONNECT").click(function(){ toApplyAP(); });
	$("#DISCONNECT").click(function(){    disconnectStation();   });
	$("#spassword").click(function(){  onStatusChange(false); });
	//$("#ssecurity").click(function(){  onStatusChange(false); });
}



//-----------------------------------------------------------------------------------------------------------------------
function loadData(){	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/softap"
		,cache:false
		,data:{
			hash:window.top.SessionID
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}


function SetAsHostname(){
$.ajax({
    url: window.top.remoteDataUrl+"nas/get/hostname"
    ,cache:false
    ,data:{
        hash:window.top.SessionID
        }
    ,type: "POST"
    ,dataType:"xml"
    ,success: function(data){
        if(window.top.checkAPIError(data))return;
        var d=$(data);
	    $("#ssid").val(d.find('hostname').text()); 
    }
    ,error:function(data){
    }
});
}


function parseData(data){
	
	if($('enable',data).text().toLowerCase()=='yes'){
		$("#check").attr('checked','checked');
	}
	if($('enable',data).text().toLowerCase()=='no'){
		$("#check").removeAttr('checked');
	}
	if($('running',data).text().toLowerCase()=='yes'){
		$('#running').html('<label domain="l10n" msgid="Preference_main_text_servicerunning">'+$.l10n.__('Preference_main_text_servicerunning')+'</label>');
	}
	if($('running',data).text().toLowerCase()=='no'){
		$('#running').html('<label domain="l10n" msgid="Preference_main_text_servicestopped">'+$.l10n.__('Preference_main_text_servicestopped')+'</label>');
	}
	
	
	if($('ssid',data).text() != ''){
	    $("#ssid").val($('ssid',data).text()); 
    }
    else{
	    SetAsHostname(); 
    }
	if($('frequency',data).text() != ''){
	    $("#frequency").val($('frequency',data).text()); 
    }
    $("#channels").html("<option value='auto'>Auto</option>");
    $("channels",data).each(function(){ 
        $("#channels").append("<option value='"+$(this).text()+"'>"+$(this).text()+"</option>");
    })
	if($('channel',data).text() != ''){
	    $("#channels option[value="+$('channel',data).text()+"]").attr("selected","selected")
    }
	if($('security',data).text() != ''){
	    $("#security").val($('security',data).text()); 
    }

	$("#password").val(''); 
	enableService();
}


function toApply(){	
	if(($("#check").attr('checked'))){
	    if(!validate())return;	
	}
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/set/softap"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,enable:($("#check").attr('checked'))?'yes':'no'
			,ssid:$("#ssid").val()
			,frequency:$("#frequency").val()
			,channel:$("#channels").val()
			,security:$("#security").val()
			,password:Crypt($("#password").val(),window.top.modulus,window.top.public)
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}

function findicon(data,sec){
	/*
	 -50 ~ -75: 收訊非常好
	 -75 ~ -90: 收訊不錯
	 -90 ~ -110: 收訊普通
	 -110 ~~~: 收訊很糟或是沒訊號
	 */
	var ret="";
	if(data > -75) {ret = "\'signal-3";}
	else if(data > -90) {ret = "\'signal-2";}
	else if(data > -110) {ret = "\'signal-1";}
	else {ret = "\'signal-0";}

	if(sec!=null&&sec.indexOf("wpa") > -1){
		ret += "_wpa\'";
	}
	else{
		ret += "\'";
	}

	return ret;
}

function parseApList(data){
	$("#aplist").empty();

	result_ssid=[];
	result_signal=[];
	result_security=[];
	var icon="";

	$("ssid",data).each(function(){
		result_ssid.push($(this).text());
        })
	
	$("signal",data).each(function(){
    		result_signal.push($(this).text());
        })

	$("security",data).each(function(){
		result_security.push($(this).text());
	})

	for(i=0; i<result_ssid.length; i++){
        	icon = findicon(result_signal[i], result_security[i]);
        	$("#aplist").append("<li class='apOption'><a class="+ icon+" onclick='show_security()'>"+result_ssid[i]+"</a></li>");
	}

	var apoption = $('#aplist').find('li');
	apoption.click(function(e) {
		$("#aplist").animate({height: "150px"});
	  	apoption.removeClass('currentApTarget');
	  	$(this).addClass('currentApTarget');
	  	var apname = $(this).find('a')[0].innerText;
	  	$('#sssid').val(apname);
	  	if($('a',this)[0].className.indexOf('wpa')>-1){
			$("#ssecurity").val('wpa');
			$("#spassword").show();
		}
		else{
			$("#ssecurity").val('none');
			toApplyAP();
		}
	});

	$("#currentstationname").fadeIn();
	$("#security").fadeOut();
	$("#aplist").animate({height: "240px"});
}

function toScan(){
        $("#waiting").show();
        $.ajax({
                url: window.top.remoteDataUrl+"nas/get/aplist"
                ,cache:false
                ,data:{
                        hash:window.top.SessionID
                        }
                ,type: "POST"
                ,dataType:"xml"
                ,success: function(data){
                        $("#waiting").hide();
                        if(window.top.checkAPIError(data))return;
                        parseApList(data);
                }
                ,error:function(data){
                        $("#waiting").hide();
                        alert ( $.l10n.__("global_alert_getdataerror") );
                }
        });
}

function showCurrentStation(data, init){
	init = init || false;
	if($('ssid',data).text() != ''){
                $("#currentstationname").text($('ssid',data).text());
                onStatusChange(true);
	}
	else{
		if(init)
			reconnect();
		else
                	$("#currentstationname").text("Disconnected");
	}

	$("#currentStation").fadeIn();
	$("#security").fadeOut();
	$("#aplist").animate({height: "240px"});
}

function loadCurrentStation(init){
	$("#waiting").show();
        $.ajax({
                url: window.top.remoteDataUrl+"nas/get/station"
                ,cache:false
                ,data:{
                        hash:window.top.SessionID
                        }
                ,type: "POST"
                ,dataType:"xml"
                ,success: function(data){
                        $("#waiting").hide();
                        if(window.top.checkAPIError(data))return;
			showCurrentStation(data, init);
                }
                ,error:function(data){
                        $("#waiting").hide();
                        alert ( $.l10n.__("global_alert_getdataerror") );
                }
        });

}

function disconnectStation(){
	$("#waiting").show();
        $.ajax({
                url: window.top.remoteDataUrl+"nas/set/station"
                ,cache:false
                ,data:{
                        hash:window.top.SessionID
                        ,enable:'no'
                        }
                ,type: "POST"
                ,dataType:"xml"
                ,success: function(data){
                        $("#waiting").hide();
                        if(window.top.checkAPIError(data))return;
			window.setTimeout(function(){
				loadCurrentStation(false);
				onStatusChange(false);
			}
			, 1000);
                }
                ,error:function(data){
                        $("#waiting").hide();
                        alert ( $.l10n.__("global_alert_getdataerror") );
                }
        });
}

function enableService(){
	if(($("#check").attr('checked'))){
		$("table input").removeAttr('disabled');
	}
	else{
		$("table input").attr('disabled','disabled');
	}
}


function validate(){
	var fields = [];
	
	if($("#check").length !== 0){
		if($("#check").attr('checked')){
			fields.push({
				method : 'required',
				value : $('#ssid').val(),
				element : $('#ssid')[0],
				param : null, 
				errParam : $.l10n.__("Preference_dlna_text_servername")
			});

			if($("#security").val() != 'none'){
				fields.push({
					method : 'required',
					value : $('#password').val(),
					element : $('#password')[0],
					param : null,
					errParam : $.l10n.__("global_text_password")
				});
			}
			if($("#security").val() != 'none'){
					fields.push({
					method : 'rangelength',
					value : $('#password').val(),
					element : $('#password')[0],
					param : [8,63],
					errParam : [$.l10n.__('global_text_password'),8,63]
				});
			}
		}
	}

	fields.push({
		method : 'required',
		value : $('#sssid').val(),
		element : $('#sssid')[0],
		param : null,
		errParam : $.l10n.__("Preference_dlna_text_servername")
	});

	/*
	if($("#ssecurity").val() != 'none'){
		fields.push({
			method : 'required',
			value : $('#spassword').val(),
			element : $('#spassword')[0],
			param : null,
			errParam : $.l10n.__("global_text_password")
		});
	}

	if($("#ssecurity").val() == 'wpa'){
		fields.push({
			method : 'rangelength',
			value : $('#spassword').val(),
			element : $('#spassword')[0],
			param : [8,63],
			errParam : [$.l10n.__('global_text_password'),8,63]
		});
	}
	*/
	return validateFields(fields);
}

function toApplyAP(){
	if($('#sssid').val() === ""){
		show_security();
		return;
	};
	if(!validate())return;
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/set/station"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,ssid:$("#sssid").val()
			,security:$("#ssecurity").val()
			,password:Crypt($("#spassword").val(),window.top.modulus,window.top.public)
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			showCurrentStation(data);
			onStatusChange(true);
			$('#sssid').val("");
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}

function reconnect(){
	$("#waiting").show();
        $.ajax({
                url: window.top.remoteDataUrl+"nas/set/reconnect"
                ,cache:false
                ,data:{
                        hash:window.top.SessionID
                        }
                ,type: "POST"
                ,dataType:"xml"
                ,success: function(data){
                        $("#waiting").hide();
                        if(window.top.checkAPIError(data))return;
			showCurrentStation(data);
                }
                ,error:function(data){
                        $("#waiting").hide();
                        alert ( $.l10n.__("global_alert_getdataerror") );
                }
        });
}

function show_security() {
	$("#aplist").animate({height: "150px"});
	$("#currentstationname").val();
	$("#security").fadeIn();
	//$("#ssecurity").val('wpa');
	$("#spassword").val('');
};

function onStatusChange(connect) {
	if (connect === true) {
		$('#CONNECT').hide();
		$('#DISCONNECT').show();
	} else{
		$('#DISCONNECT').hide();
		$('#CONNECT').show();
	}
};
