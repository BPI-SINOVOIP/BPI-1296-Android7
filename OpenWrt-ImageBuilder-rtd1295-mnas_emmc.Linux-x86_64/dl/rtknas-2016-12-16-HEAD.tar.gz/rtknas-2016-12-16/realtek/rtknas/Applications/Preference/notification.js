﻿$(function(){
	window.App="Preference";
	loadLang();
	bindEvent();
	loadData();
});

function bindEvent(){
	$("#REFRESH").click(function(){	loadData();	});
	$("#CLEAR").click(function(){	clearData();	});
}

//-----------------------------------------------------------------------------------------------------------------------
function loadData(){
	$("#waiting").show();
	var url = window.top.document.URL;
	url = url.split("lang=");
	var query = url[1].split("&")	// split string 'en-us&id=...&...' into 'en-us', 'id=...', etc.
	$.ajax({
		url: window.top.remoteDataUrl+"nas/query/event_notify"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,lang:query[0]
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}


function clearData(){
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/clear/event_notify"
		,cache:false
		,data:{
			hash:window.top.SessionID
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}


function parseData(data){
	var d=$(data);
	var tmp = d.find('log').text();
	if(tmp == "")
		tmp=$.l10n.__('Preference_notification_text_empty');
	$("#log").html('<pre>'+tmp+'</pre>');
}

