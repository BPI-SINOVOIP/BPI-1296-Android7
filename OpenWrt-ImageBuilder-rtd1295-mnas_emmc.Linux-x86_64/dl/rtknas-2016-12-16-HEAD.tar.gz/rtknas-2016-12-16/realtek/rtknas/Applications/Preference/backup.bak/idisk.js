﻿$(function(){
	window.App="Preference";
	loadLang();	
	bindEvent();
	loadData();
});



//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){
	$("#APPLY").click(function(){	toApply();	});
	$("#browse").click(function(){	showBrowse();	});	
	$("#REFRESH").click(function(){	loadData();	});
}



//-----------------------------------------------------------------------------------------------------------------------
function loadData(){	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/idisk"
		,cache:false
		,data:{
			hash:window.top.SessionID
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}



function parseData(data){
	if($('enable',data).text().toLowerCase()=='true'){
		$("#check").attr('checked','checked');
		$('#running').html('<label domain="l10n" msgid="Preference_main_text_servicerunning">'+$.l10n.__('Preference_main_text_servicerunning')+'</label>');
	}
	else{
		$("#check").removeAttr('checked');
		$('#running').html('<label domain="l10n" msgid="Preference_main_text_servicestopped">'+$.l10n.__('Preference_main_text_servicestopped')+'</label>');
	}
	$("#folder").val( syspathToDavpath ( $('directory',data).text() ) ); 
}

function toApply(){	
	if(!validate())return;	
	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/set/idisk"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,enable:($("#check").attr('checked'))?'yes':'no'
			,directory:'/dav'+$("#folder").val()
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}

function showBrowse(){
	window.top.System.selectDir({
		app:window.top.Preference
		,handler: function(path){
			$("#folder").val(   decodeURI  (path  ) );

		}
	}); 
}




function validate(){	
	if(!$("#check").attr('checked')) return true;	
	var fields = [];
		fields.push({
			method : 'required',
			value : $('#folder').val(), 
			element : $('#folder')[0],
			param : null, 
			errParam : $.l10n.__("Preference_idisk_text_folder")
		});

	return validateFields(fields);
}