﻿$(function(){
	window.App="Preference";
	loadLang();
	loadData()
	bindEvent();
});



function bindEvent(){
	$("#APPLY").click(function(){	toEdit();  });
	$("#send").click(function(){	toSend();	});
	$("#ssl").click(function(){	showSSL();	}); //been triggered on each click
//	$("#ssl").change(function(){	showSSL();	}); //been triggered on value changed
	$("#mail_server_setting").click(function(){	showSERVER(); }); //been triggered on each click
	$("#REFRESH").click(function(){	loadData(); });
	$("#CLEAR").click(function(){	toClear(); });
	$("#gmail_xoauth2").click(function(){  takeGmail(); });
}

//-----------------------------------------------------------------------------------------------------------------------
function loadData(){
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/smtp"
		,cache:false
		,data:{
			hash:window.top.SessionID
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000

	});

	//if refresh, the show the 'Current' option
	var s=$("#mail_server_setting");
	s.val("Current");

	//show host/port/ssl and not allow to be changed
	$("#row_host_port").css('visibility','visible');
	$("#row_ssl").css('visibility','visible');

	//all input are not allow to be changed in 'Current" option
	//jQuery version < 1.9 : use .attr('readonly',true)
	//               >= 1.9 : use prop('readonly',true)
	$("#user").attr('readonly',true);
	$("#pass").attr('readonly',true);
	$("#host").attr('readonly',true);
	$("#port").attr('readonly',true);
	$("#ssl").attr('disabled',true);//for select type

	//set the text color as gray (hint user that these is readonly)
	$("#user").css('color', 'gray');
	$("#pass").css('color', 'gray');
	$("#host").css('color', 'gray');
	$("#port").css('color', 'gray');

}


function parseData(data){
	var d=$(data);

	$("#email_lang").val(d.find('email_lang').text());

	$("#host").val(d.find('host').text());
	if(d.find('port').text()!=='') $("#port").val(d.find('port').text());
	else $("#port").val('25');
	$("#user").val(d.find('user').text());
	$("#pass").val(d.find('pass').text());

	/*
	if(d.find('ssl').text()=="yes") $("#ssl").attr("checked","checked");
	else $("#ssl").removeAttr("checked");
	*/
	$("#ssl").val("Disable");//default is Disable
	if(d.find('ssl').text()=="Disable") $("#ssl").val("Disable");
	if(d.find('ssl').text()=="SSL") $("#ssl").val("SSL");
	if(d.find('ssl').text()=="STARTTLS") $("#ssl").val("STARTTLS");

	if(d.find('notify').text()=="yes") $("#notify").attr("checked","checked");
	else $("#notify").removeAttr("checked");
	$("#email").val(d.find('email').text());


	the_state = d.find('state').text();
	$("#state").val(the_state);

	the_redirect_uri = d.find('redirect_uri').text();
	$("#redirect_uri").val(the_redirect_uri);

	the_url = d.find('request_url').text();
	$("a").attr('href',the_url); //there is only one a link in this web page

	the_has_token = d.find('has_token').text();
	if (($("#host").val() == "smtp.gmail.com") && (the_has_token == 'no')){
		if (($("#user").val() != '') && ($("#pass").val() != ''))//account name and account password are ready
			$("#gmail_link").css('visibility','visible');
		else
		$("#gmail_link").css('visibility','hidden');
	}
	else
	{
		$("#gmail_link").css('visibility','hidden');
	}

}


//-----------------------------------------------------------------------------------------------------------------------
function toClear(){
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/clear/smtp"
		,cache:false
		,data:{
			hash:window.top.SessionID
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			loadData();
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});

}

//-----------------------------------------------------------------------------------------------------------------------
function toEdit(){
	if(!toValidate())return;
	$("#waiting").show();
	//var ssl=($("#ssl").attr("checked"))?"yes":"no";
	var notify=($("#notify").attr("checked"))?"yes":"no";
	var url = window.top.document.URL;
	url = url.split("lang=");
	var query = url[1].split("&")	// split string 'en-us&id=...&...' into 'en-us', 'id=...', etc.
	$.ajax({
		url: window.top.remoteDataUrl+"nas/set/smtp"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,mail_server_setting:$("#mail_server_setting").val()
			,email_lang:$("#email_lang").val()
			,host:$("#host").val()
			,port:$("#port").val()
			,username:$("#user").val()
			,password:Crypt($("#pass").val(),window.top.modulus,window.top.public)
			,ssl:$("#ssl").val()
			,notify:notify
			,email:$("#email").val()
			,lang:query[0]
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data)){loadData(); return};
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000

	});
}


//-----------------------------------------------------------------------------------------------------------------------
function toSend(){
	if(!toValidateEmail())return;
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/test/email"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,subject:"A test Email from your NAS"
			,body:"This is a test Email from your NAS."
			//,sender:''
			,receiver:$("#email").val()
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			alert ( $.l10n.__("Preference_email_alert_sendok") );
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000

	});
}


function showSSL(){
	var s=$("#ssl");
	/*
	if(s.is(':checked'))$("#port").val('465');
	else $("#port").val('25');*/

	//default value is 25
	$("#port").val('25');

	if (s.val() == "SSL") {
		$("#port").val('465');
	}
	else if (s.val()=="STARTTLS") {
		$("#port").val('587');
	}

}

function showSERVER(){
	var s=$("#mail_server_setting");
	/*
	if(s.is(':checked'))$("#port").val('465');
	else $("#port").val('25');*/

	if (s.val() == "Current") {
		loadData();
		//show host/port/ssl and not allow to be changed
		$("#row_host_port").css('visibility','visible');
		$("#row_ssl").css('visibility','visible');

		//all input are not allow to be changed in 'Current" option
		//jQuery version < 1.9 : use .attr('readonly',true)
		//               >= 1.9 : use prop('readonly',true)
		$("#user").attr('readonly',true);
		$("#pass").attr('readonly',true);
		$("#host").attr('readonly',true);
		$("#port").attr('readonly',true);
		$("#ssl").attr('disabled',true);//for select type

		//set the text color as gray (hint user that these is readonly)
		$("#user").css('color', 'gray');
		$("#pass").css('color', 'gray');
		$("#host").css('color', 'gray');
		$("#port").css('color', 'gray');

	}
	else {
		//default values
		$("#host").val('');
		$("#port").val('465');
		$("#ssl").val('SSL');
		$("#user").val('');
		$("#pass").val('');

		//allow to be changed
		//jQuery version < 1.9 : use .attr('readonly',false)
		//               >= 1.9 : use prop('readonly',false)
		$("#user").attr('readonly',false);
		$("#pass").attr('readonly',false);
		$("#host").attr('readonly',false);
		$("#port").attr('readonly',false);
		$("#ssl").attr('disabled',false);//for select type

		//set the text color as black (hint user that these is changable)
		$("#user").css('color', 'black');
		$("#pass").css('color', 'black');
		$("#host").css('color', 'black');
		$("#port").css('color', 'black');


		//no show the host/port/ssl for the default mail server except 'Others'
		$("#row_host_port").css('visibility','hidden');
		$("#row_ssl").css('visibility','hidden');

		if (s.val() == "Gmail") {
			$("#host").val('smtp.gmail.com');
		}
		else if (s.val()=="Yahoo") {
			$("#host").val('smtp.mail.yahoo.com');
		}
		else if (s.val()=="Outlook") {
			$("#host").val('smtp-mail.outlook.com');
			$("#port").val('587');
			$("#ssl").val('STARTTLS');
		}
		else if (s.val()=="Others") {
			$("#row_host_port").css('visibility','visible');
			$("#row_ssl").css('visibility','visible');
		}

		//hide the gmail link 
		$("#gmail_link").css('visibility','hidden');
	}

}

//-----------------------------------------------------------------------------------------------------------------------
function takeGmail(){
	$("#waiting").show();
	var url = window.top.document.URL;
	url = url.split("lang=");
	var query = url[1].split("&")	// split string 'en-us&id=...&...' into 'en-us', 'id=...', etc.
	$.ajax({
		url: window.top.remoteDataUrl+"nas/take/smtp"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,state:$("#state").val()
			,redirect_uri:$("#redirect_uri").val()
			,lang:query[0]
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000

	});

}


function toValidate(){
	var fields = [
		{
			method : 'required',
			value : $('#host').val(),
			element : $('#host')[0],
			param : null,
			errParam : $.l10n.__("Preference_email_text_server")
		},
		{
			method : 'required',
			value : $('#port').val(),
			element : $('#port')[0],
			param : null,
			errParam : $.l10n.__("Preference_email_text_port")
		},
		{
			method : 'range',
			value : $('#port').val(),
			element : $('#port')[0],
			param : [1,65535],
			errParam : [$.l10n.__("Preference_email_text_port"),1,65535]
		}
	];

	return validateFields(fields);
}

function toValidateEmail(){

	var fields = [
		{
			method : 'required',
			value : $('#email').val(),
			element : $('#email')[0],
			param : null,
			errParam : $.l10n.__("Preference_email_text_email")
		},
		{
			method : 'email',
			value : $('#email').val(),
			element : $('#email')[0],
			param : null,
			errParam : $.l10n.__("Preference_email_text_email")
		}
	];

	return validateFields(fields);
}
