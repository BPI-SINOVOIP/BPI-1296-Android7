﻿$(function(){
	window.App="Preference";
	loadLang();	
	layout();
	bindEvent();
	loadData();
});


function layout(){
	$('body').layout({ 
			center__paneSelector:"#main"
		,	west__paneSelector:"#left" 
		,	west__size:200
		,	west__spacing_open:0
		,	south__paneSelector:"#bottom"  
		,	south__size:60
		,	south__spacing_open:0
		,	contentSelector:".data"
	}); 

}


//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){	
	$("#REFRESH").click(function(){ loadData(); });
	$("#ADD").click(function(){ prepareAdd(); });
	$("#DELETE").click(function(){ toDelete(); });
	$("#SAVE").click(function(){ toSave(); });
	
}



function loadData(){
		$("#waiting").show();
		$.ajax({
		   url: window.top.remoteDataUrl+"nas/get/users"
		   ,cache:false
		   ,type: "POST"
		   ,data: {
			   hash:window.top.SessionID
			   //,user:window.top.user
			   //,date:new Date()
			}
		   ,dataType: "xml"
		   ,success: function(data){
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
				show(data);
			}
		   ,error: function(data) {
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}
		   //,timeout: 10000
		 });
}


function show(data){
	var ul = document.createElement('ul');
	$(ul).css("width", "500px");
	ul.className="normallist user";
	$("user",data).each(function (){
		var li = document.createElement('li');
		var a = document.createElement('a');
		
		var username=$("name",this).text();
		//var privilege=$("privilege",this).text();
		//var fullname=$("fullname",this).text();
		//var lastlogin=$("lastlogin",this).text();
		
		
		a.data={
			username:username
			//,privilege:privilege
			//,fullname:fullname
			//,lastlogin:lastlogin
		};
		
		
		a.innerHTML=username;
		$(li).append(a).appendTo(ul);
		
		$(a).click(function(){
			if(this.innerHTML=="admin"){
				$('#DELETE').hide();
				$('#old,#ADD').show();
			}
			else{
				$('#DELETE,#ADD	').show();
				$('#old').hide();
			}
			$("a.selected",ul).removeClass("selected");
			$(this).addClass("selected");
			$("#username").attr('disabled','disabled').val(this.data.username);
			$("#oldpassword").val('');
			$("#password,#confirmpassword").val("");
			//$("#privilege option[value="+this.data.privilege+"]").attr("selected","selected");
		});
		
		$('a:first',ul).click();
	});
	$("#userlist").html("").append(ul);
}


function prepareAdd(){
	$("#old, #ADD, #DELETE").hide();
	$("#userlist a.selected").removeClass('selected');
	$("#username").removeAttr('disabled').attr('placeholder','Input username here!').val('');
	$("#oldpassword, #password, #confirmpassword").val('');
}



function toSave(){
		if($("#userlist a.selected").length==0)toAdd();
		else toEdit();

}

function toAdd(){
	if(!validate())return;
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/add/user"
		,cache:false
		,data:{
			username:$("#username").val()
			,password:Crypt($("#password").val(),window.top.modulus,window.top.public)
			//,privilege:$("#privilege").val()
			,hash:window.top.SessionID
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			show(data);
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
	});
}

function toEdit(){
	if(!validate())return;
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/edit/user"
		,cache:false
		,data:{
			username:$("#username").val()
			,password:Crypt($("#oldpassword").val(),window.top.modulus,window.top.public)
			,newpassword:Crypt($("#password").val(),window.top.modulus,window.top.public)
			//,privilege:$("#privilege").val()
			,hash:window.top.SessionID
			//,time:new Date()
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			//loadData();
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
	});
	
}

function toDelete(){
	if($("#userlist a.selected").length==0)return;
	if(confirm($.l10n.__('Preference_accounts_alert_delteuser'))){
		$("#waiting").show();
		$.ajax({
			url: window.top.remoteDataUrl+"nas/del/user"
			,cache:false
			,data:{
				username:$("#username").val()
				,hash:window.top.SessionID
				//,privilege:$("#privilege").val()
				//,time:new Date()
			}
			,type: "POST"
			,dataType:"xml"
			,success: function(data){
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
				delFolder($("#username").val());
				show(data);
			}
			,error:function(data){
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}		
		});
	}
}



//---------------------------------------验证---------------------------------------------------------
function validate(){
	var fields = [
		{
			method : 'required',
			value : $('#username').val(), 
			element : $('#username')[0],
			param : null, 
			errParam : $.l10n.__('global_text_username')
		},
		{
			method : 'regex',
			value : $('#username').val(), 
			element : $('#username')[0],
			param : '^[A-Za-z_][A-Za-z0-9_-]*$',
			errParam : $.l10n.__('global_text_username')
		},
		{
			method : 'required',
			value : $('#password').val(), 
			element : $('#password')[0],
			param : null, 
			errParam : $.l10n.__('global_text_password')
		},
		{
			method : 'rangelength',
			value : $('#password').val(), 
			element : $('#password')[0],
			param : [1,16], 
			errParam : [$.l10n.__('global_text_password'),1,16]
		},
		{
			method : 'equalTo',
			value : $('#confirmpassword').val(), 
			element : $('#confirmpassword')[0],
			param : $('#password').val(),
			errParam : [$.l10n.__('global_text_password'), $.l10n.__('Preference_accounts_text_cfmpass')]
		}
	];
	if($('#old').is(':visible')){
		fields.push(
			{
				method : 'required',
				value : $('#oldpassword').val(), 
				element : $('#oldpassword')[0],
				param : null, 
				errParam : $.l10n.__('Preference_accounts_text_oldpwd')
			}
		);
	}
	return validateFields(fields);
}





function delFolder(user){
	window.top.loadApp('MyNAS',function(){
		window.top.MyNAS.showProgress({
			app:window.top.Preference
			,source:window.top.root+'device/homes/'+user+'/'
			,targetpath:window.top.root+'home/.trash/'
			,sourcepath:window.top.root+'device/homes/'
			,method:'MOVE'
		});
	});
}
