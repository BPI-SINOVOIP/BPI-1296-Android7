﻿$(function(){
	window.App="Preference";
	loadLang();	
	loadData({hash:window.top.SessionID},"get");
	bindEvent();
});


//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){	
	$("#APPLY").click(function(){	toApply();	});
	$("#INITIAL").click(function(){	toInitial();	});	
	$("#YES").click(function(){	toConfirm();	});	
	$("#NO").click(function(){	toConfirmNo();	});	
}




//解析数据函数-------------------------------------------------------------------------
function parseData(data){
	if($('running',data).text().toLowerCase()=='yes'){
		$("#check").attr('checked','checked');
		$('#running').html('<label domain="l10n" msgid="Preference_main_text_servicerunning">'+$.l10n.__('Preference_main_text_servicerunning')+'</label>');
		// show url link to IP Camera webpage
		// window.location.host
	}
	if($('running',data).text().toLowerCase()=='no'){
		$("#check").removeAttr('checked');
		$('#running').html('<label domain="l10n" msgid="Preference_main_text_servicestopped">'+$.l10n.__('Preference_main_text_servicestopped')+'</label>');
	}
}



//-----------------------------------------------------------------------------------------------------------------------
function loadData(){	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+'nas/get/reset'
		,cache:false
		,data:{hash:window.top.SessionID}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}


//-----------------------------------------------------------------------------------------------------------------------
function toApply(){
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+'nas/set/reset'
		,cache:false
		,data:{
			hash:window.top.SessionID
			,enable:($("#check").attr('checked'))?'yes':'no'
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( "toApply: "+$.l10n.__("global_alert_getdataerror") );
		}
	});
}

function toInitial() {
        window.location="confirm.html";
}
function toConfirm() {
	  $("#waiting").show();
	  $.ajax({
		url: window.top.remoteDataUrl+'nas/initial/reset'
		,cache:false
		,data:{
			hash:window.top.SessionID
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			window.top.location=window.top.urlpath+'Applications/Preference/restart.html?lang='+window.top.Lang+'&registername='+window.top.NASinfo.registername+'&id='+window.top.SessionID+"&remoteDataUrl="+window.top.remoteDataUrl+'&';
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( "toInitial: "+$.l10n.__("global_alert_getdataerror") );
		}
	});
}
function toConfirmNo() {
                        window.win.closeWin();
}

