﻿$(function(){	
	window.App="Preference";
	loadLang();	
	bindEvent();
});
var newVersion=1;

//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){	
	$("#BACKUP").click(function(){toBackUp();});
	$("#UPLOAD").click(function(){toUpLoad();});	
	$("#RESTART").click(function(){toRestart();});

}


function toBackUp(){
	window.open(window.top.root+"backup?hash="+window.top.SessionID,'_blank');	
}

function toUpLoad(){
	window.top.System.toUpload(window.top.root+'restore/',true);
}

function toRestart(){
	if(confirm($.l10n.__('Preference_shutdown_text_confirmrestart'))){
		window.top.location=window.top.urlpath+'Applications/Preference/restart.html?lang='+window.top.Lang+'&registername='+window.top.NASinfo.registername+'&id='+window.top.SessionID+"&remoteDataUrl="+window.top.remoteDataUrl+'&';
	}
}

