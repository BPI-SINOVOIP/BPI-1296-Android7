﻿$(function(){	
	window.App="Preference";
	layout();
	loadData();

});


function layout(){
	window.Layout = $('body').layout({ 
			center__paneSelector:"#main" 
		,	north__paneSelector:"#top" 
		,	north__size:48
		,	north__spacing_open:0
		,	resizable:false
	}); 
	$('.ui-layout-pane').css({overflow:'hidden'});
}

function bindEvent(){
	$(".program_toolbar a").click(function(){		
		$("#Setup").show();
		$("#All").hide();
	});
	
	$("#All li").click(function(){
		var t=$("span",this).attr("msgid");
		if(t&&t!=='')window.win.setTitle("<label domain='l10n' msgid='" + t+ "'>"+$.l10n.__(t)+"</label>");
		else window.win.setTitle("<label>"+$("label",this).text()+"</label>");
		window.win.resize(720,$(this).attr("_height")-0);
	});	
	$("#SHOWALL").click(function(){	showAll();	});
	$("li").addClass('enabled');
}


function loadData(){
	$.ajax({
		url:window.top.urlpath+'Configurations/System/preferences.xml'
		,dataType:'xml'
		,success:parseData
		,error:function(){
		}
	});
}


function checkMNAS(){
$.ajax({
    url: window.top.remoteDataUrl+"nas/get/mnas"
    ,cache:false
    ,data:{
        hash:window.top.SessionID
        }
    ,type: "POST"
    ,dataType:"xml"
    ,success: function(data){
        if(window.top.checkAPIError(data))return;
        var d=$(data);
        if( d.find('enable').text() == 'yes' ){
        $('li.t20').hide();
        }
        else{
	$('li.t15').show();
        $('li.t20').show();
	$('li.t27').show();
        }
    }
    ,error:function(data){
    }
});
}


function parseData(data){
	$('items',data).each(function(){
		var id=$(this).attr('id');
		var $ul=$('#'+id+' ul');
		$('item',this).each(function(){
			var i=$('icon',this).text();
			var h=$('height',this).text();
			var n=$('name',this).text();
			var l=$(this).attr('l10n');
			var L=$(this).attr('lang');
			if(L){
				L=L.split(',');
				if($.inArray(window.top.Lang,L)===-1)return;
			}
			$ul.append('<li class="t'+i+'" _height="'+h+'"><a href="'+n+'.html" target="Setup"><img src="../../Library/blank.gif"/><br/><span ' + (l==='no'?'':'domain="l10n"  msgid="Preference_main_text_'+n+'"')   +'>'+(l==='no'?n:'')+'</span></a></li>');
		});
	});
	//if(window.top.Lang!=='zh-tw')$('li.t23').hide();
	// fw upgrade
	$('li.t15').hide();
	// SoftAP
	$('li.t20').hide();
	// Camera
	$('li.t27').hide();
	checkMNAS();

	loadLang();
	bindEvent();
}

function showAll(){
	$("#Setup").hide();
	$("#All").show();
	$("#Setup").attr('src','about:blank');
	var win=window.top.curWin;
	var t="System_application_Preference";
	window.win.setTitle("<label domain='l10n' msgid='"+t+"'>"+window.top.$.l10n.__(t)+"</label>");
	window.win.resize(720,365);
}
