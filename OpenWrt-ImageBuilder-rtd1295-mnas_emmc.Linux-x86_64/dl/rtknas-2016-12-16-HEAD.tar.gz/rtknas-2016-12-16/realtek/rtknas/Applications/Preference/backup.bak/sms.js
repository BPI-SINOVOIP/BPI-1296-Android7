﻿$(function(){
	window.App="Preference";
	loadLang();	
	loadData()
	bindEvent();
});



function bindEvent(){
	$("#APPLY").click(function(){	toApply();	});
	$("#send").click(function(){	toSend();	});
	$("#REFRESH").click(function(){	loadData();	});
}





//-----------------------------------------------------------------------------------------------------------------------
function loadData(){	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/smtp"
		,cache:false
		,data:{
			hash:window.top.SessionID
		}
		,type: "POST"
		,dataType:"xml"		
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
		
	});
}


function parseData(data){		
	$("#mobile_user").val($("mobile_user",data).text());	
	if($('mobile_notify',data).text().toLowerCase()=='yes'){
		$("#notify").attr('checked','checked');
	}
	else{
		$("#notify").removeAttr('checked');
	}
	$("#mobile_phone").val($("mobile_phone",data).text());
}



//-----------------------------------------------------------------------------------------------------------------------
function toApply(){
	if(!toValidate())return;	
	$("#waiting").show();
	var notify=($("#notify").attr("checked"))?"yes":"no";
	$.ajax({
		url: window.top.remoteDataUrl+"nas/set/smtp"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,mobile_user:$("#mobile_user").val()
			,mobile_pass:Crypt($("#mobile_pass").val(),window.top.modulus,window.top.public)
			,mobile_notify:notify
			,mobile_phone:$("#mobile_phone").val()
		}
		,type: "POST"
		,dataType:"xml"		
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
		
	});
}


//-----------------------------------------------------------------------------------------------------------------------
function toSend(){	
	if(!toValidateSMS())return;
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/send/sms"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,msg:'A test form '+window.top.user
			,dest:$('#mobile_phone').val()
		}
		,type: "POST"
		,dataType:"xml"		
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			alert ( $.l10n.__("Preference_sms_alert_sendok") );
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
		
	});
}




function toValidate(){
	var fields = [
		{
			method : 'required',
			value : $('#mobile_user').val(), 
			element : $('#mobile_user')[0],
			param : null, 
			errParam : $.l10n.__("global_text_username")
		},
		{
			method : 'required',
			value : $('#mobile_pass').val(), 
			element : $('#mobile_pass')[0],
			param : null, 
			errParam : $.l10n.__("global_text_password")
		}
	];

	return validateFields(fields);
}

function toValidateSMS(){
	
	var fields = [
		{
			method : 'required',
			value : $('#mobile_phone').val(), 
			element : $('#mobile_phone')[0],
			param : null, 
			errParam : $.l10n.__("Preference_sms_text_phone")
		}
	];

	return validateFields(fields);
}