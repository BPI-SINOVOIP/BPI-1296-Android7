﻿$(function(){
	window.urlpath=(window.location.protocol+"//"+window.location.host+window.location.pathname).replace("Applications/Preference/shutdown.html","");
	window.hostpath=window.location.protocol+"//"+window.location.host+'/';
	window.remoteDataUrl=getRequest("remoteDataUrl");//系统数据目录
	window.SessionID=getRequest('id')
	window.Lang=getRequest('lang');
	window.App="Preference";
	loadLang();	
	var dl=window.location.protocol+"//"+window.registername+'.'+$.l10n.__('global_link_domainname')+'/';
	$("#domainlink").html(dl);
	loadData();
});








//-----------------------------------------------------------------------------------------------------------------------
function loadData(){	
	$.ajax({
		url: window.top.remoteDataUrl+"nas/leave"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,action:'poweroff'
			,time:0
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			//if(window.checkAPIError(data))return;
			//alert($('nas',data).text());
		}
		,error:function(data){
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}
