﻿$(function(){
	
	window.App="DiskManager";
	loadLang();
	loadData();
	bindEvent();
	$('#CLOSE').hide();
	window.win.close.onclick = function(){};
});

function bindEvent(){
	$('#REFRESH').click(function(){loadData();});
	$('#DETAIL').click(function(){
		if($('#result').is(':hidden')){
			$('#result').show();
			window.win.resize(null,$('#content').height()+$('#result').height()+100);
		}
		else{
			$('#result').hide();
			window.win.resize(null,$('#content').height()+50);
		}
	});
	window.loadtimer=window.setInterval(loadData,2000);
}


function loadData(){	
	var object=window.win.fromWinObject;
	var path=object.path;
	$('#waiting').show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/firmware/status"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,path:path
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			if(window.top.checkAPIError(data)){
			    //window.win.close.onclick = function(){window.win.close.obj.closeWin();};
			    window.win.close.obj.closeWin();
			    return;
            }
			parseData(data, object);
		}
		,complete:function(){
			$('#waiting').hide();
		}
	});
}


function parseData(data, object){
	var retcode=$('retcode',data).text();
	var detail=$('detail',data).text();
	var processing='';
	var percent=parseInt($('percentage',data).text());
	if(isNaN(percent))percent=0;
	percent=percent+'%';
	if(retcode===''){
		//processing= $.l10n.__('Preference_shutdown_text_upgrading');
		processing= 'Verifying';
	}
	else{ 
		window.clearInterval(window.loadtimer);
		if(retcode==='0'){
			processing=$.l10n.__('DiskManager_format_done');
			percent='100%';

			if(object.func){
				window.win.close.obj.closeWin();
				object.func(object, object.file);
			}
			else toUpgrade();
		}
		else{
			processing=$.l10n.__('DiskManager_format_fail');
		}

	    $('#REFRESH').hide();
	    $('#CLOSE').click(function(){	window.win.closeWin();	});
	    $('#CLOSE').show();
		window.win.close.onclick = function(){window.win.close.obj.closeWin();};
	}
	$('#processing').html(processing);
	if(percent){
		$('#percent').html(percent);
		$('#completed').css({width:percent});
	}
	$('#result').html('<pre><code>'+detail+'</code></pre>');
}

function toUpgrade(){
	window.top.open(window.top.urlpath+'Applications/Preference/upgrading.html?sid='+window.top.SessionID+'&registername='+window.top.NASinfo.registername+'&lang='+window.top.Lang+'&remoteDataUrl='+window.top.remoteDataUrl+"&",'_top');
}
