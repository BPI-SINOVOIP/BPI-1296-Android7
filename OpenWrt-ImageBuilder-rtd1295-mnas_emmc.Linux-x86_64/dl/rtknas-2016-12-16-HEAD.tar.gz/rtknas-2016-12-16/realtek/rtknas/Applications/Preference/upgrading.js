﻿$(function(){
	window.urlpath=(window.location.protocol+"//"+window.location.host+window.location.pathname).replace("Applications/Preference/upgrading.html","");
	window.hostpath=window.location.protocol+"//"+window.location.host+'/';
	window.remoteDataUrl=getRequest("remoteDataUrl");//系统数据目录
	window.SessionID=getRequest('sid')
	window.Lang=getRequest('lang');
	window.registername=getRequest('registername')
	window.App="Preference"; 
	loadLang();
	var dl=window.location.protocol+"//"+window.registername;
	window.domainlink=dl;
	$('#domainlink').attr('href',dl).html(dl);
	
	window.setTimeout(function(){
		window.setInterval( function(){toLogin();},3000);
	},50000);
});

function toLogin(){
	$.ajax({
        url: window.remoteDataUrl+"nas/gen/hash"
		,cache:false
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			window.location=window.hostpath;
		}
		,error:function(data){
		}
	});	
	
}
