$(function(){
	window.App="Preference";
	loadLang();
	bindEvent();
	loadData();
	loadUPnPData();
});



function bindEvent(){
	$("#APPLY").click(toApply);
	$("#REFRESH").click(loadData);
	$("#uAPPLY").click(toApplyUPnP);
	$("#uREFRESH").click(loadUPnPData);
	$("#upnpauto").click(showmsg);
	$("#https_enable").click(showmsg);
}

function loadData(){
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/dyndns"
		,cache:false
		,data:{
			hash:window.top.SessionID       
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});	
}


function parseData(data){
	var hostname=[];
	$("hostname",data).each(function(){
		hostname.push($(this).text());
	});
	$("#hostname").val(hostname.join(','));
	$("#username").val($("username",data).text());
	$("#password").val($("password",data).text());

	if($('https_enable',data).text().toLowerCase()=='no'){
		$('#https_enable').removeAttr('checked');
	}else{
		$('#https_enable').attr('checked','checked');
	}

	var lastresp=$("lastresp",data).text();
	switch(lastresp){
		case 'badauth':
			$("#lastresp").html('<span domain="l10n" msgid="Preference_ddns_alert_badauth">'+$.l10n.__('Preference_ddns_alert_badauth')+'</span>');
		break;
		case 'nohost':
			$("#lastresp").html('<span domain="l10n" msgid="Preference_ddns_alert_nohost">'+$.l10n.__('Preference_ddns_alert_nohost')+'</span>');
		break;
		default:
			$("#lastresp").html(lastresp);
		break;
	}
}


function toApply(){
	if(!validate())return;
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/set/dyndns"
		,cache:false
		,data:{
			hash:window.top.SessionID,
			hostname:$("#hostname").val().split(","),
			username:$("#username").val(),
			https_enable : ($("#https_enable").attr('checked'))?'yes':'no' ,
			password:Crypt($('#password').val(),window.top.modulus,window.top.public)// $('#password').val()
			}
		,traditional:true
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			// Update register name
			window.top.loadNASinfo();
			parseData(data);
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}

function validate(){
	var fields = [
		{
			method : 'required',
			value : $('#hostname').val(), 
			element : $('#hostname')[0],
			param : null, 
			errParam : $.l10n.__("Preference_register_text_name")
		}
	];

	return validateFields(fields);
}



function loadUPnPData(){ 
    $("#waiting").show();
    $.ajax({
        url: window.top.remoteDataUrl+"nas/get/upnp"
        ,cache:false
        ,data:{
            hash:window.top.SessionID
            }
        ,type: "POST"
        ,dataType:"xml"
        ,success: function(data){
            $("#waiting").hide();
            if(window.top.checkAPIError(data))return;
            parseUPnPData(data);
        }
        ,error:function(data){
            $("#waiting").hide();
            alert ( $.l10n.__("global_alert_getdataerror") );
        }
    });
}



function parseUPnPData(data){
    var addr=$('addr',data).text();
    var port=$('port',data).text();
    var enable=$('enable',data).text();
    $("#port").val(port);
    if(addr!==''){
        window.top.NASinfo.upnp=addr+':'+port;
        $("#upnpaddr").html(window.top.NASinfo.upnp);
    }
    else{
        window.top.NASinfo.upnp='';
        $("#upnpaddr").html('no mapping');
    }
    if(enable==='yes'){
        $('#upnpauto').attr('checked','checked');
		$("#manualpm").html('');
    }
    else{
        $('#upnpauto').removeAttr('checked');
		$("#manualpm").html('<span>You need to manually set port mapping on your router if you don\'t have public IP address.</span>');
    }
}


function showmsg(){
    if($('#upnpauto').is(':checked')){
        $("#manualpm").html('');
    }
    else{
        $("#manualpm").html('<span>You need to manually set port mapping on your router if you don\'t have public IP address.</span>');
    }
}


function toApplyUPnP(){
    if(!validateUPnP())return;
    $("#waiting").show();
    $.ajax({
        url: window.top.remoteDataUrl+"nas/set/upnp"
        ,cache:false
        ,data:{
            hash:window.top.SessionID
            ,enable:($('#upnpauto').is(':checked'))?'yes':'no'
            ,port:$("#port").val()
            }
        ,type: "POST"
        ,dataType:"xml"
        ,success: function(data){
            $("#waiting").hide();
            if(window.top.checkAPIError(data))return;
            parseUPnPData(data);
        }
        ,error:function(data){
            $("#waiting").hide();
            alert ( $.l10n.__("global_alert_getdataerror") );
        }
    });
}



function validateUPnP(){
    var fields = [];
    fields.push({
        method : 'required',
        value : $('#port').val(),
        element : $('#port')[0],
        param : null,
        errParam :$.l10n.__("Preference_upnp_text_port")
    },
    {
        method : 'range',
        value : $('#port').val(),
        element : $('#port')[0],
        param : [1,65535],
        errParam : [$.l10n.__("Preference_upnp_text_port"),1,65535]
    });


    return validateFields(fields);
}

