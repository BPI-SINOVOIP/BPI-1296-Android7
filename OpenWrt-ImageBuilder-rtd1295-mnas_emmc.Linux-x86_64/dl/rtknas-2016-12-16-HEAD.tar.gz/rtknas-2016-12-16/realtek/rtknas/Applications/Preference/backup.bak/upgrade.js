﻿$(function(){	
	window.App="Preference";
	loadLang();	
	bindEvent();
	loadVersion();
});


//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){	
	if(window.win.fromWinObject==='System')$('ul.tabs').hide();
	$("#UPLOAD").click(function(){	toUpload();	});
	$("#APPLY").click(function(){	toApply();	});
	$("#UPGRADE").click(function(){	toUpgrade();	});
	$("#REFRESH").click(function(){	loadVersion();	});
}

function loadVersion(){
	$('#waiting').show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/firmware/getversion"
		,cache:false
		,data:{
			hash:window.top.SessionID
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$('#waiting').hide();
			loadAuto();
			if(window.checkAPIError(data))return;
			var c=$('current',data).text().substring(0,8)-0;
			$('#curVersion').html(c);
			var m=$('manual',data).text().substring(0,8)-0;
			var a=$('automatic',data).text().substring(0,8)-0;
			var v=Math.max(a,m);			
			if(v!=0&&v>=c)$('#newVersion').html(v);
			if(v<c||v==0)$('#UPGRADE').hide();
			else {
				$('#UPGRADE').show();
				if(v==m)$('#newVersion')[0].method=1;
				if(v==a)$('#newVersion')[0].method=0;
			}
		}
		,error:function(data){
			$('#waiting').hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});	
}


function loadAuto(){	
	$('#waiting').show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/firmware/getautoupdate"
		,cache:false
		,data:{
			hash:window.top.SessionID
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$('#waiting').hide();
			if(window.checkAPIError(data))return;
			if($('autoupdate',data).text()=='true')$('#auto').attr('checked','checked');
		}
		,error:function(data){
			$('#waiting').hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});	
}

function toApply(){
	$('#waiting').show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/firmware/setautoupdate"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,enable: $('#auto').is(':checked')?'true':'false'
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$('#waiting').hide();
			if(window.checkAPIError(data))return;			
		}
		,error:function(data){
			$('#waiting').hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});	
}


function toUpload(){	
	window.top.System.toUpload(window.top.root+'firmware/',true);
}



function toUpgrade(){
	window.top.open(window.top.urlpath+'Applications/Preference/upgrading.html?sid='+window.top.SessionID+'&registername='+window.top.NASinfo.registername+'&method='+$('#newVersion')[0].method+'&lang='+window.top.Lang+'&remoteDataUrl='+window.top.remoteDataUrl+"&",'_top');
}
