﻿$(function(){
	window.App="Preference";
	layout();
	loadLang();	
	loadData();
	bindEvent();
});

function layout(){
	$('body').layout({ 
			center__paneSelector:"#main"
		,	north__paneSelector:"#top" 
		,	north__size:32
		,	north__spacing_open:0
		,	west__paneSelector:"#left" 
		,	west__size:250
		,	west__spacing_open:0
		,	south__paneSelector:"#bottom" 
		,	south__size:80
		,	south__spacing_open:0
		,	contentSelector:".data"
	}); 
	
	$("#data").append("<table id='hostlist'></table");
	$("#hostlist").flexigrid({
		singleSelect:true
		,colModel : [
			{display: '<label domain="l10n" msgid="Preference_nfs_grid_host"></label>', name : 'host', width : 150, sortable : false, align: 'left'}
			,{display: '<label domain="l10n" msgid="global_text_readonly"></label>', name : 'readonly', width : 50, sortable : false, align: 'left'}
			,{display: '<label>insecure</label>', name : 'insecure', width : 50, sortable : false, align: 'left'}
			]
		});
	
	
	window.ip=window.top.NASinfo.ip.split('.');
	window.ip[3]="*";
	window.ip=window.ip.join('.');
}


function bindEvent(){	
	$("#ADD").click(function(){	showAdd();	});
	$("#DELETE").click(function(){	toDelete();	});
	$("#REFRESH").click(function(){	loadData();	});
	$("#SAVE").click(function(){	toSave();	});
	
	$('#addHost').click(function(){
		addRow();
	});
	$('#delHost').click(function(){
		delRow();
	});
	$('#check').click(function(){
		toEnable();
	});
}


function loadData(){
	$("#waiting").show();
	$.ajax({
	   url: window.top.remoteDataUrl+"nas/get/nfs"
	   ,cache:false
	   ,type: "POST"
	   ,data: {
		   hash:window.top.SessionID
		}
	   ,dataType: "xml"
	   ,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}
	   ,error: function(data) {
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	   //,timeout: 10000
	 });
}



function parseData(data){
	var path=$('#pathlist a.selected').attr('path');
	$('#hostlist tr').remove();
	$('#pathlist').html('<ul class="normallist item"></ul>');
	var $ul=$('#pathlist ul');
	
	if($('enable',data).text().toLowerCase()=='yes'){
		$("#check").attr('checked','checked');
	}
	if($('enable',data).text().toLowerCase()=='no'){
		$("#check").removeAttr('checked');
	}
	if($('running',data).text().toLowerCase()=='yes'){
		$('#running').html('<label domain="l10n" msgid="Preference_main_text_servicerunning">'+$.l10n.__('Preference_main_text_servicerunning')+'</label>');
	}
	if($('running',data).text().toLowerCase()=='no'){
		$('#running').html('<label domain="l10n" msgid="Preference_main_text_servicestopped">'+$.l10n.__('Preference_main_text_servicestopped')+'</label>');
	}
	
	$('directory',data).each(function(){
		var data={
			name: $('name',this).text() //syspathToDavpath ( $('name',this).text() )
			,machine:$('machine',this)
			,enable:$('enable',this)
			,running:$('running',this)
		};
		var li=document.createElement('li');
		var a=document.createElement('a');
		$(a).attr('path',data.name); //'/dav'+
		a.data=data;
		try{a.innerHTML=decodeURIComponent(data.name);}
		catch(e){a.innerHTML=data.name;}
		$(li).append(a).appendTo($ul);
	});
	
	var warning=$('warning',data).text();
	if(warning!='')alert(warning);
	
	$('#pathlist a').unbind('click').click(function(){
		$('#pathlist a.selected').removeClass('selected');
		$(this).addClass('selected');
		showData();
	});
	if(path&&path!=''){ $('#pathlist a[path='+path+']').click(); }
	else {$('#pathlist a:first').click();}
	
}


function showData(){
	$('#hostlist tr').remove();
	var data=$('#pathlist a.selected')[0].data.machine; 
	var l=data.length;
	while(l--){
		var h=$('host',data[l]).text();
		var o=$('options',data[l]).text().toLowerCase();
		var p=(o.indexOf('ro,')>-1)?'readonly':'readwrite';
		var s=(o.indexOf('insecure,')>-1)?'insecure':'secure';
		addRow(h,p,s);
	}
	
	$('#hostlist a.delete').click(function(){
		$(this.parentNode.parentNode.parentNode).remove()
	});
}

function addRow(h,p,s){
	if($('#pathlist a.selected').length==0)return;	
	if(!h){
		//var h=prompt( $.l10n.__("Preference_nfs_text_inputhost"),'');
		var h=prompt( '','');
		if(!h||h=="")return;
		h=h.replace(/\s/g,'');
	};
	if($('#hostlist tr a[host="'+h+'"]').length>0){
		alert($.l10n.__('Preference_nfs_alert_hostexist'));
		return;
	}
	if(!p)p='readwrite';
	if(!s)s='secure';
	$("#hostlist")[0].grid.addRow({
		id:''
		,host:'<a host="'+h+'">'+h+'</a>'
		,readonly:'<input type="checkbox" class="readonly" '+((p==='readonly')?'checked="checked"':'')+'>'
		,insecure:'<input type="checkbox" class="insecure" '+((s==='insecure')?'checked="checked"':'')+'>'
	});
}

function delRow(){
	if($('#hostlist tr').length<2)return;
	var trs=$('#hostlist tr.trSelected'); 
	trs.remove();
}

function showAdd(){
	window.top.System.selectDir({
		app:window.top.Preference
		,handler: function(path){
			toAdd(path);
		}
	}); 
}

function toAdd(path){
	if($('#pathlist a[path='+path+']').length>0){
		alert($.l10n.__('Preference_nfs_alert_pathexist'));
		return;
	}
	$("#waiting").show();
	$.ajax({
	   url: window.top.remoteDataUrl+"nas/set/nfs"
	   ,cache:false
	   ,type: "POST"
	   ,data: {
		   hash:window.top.SessionID
		   ,directory:'/dav'+path
		   ,host:window.ip
		   ,options:'rw,secure,async,no_root_squash,no_subtree_check'
		}
	   ,dataType: "xml"
	   ,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
			$('#pathlist a:last').click();
		}
	   ,error: function(data) {
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	   //,timeout: 10000
	 });
}

function toDelete(){
	var p=$('#pathlist a.selected');
	if(p.length!=1)return;
	if(confirm($.l10n.__('Preference_nfs_alert_deldir'))){
		var path=p.attr('path');
		$("#waiting").show();
		$.ajax({
		   url: window.top.remoteDataUrl+"nas/set/nfs"
		   ,cache:false
		   ,type: "POST"
		   ,data: {
			   hash:window.top.SessionID
			   ,directory:path
			}
		   ,dataType: "xml"
		   ,success: function(data){
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
				parseData(data);
			}
		   ,error: function(data) {
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}
		   //,timeout: 10000
		 });
	}
}

function toSave(){
	var p=$('#pathlist a.selected');
	if(p.length!=1)return;
	p='&directory='+p.attr('path');
	var h=$('#hostlist tr');
	for(var i=0,l=h.length;i<l;i++){
		var tr=h[i];
		p += '&host=' + encodeURIComponent($('a',tr).html()) + '&options=' + ($('input.readonly',tr).is(':checked')?'ro,':'rw,') + ($('input.insecure',tr).is(':checked')?'insecure,':'secure,')+'async,no_root_squash,no_subtree_check';
	}
	//p += '&enable=' + (($('#check').is(':checked'))?'yes':'no')
	$("#waiting").show();
	$.ajax({
	   url: window.top.remoteDataUrl+"nas/set/nfs"
	   ,cache:false
	   ,type: "POST"
	   ,data: 'hash='+window.top.SessionID + p
	   ,dataType: "xml"
	   ,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}
	   ,error: function(data) {
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	   //,timeout: 10000
	 });
}


function toEnable(){
	$("#waiting").show();
	$.ajax({
	   url: window.top.remoteDataUrl+"nas/set/nfs"
	   ,cache:false
	   ,type: "POST"
	   ,data: {
		   hash:window.top.SessionID
		   ,enable:(($('#check').is(':checked'))?'yes':'no')
	   }
	   ,dataType: "xml"
	   ,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}
	   ,error: function(data) {
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	   //,timeout: 10000
	 });
}


function toValidate(){
	var fields = [
		{
			method : 'required',
			value : $('#time').val(), 
			element : $('#time')[0],
			param : null, 
			errParam : $.l10n.__("Preference_datetime_text_time")
		},
		{
			method : 'regex',
			value : $('#time').val(), 
			element : $('#time')[0],
			param : '^([0-1][0-9]|[2][0-3]):([0-5][0-9]):([0-5][0-9])$', 
			errParam : $.l10n.__("Preference_datetime_text_time")
		}
	];

	return validateFields(fields);
}