﻿$(function(){
	window.App="Preference";
	loadLang();	
	loadData();
	bindEvent();
});


//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){	
	$("#APPLY").click(function(){	toApply();	});	
	$("#REFRESH").click(function(){	loadData();	});	
}



//-----------------------------------------------------------------------------------------------------------------------
function loadData(){	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/samba"
		,cache:false
		,data:{
			hash:window.top.SessionID
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}


function parseData(data){
	$("#workgroup").val($('workgroup',data).text());
	if($('enable',data).text().toLowerCase()=='yes'){
		$("#check").attr('checked','checked');
	}
	else{
		$("#check").removeAttr('checked');
	}
	if($('running',data).text().toLowerCase()=='yes'){
		$('#running').html('<label domain="l10n" msgid="Preference_main_text_servicerunning">'+$.l10n.__('Preference_main_text_servicerunning')+'</label>');
	}
	else{
		$('#running').html('<label domain="l10n" msgid="Preference_main_text_servicestopped">'+$.l10n.__('Preference_main_text_servicestopped')+'</label>');
	}

    var d=[];
	$('directory',data).each(function(){
	    d.push( syspathToDavpath ( decodeURI($(this).text()) ) );
	});
	$("#scanfolder").val(   d.join(';') );
}

function toApply(){
	if(!validate())return;	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/set/samba"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,enable:($("#check").attr('checked'))?'yes':'no'
			,workgroup:$("#workgroup").val()
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data)){loadData();return;}
			parseData(data);
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}

function validate(){
	var fields = [];
	if($("#check").attr('checked')){
		fields.push({
			method : 'required',
			value : $('#workgroup').val(), 
			element : $('#workgroup')[0],
			param : null, 
			errParam :$.l10n.__("Preference_samba_text_workgroup")
		},
		{
			method : 'regex',
			value : $('#workgroup').val(), 
			element : $('#workgroup')[0],
			param : /^[^\*\+\=\[\]\|\\\:\;\"\'\<\>\.\,\?\/]{1,32}$/, 
			errParam : $.l10n.__("Preference_samba_text_workgroup")
		});
	}

	return validateFields(fields);
}
