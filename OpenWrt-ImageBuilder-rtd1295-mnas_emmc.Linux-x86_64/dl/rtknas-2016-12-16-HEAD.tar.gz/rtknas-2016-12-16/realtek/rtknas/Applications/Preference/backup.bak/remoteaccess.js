﻿$(function(){
	window.App="Preference";
	loadLang();
	bindEvent();
	loadRegisterData();
	loadData();
	loadUPnPData();
});



function bindEvent(){
	$("#REGISTER").click(toRegister);
	$("#APPLY").click(toApply);
	$("#REFRESH").click(loadData);
	$("#uAPPLY").click(toApplyUPnP);	
	$("#uREFRESH").click(function(){loadUPnPData();loadRegisterData();});
}

function loadData(){
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/dyndns"
		,cache:false
		,data:{
			hash:window.top.SessionID
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});	
}


function loadSockproxy(){
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/sockproxy"
		,cache:false
		,data:{hash:window.top.SessionID}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			var status=$('status',data).text().toLowerCase();
			if(status==='true')$('#sockporxy').html('Connected');
			else $('#sockporxy').html('Unconnected');
		}
	});
}


function parseData(data){
	var hostname=[];
	$("hostname",data).each(function(){
		hostname.push($(this).text());
	});
	$("#hostname").val(hostname.join(','));
	$("#username").val($("username",data).text());
	$("#password").val($("password",data).text());
	var lastresp=$("lastresp",data).text();
	switch(lastresp){
		case 'badauth':
			$("#lastresp").html('<span domain="l10n" msgid="Preference_ddns_alert_badauth">'+$.l10n.__('Preference_ddns_alert_badauth')+'</span>');
		break;
		case 'nohost':
			$("#lastresp").html('<span domain="l10n" msgid="Preference_ddns_alert_nohost">'+$.l10n.__('Preference_ddns_alert_nohost')+'</span>');
		break;
		default:
			$("#lastresp").html(lastresp);
		break;
	}
}


function toApply(){
	if(!validate())return;
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/set/dyndns"
		,cache:false
		,data:{
			hash:window.top.SessionID,
			hostname:$("#hostname").val().split(","),
			username:$("#username").val(),
			password:Crypt($('#password').val(),window.top.modulus,window.top.public)// $('#password').val()
			}
		,traditional:true
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			parseData(data);
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}

function validate(){
	var fields = [
		{
			method : 'required',
			value : $('#hostname').val(), 
			element : $('#hostname')[0],
			param : null, 
			errParam : $.l10n.__("Preference_register_text_name")
		}
	];

	return validateFields(fields);
}





function loadUPnPData(){	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/upnp"
		,cache:false
		,data:{
			hash:window.top.SessionID
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseUPnPData(data);
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}



function parseUPnPData(data){
	var addr=$('addr',data).text();
	var port=$('port',data).text();
	var enable=$('enable',data).text();
	$("#port").val(port);
	if(addr!==''){
		window.top.NASinfo.upnp=addr+':'+port;
		$("#upnpaddr").html(window.top.NASinfo.upnp);
	}
	else{
		window.top.NASinfo.upnp='';
		$("#upnpaddr").html('no mapping');
	}
	if(enable==='yes')$('#upnpauto').attr('checked','checked');
	else $('#upnpauto').removeAttr('checked');
}



function toApplyUPnP(){
	if(!validateUPnP())return;	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/set/upnp"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,enable:($('#upnpauto').is(':checked'))?'yes':'no'
			,port:$("#port").val()
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseUPnPData(data);
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}


function validateUPnP(){
	var fields = [];
	fields.push({
		method : 'required',
		value : $('#port').val(), 
		element : $('#port')[0],
		param : null, 
		errParam :$.l10n.__("Preference_upnp_text_port")
	},
	{
		method : 'range',
		value : $('#port').val(), 
		element : $('#port')[0],
		param : [1,65535], 
		errParam : [$.l10n.__("Preference_upnp_text_port"),1,65535]
	});

	
	return validateFields(fields);
}



function loadRegisterData(){
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/info"
		,cache:false
		,data:{
			hash:window.top.SessionID
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			var url=$("register",data).text();
			$("#registername").val(url);
			window.top.NASinfo.registername=url;
			window.top.document.title=window.top.NASinfo.registername;
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
	loadSockproxy();		
}


//--------------------------------注册-------------------------------------------------------------
function toRegister(){
	if(!validateRegister())return;
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/register"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,name:$("#registername").val()
			,host:$.l10n.__('global_link_registerhost')
			,port:$.l10n.__('global_link_registerport')
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			window.top.NASinfo.registername=$("#registername").val();
			window.top.document.title=$("#registername").val();
			alert ( $.l10n.__("Preference_register_alert_ok") );

		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
	
	
	
}

function validateRegister(){
	var fields = [
		{
			method : 'required',
			value : $('#registername').val(), 
			element : $('#registername')[0],
			param : null, 
			errParam : $.l10n.__("Preference_register_text_name")
		},
		{
			method : 'regex',
			value : $('#registername').val(), 
			element : $('#registername')[0],
			param : '^[a-zA-Z0-9][a-zA-Z0-9-]{3,32}$', 
			errParam : $.l10n.__("Preference_register_text_name")
		}
	];

	return validateFields(fields);
}
