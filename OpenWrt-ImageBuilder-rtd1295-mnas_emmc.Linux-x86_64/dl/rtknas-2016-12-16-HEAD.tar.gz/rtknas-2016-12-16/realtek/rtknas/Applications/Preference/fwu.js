﻿$(function(){	
	window.App="Preference";
	loadLang();	
	bindEvent();
	$("#UPGRADE").hide();
	loadVersion();
});


//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){
	$("#UPGRADE").click(toUpgrade);
	$("#browse").click(showBrowse);
	$("#APPLY").click(localUpgrade);	
	$("#REFRESH").click(loadVersion);
}

function loadVersion(){
	$('#waiting').show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/firmware/getversion"
		,cache:false
		,data:{
			hash:window.top.SessionID
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$('#waiting').hide();
			if(window.checkAPIError(data))return;
			var upgrade=$('upgrade',data).text();
			var c=$('current',data).text()-0;
			var d=$('date',data).text();
			var fw_v=$('remote_ver',data).text()-0;
			var fw_d=$('remote_date',data).text();
			$('#curVersion').html(c);
			$('#curDate').html(d);
			if(upgrade.toLowerCase() != "yes"){
				$('#upgradeTr').hide();
				$("#UPGRADE").hide();
				$('#isLatest').show();
			}else {
				$('#newVersion').html(fw_v);
				$('#newDate').html(fw_d);
				$('#upgradeTr').show();
				$("#UPGRADE").show();
				$('#isLatest').hide();
			}
		}
		,error:function(data){
			$('#waiting').hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});	
}


function localUpgrade(obj, filepath){
	if(!filepath){
	if(!validate())return;	
	if(!confirm($.l10n.__('Preference_upgrade_text_warning'))) return;
        filepath = '/dav'+$("#scanfolder").val()
	}
	// Default to use upgrade mode
	//if(!confirm('All user settings will be lost!!')) return;
	window.win.close.onclick = function(){};
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/firmware/localupgrade"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,filepath:filepath
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
		    window.win.close.onclick = function(){window.win.close.obj.closeWin();};
			if(window.top.checkAPIError(data))return;

			var path = $('path',data).text();
			window.top.Preference.showVerify({path:path,win:window});

			//toUpgrade();
		}
		,error:function(data){
			$("#waiting").hide();
		    window.win.close.onclick = function(){window.win.close.obj.closeWin();};
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}

function showBrowse(){
	//window.top.System.selectDir({
	window.top.System.opendialog({
		app:window.top.Preference
		,filter:'*.img'
		,single:true
		,handler: function(path){
		    var file=path.toString().split('/dav');
		    file=file[file.length-1];
			$("#scanfolder").val(decodeURI(file));
		}
	}); 
}

function validate(){
	var fields = [];
	fields.push({
		method : 'required',
		value : $('#scanfolder').val(), 
		element : $('#scanfolder')[0],
		param : null, 
		errParam : $.l10n.__("Preference_dlna_text_folder")
	},
	{
		method : 'regex',
		value : $('#scanfolder').val(), 
		element : $('#scanfolder')[0],
		param : '^((?!;).)*$', 
		errParam : $.l10n.__("Preference_dlna_text_folder")
	});

	return validateFields(fields);
}


function toUpgrade(){
	if(!confirm($.l10n.__('Preference_upgrade_text_warning'))) return;
	// Default to use upgrade mode
	//if(!confirm('All user settings will be lost!!')) return;
	window.win.close.onclick = function(){};
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/firmware/upgrade"
		,cache:false
		,data:{
			hash:window.top.SessionID
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
		    window.win.close.onclick = function(){window.win.close.obj.closeWin();};
			if(window.top.checkAPIError(data))return;

			var path = $('path',data).text();
			var file = $('file',data).text();
			window.top.Preference.showVerify({path:path,file:file,func:localUpgrade,win:window});

			//toUpgrade();
		}
		,error:function(data){
			$("#waiting").hide();
		    window.win.close.onclick = function(){window.win.close.obj.closeWin();};
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}
