﻿$(function(){
	window.App="Preference";
	layout();
	loadLang();	
	loadData();
	bindEvent();
});

function layout(){
	$('body').layout({ 
			center__paneSelector:"#main"
		,	north__paneSelector:"#top" 
		,	north__size:32
		,	north__spacing_open:0
		,	west__paneSelector:"#left" 
		,	west__size:340
		,	west__spacing_open:0
		,	south__paneSelector:"#bottom" 
		,	south__size:80
		,	south__spacing_open:0
		,	contentSelector:".data"
	}); 

	$("#pathlist").append("<table id='sharelist'></table");
	$("#sharelist").flexigrid({
		singleSelect:true
		,colModel : [
			{display: '<label domain="l10n" msgid="global_text_name"></label>', name : 'name', width : 'auto', sortable : false, align: 'left'}
			,{display: '<label domain="l10n" msgid="Preference_dlna_text_folder"></label>', name : 'path', width : 'auto', sortable : false, align: 'left'}
			]
		});
	
	$("#data").append("<table id='servicelist'></table");
	$("#servicelist").flexigrid({
		singleSelect:true
		,colModel : [
			{display: '<label domain="l10n" msgid="Preference_dlna_text_servername"></label>', name : 'service', width : 70, sortable : false, align: 'left'}
			,{display: '<label>enable</label>', name : 'enable', width : 30, sortable : false, align: 'left'}
			,{display: '<label>Guest</label>', name : 'guest', width : 30, sortable : false, align: 'left'}
			,{display: '<label>Recycle</label>', name : 'recycle', width : 40, sortable : false, align: 'left'}
			,{display: '<label>TimeMachine</label>', name : 'tm', width : 70, sortable : false, align: 'left'}
			]
		});
	
	
	window.ip=window.top.NASinfo.ip.split('.');
	window.ip[3]="*";
	window.ip=window.ip.join('.');
}


function bindEvent(){	
	$("#ADD").click(function(){	showAdd();	});
	$("#DELETE").click(function(){	toDelete();	});
	$("#REFRESH").click(function(){	loadData();	});
	$("#SAVE").click(function(){	toSave();	});
}


function loadData(){
	$("#waiting").show();
	$.ajax({
	   url: window.top.remoteDataUrl+"nas/get/sharelist"
	   ,cache:false
	   ,type: "POST"
	   ,data: {
		   hash:window.top.SessionID
		}
	   ,dataType: "xml"
	   ,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}
	   ,error: function(data) {
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	   //,timeout: 10000
	 });
}



function parseData(data){
	$('#sharelist tr').remove();
	$('#servicelist tr').remove();
	
	$('sharelist',data).each(function(){
		var data={
			name: $('name',this).text() //syspathToDavpath ( $('name',this).text() )
			,path:$('path',this).text()
			,uuid:$('uuid',this).text()
			,comment:$('comment',this).text()
			,services:$('services',this)
			,options:$('options',this).text()
		};

		$("#sharelist")[0].grid.addRow({
			id:data.uuid
			,name:'<a>'+data.name+'</a>'
			,path:'<a>'+data.path+'</a>'
		});
		$("#sharelist tr:last").data('data',data);
	});
	
	var warning=$('warning',data).text();
	if(warning!='')alert(warning);
	
	$('#sharelist tr').unbind('click').click(function(){
		var p=$('#sharelist tr.selected')
		p.removeClass('selected');
		$('#servicelist tr').remove();
		if(p.text()!=$(this).text()){$(this).addClass('selected');showData();}
	});
	$('#sharelist tr:first').toggleClass('trSelected');
	$('#sharelist tr:first').siblings().removeClass('trSelected');
	$('#sharelist tr:first').click();
}


function showData(){
	var data=$('#sharelist tr.selected').data('data').services;
	var opts=$('#sharelist tr.selected').data('data').options;
	//alert($('#sharelist tr.selected')[0].id);
	//alert($('#sharelist tr.selected').data('data').name);
	var services=['smb','ftp','afp','minidlna'];
	services.reverse();
	var l=services.length;
	while(l--){
		var service=services[l];
		var enable=(data.text().indexOf(service)>-1)?'yes':'no';
		var guest=(opts.indexOf(service+'guest')>-1)?'yes':'no';
		var recycle=(opts.indexOf('recycle')>-1)?'yes':'no';
		var tm=(opts.indexOf('tm')>-1)?'yes':'no';
		if('smb' != service && 'afp' != service) guest='d';
		if('smb' != service) recycle='d';
		if('afp' != service) tm='d';
		addRow(service,enable,guest,recycle,tm);
	}
	$('#servicelist tr').unbind('click').click(function(e){
		var p=$('#servicelist tr.selected')
		p.removeClass('selected');
		if(p.text()!=$(this).text()){$(this).addClass('selected');}
		if (e.target.type == "checkbox") {
			p.removeClass('trSelected');
			if(p.text()!=$(this).text()){$(this).addClass('trSelected');}
		}
	});
}

function addRow(s,e,g,r,t){
	if($('#sharelist tr.selected').length==0)return;	
	if(!s)s='test';
	if(!e)e='no';
	if(!g)g='d';
	if(!r)r='d';
	if(!t)t='d';
	$("#servicelist")[0].grid.addRow({
		id:''
		,service:'<a>'+s+'</a>'
		,enable:'<input type="checkbox" class="enable" '+((e==='yes')?'checked="checked"':'')+'>'
		,guest:'<input type="checkbox" class="guest" '+((g==='yes')?'checked="checked"':(g==='d')?'disabled':'')+'>'
		,recycle:'<input type="checkbox" class="recycle" '+((r==='yes')?'checked="checked"':(r==='d')?'disabled':'')+'>'
		,tm:'<input type="checkbox" class="tm" '+((t==='yes')?'checked="checked"':(t==='d')?'disabled':'')+'>'
	});
}

function showAdd(){
	var name=prompt('Name','');
	if(!name||name=="")return;
	name=name.replace(/\s/g,'');

	$('#sharelist tr').each(function(){
		if($(this).data('data').name == name){
			alert($.l10n.__('Preference_nfs_alert_pathexist'));
			name="";
			return false;
		}
	});
	if(!name||name=="")return;

	window.top.System.selectDir({
		app:window.top.Preference
		,handler: function(path){
			toAdd(name,path);
		}
	}); 
}

function toAdd(name,path){
	$('#sharelist tr').each(function(){
		var dpath = syspathToDavpath($(this).data('data').path);
		if(dpath == path){
			alert($.l10n.__('Preference_nfs_alert_pathexist'));
			name="";
			return false;
		}
	});
	if(!name||name=="")return;

	$("#waiting").show();
	$.ajax({
	   url: window.top.remoteDataUrl+"nas/set/share"
	   ,cache:false
	   ,type: "POST"
	   ,data: {
		   hash:window.top.SessionID
		   ,action:'add'
		   ,name:name
		   ,directory:'/dav'+path
		}
	   ,dataType: "xml"
	   ,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data)){loadData();return;}
			parseData(data);
			$('#sharelist tr:last').toggleClass('trSelected');
			$('#sharelist tr:last').siblings().removeClass('trSelected');
			$('#sharelist tr:last').click();
		}
	   ,error: function(data) {
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	   //,timeout: 10000
	 });
}

function toDelete(){
	var p=$('#sharelist tr.selected');
	if(p.length!=1)return;
	if(confirm($.l10n.__('Preference_nfs_alert_deldir'))){
		var uuid=p.data('data').uuid;
		$("#waiting").show();
		$.ajax({
		   url: window.top.remoteDataUrl+"nas/set/share"
		   ,cache:false
		   ,type: "POST"
		   ,data: {
			   hash:window.top.SessionID
			   ,action:'delete'
			   ,uuid:uuid
			}
		   ,dataType: "xml"
		   ,success: function(data){
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
				parseData(data);
			}
		   ,error: function(data) {
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}
		   //,timeout: 10000
		 });
	}
}

function toSave(){
	var p=$('#sharelist tr.selected');
	if(p.length!=1)return;

	$("#waiting").show();
	var e=[];
	var opts=[];
	var h=$('#servicelist tr');
	for(var i=0,l=h.length;i<l;i++){
		var tr=h[i];
		var service=$('a',tr).text();
		if($('input.guest',tr).is(':checked')){ opts.push(service+'guest');}
		if($('input.tm',tr).is(':checked')){ opts.push('tm'); e.push('afp=yes'); }
		else
		e.push(service+'='+($('input.enable',tr).is(':checked')?'yes':'no'));
		if($('input.recycle',tr).is(':checked')){ opts.push('recycle');}
	}
	e='?'+e.join('&');
	opts=opts.join(',');
	$.ajax({
	   url: window.top.remoteDataUrl+"nas/set/service"+e
	   ,cache:false
	   ,type: "POST"
	   ,data: {
		   hash:window.top.SessionID
		   ,uuid:p.data('data').uuid
		   ,options:opts
		}
	   ,dataType: "xml"
	   ,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data)){loadData();return;}
			parseData(data);
		}
	   ,error: function(data) {
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	   //,timeout: 10000
	 });
}


function toValidate(){
	var fields = [
		{
			method : 'required',
			value : $('#time').val(), 
			element : $('#time')[0],
			param : null, 
			errParam : $.l10n.__("Preference_datetime_text_time")
		},
		{
			method : 'regex',
			value : $('#time').val(), 
			element : $('#time')[0],
			param : '^([0-1][0-9]|[2][0-3]):([0-5][0-9]):([0-5][0-9])$', 
			errParam : $.l10n.__("Preference_datetime_text_time")
		}
	];

	return validateFields(fields);
}
