﻿$(function(){
	window.App="Preference";
	loadLang();	
	loadData();
	bindEvent();
});


//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){	
	$("#APPLY").click(function(){	toApply();	});	
	$("#check").click(function(){	enableService();	});	
	$("#anony").click(function(){	enableService();	});	
	$("#REFRESH").click(function(){	loadData();	});	
}



//-----------------------------------------------------------------------------------------------------------------------
function loadData(){	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/ftpd"
		,cache:false
		,data:{
			hash:window.top.SessionID
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}


function parseData(data){
	if($('enable',data).text().toLowerCase()=='yes'){
		$("#check").attr('checked','checked');
	}else{
		$("#check").removeAttr('checked');
	}

/*	if($('force_local_data_ssl',data).text().toLowerCase()=='yes'){
		$('#ssl').attr('checked','checked');
	}else{
		$('#ssl').removeAttr('checked');
	}*/

	if($('anonymous_enable',data).text().toLowerCase()=='yes'){
		$('#anony').attr('checked','checked');
	}else{
		$('#anony').removeAttr('checked');
	}
	
	if($('running',data).text().toLowerCase()=='yes'){
		$('#running').html('<label domain="l10n" msgid="Preference_main_text_servicerunning">'+$.l10n.__('Preference_main_text_servicerunning')+'</label>');
	}else{
		$('#running').html('<label domain="l10n" msgid="Preference_main_text_servicestopped">'+$.l10n.__('Preference_main_text_servicestopped')+'</label>');
	}
	
	
	$("#port").val($('port',data).text()); 
	$("#maxclients").val($('maxclients',data).text()); 
	$("#maxperip").val($('maxperip',data).text()); 
    var d=[];
	$('directory',data).each(function(){
	    d.push( syspathToDavpath ( decodeURI($(this).text()) ) );
	});
	$("#scanfolder").val(   d.join(';') );
	enableService();
}

function toApply(){
	if(!validate())return;	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/set/ftpd"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,enable:($("#check").attr('checked'))?'yes':'no'
			//,force_anon_data_ssl: ($("#ssl").attr('checked'))?'yes':'no'
			//,force_local_data_ssl: ($("#ssl").attr('checked'))?'yes':'no'
			,anonymous_enable : ($("#anony").attr('checked'))?'yes':'no'
			,port:$("#port").val()
			,maxclients:$("#maxclients").val()
			,maxperip:$("#maxperip").val()
			,write_enable:'yes'
			//,force_local_logins_ssl :'no'
			//,force_anon_logins_ssl: 'no'
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data)){loadData();return;}
			parseData(data);
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}

function enableService(){
	if(($("#check").attr('checked'))){
		$("table input").removeAttr('disabled');
	}
	else{
		$("table input").attr('disabled','disabled');
	}
	$('#scanfolder').attr('disabled','disabled');
}


function validate(){
	var fields = [];
	if($("#check").attr('checked')){
		if($('#port').val().replace(/\s/g,'')==='80'){
			alert('Port 80 is used!');
			return false;
		}
		fields.push({
			method : 'required',
			value : $('#port').val(), 
			element : $('#port')[0],
			param : null, 
			errParam : $.l10n.__("Preference_ftp_text_port")
		},
		{
			method : 'range',
			value : $('#port').val(), 
			element : $('#port')[0],
			param : [1,65535], 
			errParam : [$.l10n.__("Preference_ftp_text_port"),1,65535]
		});
		
		fields.push({
			method : 'required',
			value : $('#maxclients').val(), 
			element : $('#maxclients')[0],
			param : null, 
			errParam : $.l10n.__("Preference_ftp_text_max")
		},
		{
			method : 'range',
			value : $('#maxclients').val(), 
			element : $('#maxclients')[0],
			param : [0,20], 
			errParam : [$.l10n.__("Preference_ftp_text_max"),0,20]
		});
		fields.push({
			method : 'required',
			value : $('#maxperip').val(), 
			element : $('#maxperip')[0],
			param : null, 
			errParam : $.l10n.__("Preference_ftp_text_perhost")
		},
		{
			method : 'range',
			value : $('#maxperip').val(), 
			element : $('#maxperip')[0],
			param : [0,5], 
			errParam : [$.l10n.__("Preference_ftp_text_perhost"),0,5]
		});
		
	}

	return validateFields(fields);
}
