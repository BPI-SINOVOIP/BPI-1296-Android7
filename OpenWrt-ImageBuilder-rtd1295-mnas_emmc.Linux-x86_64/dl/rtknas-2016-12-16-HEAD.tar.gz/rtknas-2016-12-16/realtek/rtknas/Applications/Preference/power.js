﻿$(function(){
	window.App="Preference";
	loadLang();	
	loadData();
	bindEvent();
});



//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){	
	$("#APPLY").click(function(){	toApply();	});
	$("#SAVE").click(function(){ toSave(); });
	$("#SLEEPNOW").click(function(){ toSleepNow(); });
	$("#REFRESH").click(function(){ loadData(); });
	$("#schedule1").change(function(){ selectSchedule(); });
}


function loadData(){	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/spindown/"
		,cache:false
		,data:{
			hash:window.top.SessionID
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			var s=$('seconds',data).text()-0;
			var t=$("#timeout")[0];
			if(s==0) t.selectedIndex=0;
			if(s==60) t.selectedIndex=1;
			if(s==120) t.selectedIndex=2;
			if(s==300) t.selectedIndex=3;
			if(s==600) t.selectedIndex=4;
			if(s==900) t.selectedIndex=5;
			if(s==1800) t.selectedIndex=6;

			if($('caching',data).text().toLowerCase()=='yes'){
				$('#caching').attr('checked','checked');
			}else{
				$('#caching').removeAttr('checked');
			}
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});

	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/sleeptimer"
		,cache:false
		,type: "POST"
		,data: {
			hash:window.top.SessionID
		}
		,dataType: "xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
				show(data);
		}
		,error: function(data) {
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout: 10000
	 });
}


function toApply(){
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/spindown/disk"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,timeout:$("#timeout").val()+'m'
			,caching:($("#caching").attr('checked'))?'yes':'no'
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}


function show(data){
	//alert(data);
	index = 1;	
	$("sleeptimer",data).each(function (){
		var schedule=$("schedule",this).text();
		var day=$("day",this).text();
		var sleeptime=$("down",this).text();
		var sleep_length=$("length",this).text();

		$("#schedule"+index).val(schedule);
		var someday = day.split(",");
		for(var j=0;j<someday.length;j++)
		{
			$("#"+someday[j]+index).attr('checked','checked');
		}	
		$("#sleephour"+index).val(sleeptime.split(":")[0]);
		$("#sleepminute"+index).val(sleeptime.split(":")[1]);
		$("#sleeplength"+index).val(sleep_length);

		index++;
	});
	selectSchedule();
}


function toSave(){
	arr = [];
	for(i=1;i<=1;i++)
	{
		if($("#schedule"+i).val()=="disable")
			arr[i] = {schedule:$("#schedule"+i).val()};
		else if($("#schedule"+i).val()=="day")
			arr[i] = {schedule:$("#schedule"+i).val(),down:$("#sleephour"+i).val()+":"+$("#sleepminute"+i).val(),sleeplength:$("#sleeplength"+i).val()};
		else if($("#schedule"+i).val()=="week")
		{
			days = ($("#sun"+i).attr('checked')?"sun":"")+
				($("#mon"+i).attr('checked')?",mon":"")+
				($("#tue"+i).attr('checked')?",tue":"")+
				($("#wed"+i).attr('checked')?",wed":"")+
				($("#thu"+i).attr('checked')?",thu":"")+
				($("#fri"+i).attr('checked')?",fri":"")+
				($("#sat"+i).attr('checked')?",sat":"");

			if(days.indexOf(",")==0)
				days = days.substring(1);

			if(days == "")
			{
				alert ( $.l10n.__("Preference_sleep_alert_days") );
				return;
			}

			arr[i] = {schedule:$("#schedule"+i).val(),day:days,down:$("#sleephour"+i).val()+":"+$("#sleepminute"+i).val(),sleeplength:$("#sleeplength"+i).val()};
		}
	}

	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/set/sleeptimer"
		,cache:false
		,data:{
			schedule1:arr[1].schedule
			,day1:arr[1].day
			,down1:arr[1].down
			,length1:arr[1].sleeplength
			,hash:window.top.SessionID
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			loadData();
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
	});
}


function toSleepNow(){
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/set/sleeptimer"
		,cache:false
		,data:{
			schedule:"now"
			,hash:window.top.SessionID
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			loadData();
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
	});
}


function selectSchedule(){
	//for schedule1
	if($("#schedule1").val()=="disable")
	{
		$("#day1").attr('disabled','disabled');
		$("#sun1, #mon1, #tue1, #wed1, #thu1, #fri1, #sat1").attr('disabled','disabled');
		$("#sleephour1, #sleepminute1, #sleeplength1").attr('disabled','disabled');
	}
	else if($("#schedule1").val()=="day")
	{
		$("#day1").attr('disabled','disabled');
		$("#sun1, #mon1, #tue1, #wed1, #thu1, #fri1, #sat1").attr('disabled','disabled');
		$("#sleephour1, #sleepminute1, #sleeplength1").removeAttr('disabled','disabled');
	}
	else
	{
		$("#day1").removeAttr('disabled','disabled');
		$("#sun1, #mon1, #tue1, #wed1, #thu1, #fri1, #sat1").removeAttr('disabled','disabled');
		$("#sleephour1, #sleepminute1, #sleeplength1").removeAttr('disabled','disabled');
	}
}
