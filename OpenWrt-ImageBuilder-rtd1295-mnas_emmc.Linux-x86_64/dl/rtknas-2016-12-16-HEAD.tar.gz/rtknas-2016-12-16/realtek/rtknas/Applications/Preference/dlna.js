﻿$(function(){
	window.App="Preference";
	loadLang();	
	bindEvent();
	loadData();
});



//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){	
	$("#APPLY").click(function(){	toApply();	});
	$("#check").click(function(){	enableService();	});	
	$("#REFRESH").click(function(){	loadData();	});
}



//-----------------------------------------------------------------------------------------------------------------------
function loadData(){	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/dlna"
		,cache:false
		,data:{
			hash:window.top.SessionID
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}


function SetAsHostname(){
$.ajax({
    url: window.top.remoteDataUrl+"nas/get/hostname"
    ,cache:false
    ,data:{
        hash:window.top.SessionID
        }
    ,type: "POST"
    ,dataType:"xml"
    ,success: function(data){
        if(window.top.checkAPIError(data))return;
        var d=$(data);
	    $("#servername").val(d.find('hostname').text()); 
    }
    ,error:function(data){
    }
});
}


function parseData(data){
	
	if($('enable',data).text().toLowerCase()=='yes'){
		$("#check").attr('checked','checked');
	}
	if($('enable',data).text().toLowerCase()=='no'){
		$("#check").removeAttr('checked');
	}
	if($('running',data).text().toLowerCase()=='yes'){
		$('#running').html('<label domain="l10n" msgid="Preference_main_text_servicerunning">'+$.l10n.__('Preference_main_text_servicerunning')+'</label>');
	}
	if($('running',data).text().toLowerCase()=='no'){
		$('#running').html('<label domain="l10n" msgid="Preference_main_text_servicestopped">'+$.l10n.__('Preference_main_text_servicestopped')+'</label>');
	}
	
	
	if($('strict',data).text().toLowerCase()=='yes'){
		$("#strict").attr('checked','checked');
	}else{
		$("#strict").removeAttr('checked');
	}
	if($('tivo',data).text().toLowerCase()=='yes'){
		$("#tivo").attr('checked','checked');
	}else{
		$("#tivo").removeAttr('checked');
	}
	if($('servername',data).text() != ''){
	    $("#servername").val($('servername',data).text()); 
    }
    else{
	    SetAsHostname(); 
    }
	//$("#interval").val($('interval',data).text()/60); 
	var d=[];
	$('directory',data).each(function(){
		d.push( syspathToDavpath ( decodeURI($(this).text()) ) );
	});
	$("#scanfolder").val(   d.join(';') ); 
	enableService();
}


function toApply(){	
	if(($("#check").attr('checked'))){
	    if(!validate())return;	
	}
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/set/dlna"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,enable:($("#check").attr('checked'))?'yes':'no'
			,strict:($("#strict").attr('checked'))?'yes':'no'
			,tivo:($("#tivo").attr('checked'))?'yes':'no'
			,servername:$("#servername").val()
			//,interval:$("#interval").val()*60
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data)){loadData();return;}
			parseData(data);
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}

function enableService(){
	if(($("#check").attr('checked'))){
		$("table input").removeAttr('disabled');
	}
	else{
		$("table input").attr('disabled','disabled');
	}
	$('#scanfolder').attr('disabled','disabled');
}


function validate(){
	var fields = [];

	if($("#check").attr('checked')){
		fields.push({
			method : 'required',
			value : $('#servername').val(), 
			element : $('#servername')[0],
			param : null, 
			errParam : $.l10n.__("Preference_dlna_text_servername")
		}
/*		,{
			method : 'required',
			value : $('#interval').val(), 
			element : $('#interval')[0],
			param : null, 
			errParam : $.l10n.__("Preference_dlna_text_interval")
		},
		{
			method : 'digits',
			value : $('#interval').val(), 
			element : $('#interval')[0],
			param : null, 
			errParam :  $.l10n.__("Preference_dlna_text_interval")
		}*/
		);
	}

	return validateFields(fields);
}
