﻿$(function(){
	window.App="Preference";
	loadLang();	
	loadData();
	bindEvent();
	checkMNAS();
});


function checkMNAS(){
$.ajax({
    url: window.top.remoteDataUrl+"nas/get/mnas"
    ,cache:false
    ,data:{
        hash:window.top.SessionID
        }
    ,type: "POST"
    ,dataType:"xml"
    ,success: function(data){
        if(window.top.checkAPIError(data))return;
        var d=$(data);
        if( d.find('enable').text() == 'yes' ){
	$("#network_tab").hide();
        }
    }
    ,error:function(data){
    }
});
}


//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){	
	$("button.REFRESH").click(loadData);
	$("#APPLYHOSTNAME").click(toApplyHostName);
	$("#APPLYNEWORK").click(toApplyNetwork);
	$("#checkping").click(function(){toTest('ping');});
	$("#checktraceroute").click(function(){toTest('traceroute');});
	$("#APPLYWOL").click(toApplyWoL);		// apply Wake-on-LAN
	$("#dhcp").click(function(){
			$("#ipaddr, #netmask, #gateway").attr("disabled","disabled");
			//$('#autonameserver').removeAttr("disabled");
			$("#nameserver1,#nameserver2").removeAttr("disabled");	
			//$("#autonameserver").attr('checked','checked');
			$("#nameserver1,#nameserver2").attr("disabled","disabled");
	});
	$("#manual").click(function(){
			$("#ipaddr, #netmask, #gateway").removeAttr("disabled");
			//$('#autonameserver').attr("disabled","disabled").removeAttr("checked");	
			$("#nameserver1,#nameserver2").removeAttr("disabled");	
	});
	/*$("#autonameserver").click(function(){
		if(!$(this).attr("disabled")){
			if($(this).attr("checked")){
				$("#nameserver1,#nameserver2").attr("disabled","disabled");
			}
			else{
				$("#nameserver1,#nameserver2").removeAttr("disabled");	
			}
		}
	});*/
	var dm=$.l10n.__('global_link_domainname');
	//var dl=window.top.location.protocol+"//"+window.top.NASinfo.registername+'.'+dm+'/';
	var dl=window.top.location.protocol+"//"+window.top.NASinfo.registername;
	var vpn=window.top.NASinfo.vpnip;
	if(!vpn||vpn===''){vpn=dm;}
	else { try{vpn=vpn.split('.');vpn.pop();vpn.push(1);vpn=vpn.join('.');} catch(e){vpn=dm;}}
	$("#domainlink").attr("href",dl).html(dl);
	//$('#ping').val(dm);//vpn
	//$('#traceroute').val(dm);
}

//-----------------------------------------------------------------------------------------------------------------------
function loadData(){	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/network"
		,cache:false
		,data:{
			hash:window.top.SessionID
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ($.l10n.__("global_alert_getdataerror")); 
		}
	});
}


function parseData(data){
	var d=$(data);
	$("#hostname").val(d.find('hostname').text()); 
	$("#ipaddr").val($(d.find('ipaddr')[0]).text());
	$("#netmask").val(d.find('netmask').text());	
	$("#gateway").val(d.find('gateway').text());	
	$("#nameserver1").val(d.find('dns1').text());
	$("#nameserver2").val(d.find('dns2').text());
	
	if(d.find('dhcp').text()=="yes"){
		$("#dhcp").attr("checked","checked");
		$("#dhcp").click();
	}
	else{
		$("#manual").attr("checked","checked");
		$("#manual").click();
	}
	
	/*if(d.find('autodns').text()=="yes"){
		$("#autonameserver").attr("checked","checked");
		$("#nameserver1,#nameserver2").attr("disabled","disabled");	
	}
	else{
		$("#autonameserver").attr("checked","");
		$("#nameserver1,#nameserver2").attr("disabled","");
	}*/

	// Wake-on-LAN
	if($('enableWoL',data).text().toLowerCase()=='yes'){
		$("#check").attr('checked','checked');
	}
	else{
		$("#check").removeAttr('checked');
	}
}



function toApplyNetwork(){
	if(!toValidateNetwork())return;
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/set/network"
		,cache:false
		,data:{
				hash:window.top.SessionID
				,dhcp:($("#dhcp").attr('checked'))?"yes":'no'
				,ipaddr:$("#ipaddr").val()
				,netmask:$("#netmask").val()
				,gateway:$("#gateway").val()
				,dns1:$("#nameserver1").val()
				,dns2:$("#nameserver2").val()
				//,autodns:($("#autonameserver").attr('checked'))?"yes":'no'
				
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			alert($("nas",data).text());
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ($.l10n.__("global_alert_getdataerror")); 
		}
	});
}


function toValidateNetwork(){
	/*
	if($("#dhcp").attr("checked")){
		if($("#autonameserver").attr('checked')){
			if($("#nameserver1").val()==""&&$('#nameserver2').val()=="") {
				alert( $.l10n.__('global_alert_inputerror') );
				return false;
			}
		}
	}
	else{
		if($("#ipaddr").val==""||$("#netmask").val==""||$("#gateway").val=="") {
				alert( $.l10n.__('global_alert_inputerror') );
				return false;
		}
		if($("#Preference_network_text_dns1").val()==""&&$('#Preference_network_text_dns1').val()=="") {
				alert( $.l10n.__('global_alert_inputerror') );
				return false;
		}
	}
	*/
	var fields = [];
	
	if($("#manual").attr('checked')){
		
		fields.push({
			method : 'required',
			value : $('#ipaddr').val(), 
			element : $('#ipaddr')[0],
			param : null, 
			errParam : $.l10n.__('Preference_network_text_ip')
		},
		{
			method : 'regex',
			value : $('#ipaddr').val(), 
			element : $('#ipaddr')[0],
			param : '^([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$', 
			errParam : $.l10n.__('Preference_network_text_ip')
		});
		
		fields.push({
			method : 'required',
			value : $('#netmask').val(), 
			element : $('#netmask')[0],
			param : null, 
			errParam : $.l10n.__('Preference_network_text_mask')
		}/*,
		{
			method : 'regex',
			value : $('#netmask').val(), 
			element : $('#netmask')[0],
			param : '^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}$', 
			errParam : $.l10n.__('Preference_network_text_mask')
		}*/);
		
		fields.push({
			method : 'required',
			value : $('#gateway').val(), 
			element : $('#gateway')[0],
			param : null, 
			errParam : $.l10n.__('Preference_network_text_gateway')
		},
		{
			method : 'regex',
			value : $('#gateway').val(), 
			element : $('#gateway')[0],
			param : '^([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$', 
			errParam : $.l10n.__('Preference_network_text_gateway')
		});
	//}
	// if DHCP is selected, there no need to fill in DNS servers.
	
	//if(!$("#autonameserver").attr('checked')){
		
		fields.push({
			method : 'required',
			value : $('#nameserver1').val(), 
			element : $('#nameserver1')[0],
			param : null, 
			errParam : $.l10n.__('Preference_network_text_dns1')
		},
		{
			method : 'regex',
			value : $('#nameserver1').val(), 
			element : $('#nameserver1')[0],
			param : '^([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$', 
			errParam : $.l10n.__('Preference_network_text_dns1')
		});
	}
	return validateFields(fields);
}



function toApplyHostName(){
	if(!toValidateHostName())return;
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/set/hostname"
		,cache:false
		,data:{
				hash:window.top.SessionID
				,hostname:$("#hostname").val()
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			// Update register name
			window.top.loadNASinfo();
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ($.l10n.__("global_alert_getdataerror")); 
		}
	});
}


function toTest(method){
	var v=$('#'+method).val().replace(/\s/g,'');
	if(v!=='')window.open(window.top.remoteDataUrl+method+'.cgi?host='+v+'&_='+(new Date().getTime()),'testresult');
}

function toValidateHostName(){
	var fields = [
		{
			method : 'required',
			value : $('#hostname').val(), 
			element : $('#hostname')[0],
			param : null, 
			errParam : $.l10n.__('Preference_network_text_hostname')
		},
		{
			method : 'regex',
			value : $('#hostname').val(), 
			element : $('#hostname')[0],
			// '_' is not a valid char for hostname, but '-' is.
			//param : '^[a-zA-Z0-9_]{1,32}$', 
			param : '^[a-zA-Z0-9-]{1,32}$', 
			errParam : $.l10n.__('Preference_network_text_hostname')
		}
	];
	
	return validateFields(fields);
}

function toApplyWoL(){
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/set/wol"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,enable:($("#check").attr('checked'))?'yes':'no'
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}
