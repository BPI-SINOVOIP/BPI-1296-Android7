﻿var init;
var winRef;
var myVar;
var g_name='';
var g_quota='';
var g_used='';
var g_available='';
var g_service='';
var g_uname='';
var g_st='';
var g_enable='yes';
var g_new=0;
var g_cloud='';
var g_dir='';
$(function(){
	window.App="Preference";
	loadLang();
        layout();
	loadData();
	bindEvent();
});
function layout(){
        $('body').layout({
                        center__paneSelector:"#main"
                ,       west__paneSelector:"#left"
                ,       west__size:200
                ,       west__spacing_open:0
                ,       south__paneSelector:"#bottom"
                ,       south__size:60
                ,       south__spacing_open:0
                ,       contentSelector:".data"
        });

}



//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){
	$("#pause").click(function(){g_enable='pause';	g_cloud=g_service ; toApply();	});
	$("#SAVE").click(function(){g_enable='yes'; toApply();	});
	$("#browse").click(function(){  showBrowse();   });
	$("#CANCEL").click(function(){	loadData();	});
        $("#ADD").click(function(){ toNew(); });
        $("#DELETE").click(function(){ toDelete(); });
        $("#YES").click(function(){   toConfirm();    });
        $("#OK").click(function(){ toAdd(); });

}

function show(data){
        var ul = document.createElement('ul');
        $(ul).css("width", "500px");
        ul.className="normallist user";
        $("user",data).each(function (){
                var li = document.createElement('li');
                var a = document.createElement('a');
                var taskname=$("name",this).text();
                a.data={
                        taskname:taskname
                };
                a.innerHTML=taskname;
                $(li).append(a).appendTo(ul);
                $(a).click(function(){

                        $("a.selected",ul).removeClass("selected");
                        $(this).addClass("selected");
                        $("#taskname").attr('disabled','disabled').val(this.data.taskname);
                });

                $('a:first',ul).click();
        });
        $("#userlist").html("").append(ul);
}

function userData(){
	$.ajax({
		url: window.top.remoteDataUrl+'nas/get/cloud'
		,cache:false
		,data:{hash:window.top.SessionID,add:'no'}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			if(window.top.checkAPIError(data))return;
                        $("user",data).each(function (){
                           if ($("name",this).text()===g_name)
                           {
                           g_quota=$("quota",this).text();
                           g_used=$("used",this).text();
                           g_available=$("available",this).text();
                           g_service=$("service",this).text();
                           g_uname=$("uname",this).text();
                           g_st=$("status",this).text();
        $("#quota").html(g_quota);
        $("#used").html(g_used);
        $("#available").html(g_available);
        $("#uname").html(g_uname);
        $("#service").html(g_service);
        if(g_st=='')
          $("#status").html("");
        else if(g_st=='0')
          $('#status').html('<label domain="l10n" msgid="Preference_dropbox_text_out_sync">'+$.l10n.__('Preference_dropbox_text_out_sync')+'</label>');
        else
          $("#status").html(g_st+' '+'<label domain="l10n" msgid="Preference_dropbox_text_in_sync">'+$.l10n.__('Preference_dropbox_text_in_sync')+'</label>');
                           }
                        });
		}
		,error:function(data){
//			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});

}


//解析数据函数-------------------------------------------------------------------------
function parseData(data){
      g_name='';
      $("#h_task,#h_folder,").hide();
      document.getElementById('taskname').type = 'hidden';
      document.getElementById('scanfolder').type = 'hidden';
      document.getElementById("form1").style.display = "none";
      $("#pause,#h_pause,#h_service,#h_uname,#h_status,#h_quota,#h_used,#h_available").hide();
      $("#CANCEL,#browse,#SAVE,#OK").hide();
      $("#ADD, #DELETE").show();
      $("#service,#uname,#status,#quota,#used,#available").show();
      var ul = document.createElement('ul');
      $(ul).css("width", "500px");
      ul.className="normallist synccloud";
      $("user",data).each(function (){
                var li = document.createElement('li');
                var a = document.createElement('a');
                var taskname=$("name",this).text();
                var directory=$("directory",this).text();
                var en_pause=$("en_pause",this).text();
                a.data={
                        taskname:taskname
                       ,directory:directory
                       ,en_pause:en_pause

                };
                a.innerHTML=taskname;
                $(li).append(a).appendTo(ul);
        $(a).click(function(){
          clearInterval(myVar);
          g_name=this.data.taskname;
          if (g_name!="")
          {
            g_new=1;
            $("#h_task,#h_folder,").show();
            document.getElementById('taskname').type = 'text';
            document.getElementById('scanfolder').type = 'text';
            $("#h_task,#h_folder,#pause,#h_pause,#h_service,#h_uname,#h_status,#h_quota,#h_used,#h_available").show();
          }
          userData();
          $("#taskname").attr('disabled','disabled').val(this.data.taskname);

          if($('running',this).text().toLowerCase()=='yes'){
                $("#check").attr('checked','checked');
          }
          if($('running',this).text().toLowerCase()=='no'){
                $("#check").removeAttr('checked');
          }
          if(this.data.en_pause=='yes'){
                $("#pause").attr('checked','checked');
          }
          else
                $("#pause").removeAttr('checked');

	  $("#scanfolder").val(this.data.directory);
          myVar=setInterval(function () {userData()}, 5000);
          });
      });
    $('a:first',ul).click();
    if (g_name!="")
      $("#userlist").html("").append(ul);
    else
    {
      $("#userlist").html("").remove(ul);
      toNew();
    }



}
function prepareAdd(){
        init='open';
        polling=setInterval(function () {login_win()}, 2000);
        document.getElementById('taskname').type = 'text';
        document.getElementById('scanfolder').type = 'text';
        $("#h_task,#h_folder,").show();
        $("#CANCEL,#browse,#SAVE").show();
        document.getElementById("form1").style.display = "none";
        $("#check,#pause").hide();
        $("#ADD, #DELETE,#OK").hide();
        $("#userlist a.selected").removeClass('selected');
        $("#taskname").removeAttr('disabled').val('');
        if (g_cloud=='dropbox')
           $("#scanfolder").val('/home/dropbox/');
        if (g_cloud=='google drive')
           $("#scanfolder").val('/home/gdrive/');
}
function toNew(){
        $("#OK").show();
        document.getElementById('taskname').type = 'hidden';
        document.getElementById('scanfolder').type = 'hidden';
        document.getElementById("form1").style.display = "inline";
        $("#check,#pause").hide();
        $("#ADD, #DELETE").hide();
        $("#userlist a.selected").removeClass('selected');
        $("#h_pause,#h_task,#h_folder,#h_service,#h_uname,#h_status,#h_quota,#h_used,#h_available").hide();
        $("#service,#uname,#status,#quota,#used,#available").hide();
}



//-----------------------------------------------------------------------------------------------------------------------
function loadData(){
	$.ajax({
		url: window.top.remoteDataUrl+'nas/get/cloud'
		,cache:false
		,data:{hash:window.top.SessionID,add:'no'}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}
		,error:function(data){
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}

function login_win(){
	$("#waiting").show();
        $.ajax({
                url: window.top.remoteDataUrl+"nas/get/cloud"
                ,cache:false
                ,data:{
                        hash:window.top.SessionID
                        ,add:init
                        }
                ,type: "POST"
                ,dataType:"xml"
                ,success: function(data){

                        if($('url',data).text()!='' && init=='open'){
                          winRef = window.open($('url',data).text(), "myWindow","toolbar=yes, scrollbars=yes, resizable=yes, top=500, left=500, width=500, height=500");   // Opens a new windowa
                          init='close';

                        }

                        if ($('url',data).text()=='' && init=='close')
                        {
			  $("#waiting").hide();
                          clearInterval(polling);
                          winRef.close();
                        }

                }
                ,error:function(data){
			$("#waiting").hide();
                        alert ( $.l10n.__("global_alert_getdataerror") );
                }
        });

}

function toAdd(){
    for (i = 0; i < document.getElementsByName('cloud').length; i++) {
            if (document.getElementsByName('cloud')[i].checked) {
                g_cloud = document.getElementsByName('cloud')[i].value;
                break;

            }
    }
    if(!validate())return;
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+'nas/set/cloud'
		,cache:false
		,data:{
                        hash:window.top.SessionID
			,enable:'new'
                        ,type:g_cloud
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
                        prepareAdd();
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}


//-----------------------------------------------------------------------------------------------------------------------
function toApply(){
    if(!validate())return;
        if (g_enable=='pause')
          g_dir= $("#scanfolder").val()
        else
          g_dir='/dav'+$("#scanfolder").val()

	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+'nas/set/cloud'
		,cache:false
		,data:{
                        hash:window.top.SessionID
                        ,name:$("#taskname").val()
			,enable:g_enable
			,en_pause:($("#pause").attr('checked'))?'yes':'no'
			,directory:g_dir
                        ,type:g_cloud
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
//			$("#waiting").hide();
			if(window.top.checkAPIError(data))
                        {
			  $("#waiting").hide();
                          return;
                        }
                        setTimeout(function (){
			  $("#waiting").hide();
	                  loadData();
                          }, 7000);
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}
function toDelete(){
    if(!validate())return;
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+'nas/set/cloud'
		,cache:false
		,data:{
                        hash:window.top.SessionID
                        ,name:$("#taskname").val()
			,enable:'no'
                        ,type:g_service
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
                        loadData();
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}


function showBrowse(){
	window.top.System.selectDir({
		app:window.top.Preference
		,handler: function(path){
			$("#scanfolder").val(   decodeURI(path) );
		}
	});
}


function validate(){
    var fields = [];
	if($("#check").attr('checked')){
		fields.push(
		{
			method : 'required',
			value : $('#scanfolder').val(),
			element : $('#scanfolder')[0],
			param : null,
			errParam : $.l10n.__("Preference_dlna_text_folder")
		},
		{
			method : 'regex',
			value : $('#scanfolder').val(),
			element : $('#scanfolder')[0],
			param : '^((?!;).)*$',
			errParam : $.l10n.__("Preference_dlna_text_folder")
		});
	}

	return validateFields(fields);
}
function myTimer() {
     loadData();
}
var checkbox = $("#pause");
