﻿$(function(){
	window.App="Preference";
	loadLang();	
	loadData();
	bindEvent();
});


//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){	
	$("#APPLY").click(function(){	toApply();	});	
	$("#REFRESH").click(function(){	loadData();	});
	$('#check').click(function(){	enableService();	});
}



//-----------------------------------------------------------------------------------------------------------------------
function loadData(){	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/mldonkey"
		,cache:false
		,data:{
			hash:window.top.SessionID
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}


function parseData(data){
	if($('enable',data).text().toLowerCase()=='yes'){
		$("#check").attr('checked','checked');
	}
	else {
		$("#check").removeAttr('checked');
	}
	if($('running',data).text().toLowerCase()=='yes'){
		$('#running').html('<label domain="l10n" msgid="Preference_main_text_servicerunning">'+$.l10n.__('Preference_main_text_servicerunning')+'</label>');
		window.running=true;		
		$('table.param input').removeAttr('disabled');
		loadParam();
	}
	else{		
		$('#running').html('<label domain="l10n" msgid="Preference_main_text_servicestopped">'+$.l10n.__('Preference_main_text_servicestopped')+'</label>');
		window.running=false;
		$('table.param input').val('').attr('disabled','disabled');
	}
}


function  loadParam(){
	$("#waiting").show();
	$.ajax({
		url:window.top.remoteDataUrl+"submit?q=voo+1"
		,cache:false
		,type:"GET"
		,dataType: 'html'
		,success:function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseParam(data);			
		}	
		,error:function(data){
			$("#waiting").hide();
			//alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});				
}

function parseParam(data){
	var v1 = $('#upstatsTable input[value=max_hard_upload_rate]',data).next().val(); 
	var v2 = $('#upstatsTable input[value=max_hard_download_rate]',data).next().val();
	var v3 = $('#upstatsTable input[value=max_opened_connections]',data).next().val(); 
	var v4 = $('#upstatsTable input[value=max_concurrent_downloads]',data).next().val(); 
	$('#maxuploadrate').val(v1);
	$('#maxdownloadrate').val(v2);
	$('#maxopenedconnections').val(v3);
	$('#maxconcurrentdownloads').val(v4);
}

function toApply(){
	//if(!toValidate())return;	
	if(window.running&&($("#check").is(':checked'))){
		toSave();
		return;
	}
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/set/mldonkey"
		//,cache:false
		,data:{
			hash:window.top.SessionID
			,enable:($("#check").is(':checked'))?'yes':'no'
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			if($('running',data).text().toLowerCase()=='yes'){
				parseData(data);
			}else{
				parseData(data);
			}
			
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}


function toSave(){
	$("#waiting").show();
	$.ajax({
		type: "get",
		async: 'false',
		//cache: false,
		url: window.top.remoteDataUrl+"submit",
		data:{
			setoption:'q'
			,option:'max_hard_upload_rate'
			,value:$('#maxuploadrate').val()
		}
		,dataType: "html"
		,success:function(data){
		}
		,error: function(data){
			$("#waiting").hide();
		}
	}); 
	$.ajax({
		type: "get",
		async: 'false',
		//cache: false,
		url: window.top.remoteDataUrl+"submit",
		data:{
			setoption:'q'
			,option:'max_hard_download_rate'
			,value:$('#maxdownloadrate').val()
		}
		,dataType: "html"
		,success:function(data){
		}
		,error: function(data){
			$("#waiting").hide();
		}
	}); 
	$.ajax({
		type: "get"
		,async: 'false'
		//,cache: false
		,url: window.top.remoteDataUrl+"submit"
		,data:{
			setoption:'q'
			,option:'max_opened_connections'
			,value:$('#maxopenedconnections').val()
		}
		,dataType: "html"
		,success:function(data){
		}
		,error: function(data){
			$("#waiting").hide();
		}
	}); 
	$.ajax({
		type: "get",
		async: 'false',
		//cache: false,
		url: window.top.remoteDataUrl+"submit",
		data:{
			setoption:'q'
			,option:'max_concurrent_downloads'
			,value:$('#maxconcurrentdownloads').val()
		}
		,dataType: "html"
		,success:function(data){
			$("#waiting").hide();
			loadData();
		}
		,error: function(data){
			$("#waiting").hide();
		}
	}); 
	
}
//http://172.31.0.117:4080/submit?setoption=q&option=max_concurrent_downloads&value=51


function toValidate(){
var fields = [];
		fields.push({
			method : 'required',
			value : $('#maxuploadrate').val(), 
			element : $('#maxuploadrate')[0],
			param : null, 
			errParam : $.l10n.__("Preference_mldonkey_text_maxuploadrate")
		},
		{
			method : 'range',
			value : $('#maxuploadrate').val(), 
			element : $('#maxuploadrate')[0],
			param : [0,1024*100], 
			errParam : [$.l10n.__("Preference_mldonkey_text_maxuploadrate"),1,1024*100]
		},
		{
			method : 'required',
			value : $('#maxdownloadrate').val(), 
			element : $('#maxdownloadrate')[0],
			param : null, 
			errParam : $.l10n.__("Preference_mldonkey_text_maxdownloadrate")
		},
		{
			method : 'range',
			value : $('#maxdownloadrate').val(), 
			element : $('#maxdownloadrate')[0],
			param : [0,1024*100], 
			errParam : [$.l10n.__("Preference_mldonkey_text_maxdownloadrate"),1,1024*100]
		},
		{
			method : 'required',
			value : $('#maxopenedconnections').val(), 
			element : $('#maxopenedconnections')[0],
			param : null, 
			errParam : $.l10n.__("Preference_mldonkey_text_maxopenedconnections")
		},
		{
			method : 'range',
			value : $('#maxopenedconnections').val(), 
			element : $('#maxopenedconnections')[0],
			param : [1,1000], 
			errParam : [$.l10n.__("Preference_mldonkey_text_maxopenedconnections"),1,1000]
		},
		{
			method : 'required',
			value : $('#maxconcurrentdownloads').val(), 
			element : $('#maxconcurrentdownloads')[0],
			param : null, 
			errParam : $.l10n.__("Preference_mldonkey_text_maxconcurrentdownloads")
		},
		{
			method : 'range',
			value : $('#maxconcurrentdownloads').val(), 
			element : $('#maxconcurrentdownloads')[0],
			param : [1,100], 
			errParam : [$.l10n.__("Preference_mldonkey_text_maxconcurrentdownloads"),1,100]
		}
		
		
		);
		

	return validateFields(fields);
}


function enableService(){
	if(window.running){
		if(($("#check").is(':checked'))){
			$("table input").removeAttr('disabled');
		}
		else{
			$("table input").attr('disabled','disabled');
		}
	}
}
