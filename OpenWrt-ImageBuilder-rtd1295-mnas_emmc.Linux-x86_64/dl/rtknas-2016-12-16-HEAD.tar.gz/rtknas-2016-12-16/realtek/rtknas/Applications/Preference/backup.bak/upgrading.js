﻿$(function(){
	window.urlpath=(window.location.protocol+"//"+window.location.host+window.location.pathname).replace("Applications/Preference/upgrading.html","");
	window.hostpath=window.location.protocol+"//"+window.location.host+'/';
	window.remoteDataUrl=getRequest("remoteDataUrl");//系统数据目录
	window.SessionID=getRequest('sid')
	window.Lang=getRequest('lang');
	window.registername=getRequest('registername')
	window.method=getRequest('method')
	window.App="Preference"; 
	loadLang();
	var dl=window.location.protocol+"//"+window.registername+'.'+$.l10n.__('global_link_domainname')+'/';
	window.domainlink=dl;
	$('#domainlink').attr('href',dl).html(dl);
	loadData();
	
});








//-----------------------------------------------------------------------------------------------------------------------
function loadData(){	
	$.ajax({
		url: window.top.remoteDataUrl+"nas/firmware/"+((window.method-0==0)?'autoupdate':'manualupdate')
		,cache:false
		,data:{
			hash:window.top.SessionID
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			if(window.checkAPIError(data))return; 
			window.setInterval( function(){toLogin();},10000);
		}
		,error:function(data){
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});	
}


function toLogin(){
	$.ajax({
		url: window.remoteDataUrl+"nas/gen/hash"
		,cache:false
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			window.location=window.hostpath;
		}
		,error:function(data){
		}
	});	
	
}
