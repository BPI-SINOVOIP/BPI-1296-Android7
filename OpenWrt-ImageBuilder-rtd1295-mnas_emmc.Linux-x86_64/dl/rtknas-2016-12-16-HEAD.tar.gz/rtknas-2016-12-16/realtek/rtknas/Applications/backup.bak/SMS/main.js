﻿$(function(){
	window.App="SMS";	
	loadLang();
	layout();
	bindEvent();
	loadData();	
});

function layout(){	
	$('body').layout({ 
			center__paneSelector:"#editor"
		,	north__paneSelector:"#top"  
		,	north__size:120
		,	north__spacing_open:0
		,	center__minWidth:400
		,	contentSelector:".data"
	}); 
}

function bindEvent(){
	$("#APPLY").click(function(){	toSend();	});
	$("#reveiver").click(function(){	window.top.System.addReceiver({fn:addReceiver,data:'phone'});});
	$('#address')[0].data=[];
}
	
	
function loadData(o){
	if(!o)o=window.win.fromWinObject;
	if(o){
		if(o.email)$("#address").val(o.email);
		if(!o.path){
			writeContent();
			return;
		};
		for(var i=0;i<o.path.length;i++){
			window.top.System.toPublish({path:o.path[i].path, filename:o.path[i].displayname, guest:'SMS', callback:writeContent});
		}
	}	
}

function writeContent(filename,uuid){ 	
	var dl=window.top.location.protocol+"//"+window.top.NASinfo.registername+'.'+$.l10n.__('global_link_domainname')+'/';	
	if($("#editor").val()===''){
		var o=window.win.fromWinObject;
		var s=(o.content)?o.content:'';
		var album=dl+"album.html?author="+window.top.user;
		s += '\n'+$.l10n.__("global_text_visitalbum")+":\n"+album+"\n";
		$("#editor").val(s);
	}
	if(!filename||!uuid)return;
	var p=dl+'publish.html?uuid='+uuid; 
	var s=filename+':\n'+ p +'\n';
	s = s + $("#editor").val(); 
	$("#editor").val( s );
	
};

function addReceiver(r){
	var v=$("#address").val();
	$("#address").val(  v + ( (/,$/.test(v)||v==='')?'':',') + r.join(',') );
}



function toSend(){ 
	if(!toValidate())return;
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/send/sms"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,msg:$('#editor').val()
			,dest:$("#address").val()
		}
		,type: "POST"
		,dataType:"xml"		
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			alert ( $.l10n.__("SMS_alert_sendok") );
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
		
	});
}

function toValidate(){
	if($("#address").val()==""||$("#editor").val()==""){
		alert($.l10n.__("global_alert_inputerror"));
		return false;
	}
	return true;
}