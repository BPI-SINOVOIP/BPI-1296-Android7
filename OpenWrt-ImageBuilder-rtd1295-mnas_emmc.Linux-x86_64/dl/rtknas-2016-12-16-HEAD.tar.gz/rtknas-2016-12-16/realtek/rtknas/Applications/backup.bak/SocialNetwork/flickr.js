﻿$(function(){
	  
	window.App="SocialNetwork";	
	loadLang();	
	layout();
	bindEvent();
	init();
});


function layout(){
	$('body').layout({ 
			center__paneSelector:"#main"
		,	north__paneSelector:"#top"  
		,	north__size:80
		,	north__spacing_open:0
		,	west__paneSelector:"#left"  
		,	west__size:200
		,	west__spacing_open:0
		//,	center__minWidth:400
		,	contentSelector:".data"
	}); 
}



function init(){ 
	if(window.top.flickrauth){
		showUserInfo();	
		loadAlbum();
		$('#login').hide();
		$('#logout,#REFRESH').show();
		return;
	}
	
		
	var frob=getRequest('frob');
	if(frob&&frob!==''){ 
		getToken(frob);
		return;
	}else{
		$('#login').show();
		$('#logout,#REFRESH').hide();
		$('#login').click();
		return;
	}
	
	
	if(window.location.search===''){ 
		$('#login').click();
		return;
	}
	
}

function toLogout(){
	window.open('http://www.flikr.com/','_blank');
	$('#login').show();
	$('#logout,#REFRESH').hide();
	$('#username').html('');
	$('#userphoto').attr('src','icons/user.gif');
	window.top.flickrauth=null;
	$('#tree,#data').empty();
}


function getToken(frob){
	FR({
			method:'flickr.auth.getToken'
			,frob:frob
			,jsoncallback:'parseToken'
		});
}


function parseToken(resp){
	//{"auth":{"token":{"_content":"72157625422265584-371ebf954bbdcf22"}, "perms":{"_content":"write"}, "user":{"nsid":"55662999@N03", "username":"dingguokai", "fullname":""}}, "stat":"ok"})
	if(isError(resp)) return; 
	window.top.flickrauth=resp.auth;
	window.parent.location=window.parent.location;
}



function showUserInfo(){
	$('#username').html(window.top.flickrauth.user.username);
	//$('#userphoto').attr('src','icons/user.gif');
}





function loadAlbum() {
	$('#waiting').show();	
	$('#tree').html('<ul class="normallist album"><li><a id="noset" class="unknown">Not in set</a><hr/></li></ul>');
	$('#tree a:first')[0].data={};
	$('#tree a:first').click(function(){
		$('#tree a.selected').removeClass('selected');
		$(this).addClass('selected');
		if($(this).hasClass('unknown')){
			getNotInSet();
		}else{
			showContent(this.data.resp);
		}
	}).click();
	getSets();
};


function getNotInSet(){
	$('#waiting').show();
	FR({
	   method:'flickr.photos.getNotInSet'
		,jsoncallback:'showContent'
	});
}

function getSets(){
	$('#waiting').show();
	FR({
	   method:'flickr.photosets.getList'
		,jsoncallback:'showSets'
	});
}


function showSets(resp){
	if(isError(resp)) return;
	//{"photosets":{"photoset":[{"id":"72157625297135535", "primary":"5188431613", "secret":"c3a65f628c", "server":"4088", "farm":5, "photos":"9", "videos":0, "title":{"_content":"newset"}, "description":{"_content":""}}], "cancreate":1}, "stat":"ok"}
	var data=resp.photosets.photoset;	
	for(var i=0,l=data.length;i<l;i++){
		addSet(data[i],true);
	}
	//$('#tree a:first').click();
	
}



function addSet(resp,list){
	if(isError(resp)) return;
	var $ul=$('#tree ul');
	var album=resp.photoset||resp;
	var li = document.createElement('li');
	var a = document.createElement('a');
	a.data={
		id: album.id
		,title:window.newalbumname||album.title._content
		//,url:album.url
	}; 
	a.id='album'+a.data.id;
	a.innerHTML = a.data.title;
	a.className='unknown';
	//a.href = album.url;
	$(a).click(function(){
		$('#tree a.selected').removeClass('selected');
		$(this).addClass('selected');
		if($(this).hasClass('unknown')){
			loadContent();
		}else{
			showContent(this.data.resp);
		}
	});
	$(li).append(a).appendTo($ul);
	if(!list)$(a).click();
	window.newalbumname=null;
}




function toCreateSet(){
	if(!window.top.flickrauth)return;
	var p=$('#data div.selected');
	if(p.length===0){alert('Choose one item first!');return;}
	var name=prompt($.l10n.__('SocialNetwork_text_newalbum'),'');
	if(!name||name==='')return;
	window.newalbumname=name;
	$("#waiting").show();
	FR({
		method:'flickr.photosets.create'
		,title: name
		,primary_photo_id: p[0].data.id
		,jsoncallback:'addSet'
	});
}


function loadContent(){
	$('#waiting').show();
	var id=$("#tree a.selected")[0].data.id;
	FR({
		method:'flickr.photosets.getPhotos'
		,photoset_id:id
		,jsoncallback:'showContent'
	});
	
}

function showContent(resp){
	//{"photoset":{"id":"72157625297135535", "primary":"5188431613", "owner":"55662999@N03", "ownername":"dingguokai", "photo":[{"id":"5188431613", "secret":"c3a65f628c", "server":"4088", "farm":5, "title":"2", "isprimary":"1"}, {"id":"5188431611", "secret":"a04a16364a", "server":"1035", "farm":2, "title":"03", "isprimary":"0"}, {"id":"5188431609", "secret":"94a4c230cd", "server":"4084", "farm":5, "title":"05", "isprimary":"0"}, {"id":"5188431607", "secret":"1f01444ac0", "server":"4149", "farm":5, "title":"07", "isprimary":"0"}, {"id":"5188431605", "secret":"39e4e8325a", "server":"4129", "farm":5, "title":"10", "isprimary":"0"}, {"id":"5188431603", "secret":"1c37e61082", "server":"4104", "farm":5, "title":"04", "isprimary":"0"}, {"id":"5159487433", "secret":"99ee76841d", "server":"4085", "farm":5, "title":"gateway_icon", "isprimary":"0"}, {"id":"5160102252", "secret":"47c3b08d23", "server":"1315", "farm":2, "title":"1", "isprimary":"0"}, {"id":"5157232939", "secret":"b253e6e0b2", "server":"1090", "farm":2, "title":"1", "isprimary":"0"}], "page":1, "per_page":500, "perpage":500, "pages":1, "total":"9"}, "stat":"ok"}
	//{"photos":{"page":1, "pages":1, "perpage":100, "total":"1", "photo":[{"id":"5189137958", "owner":"55662999@N03", "secret":"ca2489d537", "server":"4145", "farm":5, "title":"Archive-icon", "ispublic":1, "isfriend":0, "isfamily":0}]}, "stat":"ok"}
	//farm5.static.flickr.com\/4104\/5188431603_1c37e61082_s.jpg
	if(isError(resp)) return;
	$('#tree a.selected').removeClass('unknown');
	var data=(resp.photoset||resp.photos).photo;
	$('#tree a.selected')[0].data.resp=resp;
	$('#data').html('');
	for (var i=0, l=data.length; i<l; i++) {
		addPhoto(data[i]);
    }
	$('#data div').click(function(){
		$('#data div.selected').removeClass('selected');
		$(this).addClass('selected');		
	});
	
}


function addPhoto(resp){
	//{"id":"5188431613", "secret":"c3a65f628c", "server":"4088", "farm":5, "title":"2", "isprimary":"1"}
	
	var div=document.createElement('div');
	var photo = (resp.photo||resp.source)||resp;
	div.data=photo;
	var url=(resp.source)?resp.source:'http://farm'+photo.farm+'.static.flickr.com/'+photo.server+'/'+photo.id+'_'+photo.secret+'_t.jpg';		
	div.style.cssText='background:#f2f2f2 url('+url+') no-repeat center center;float:left;';
	$('#data').append(div);
}


function showUpload(){
	if($('#tree a.selected').length===0)return;
	window.top.System.opendialog({
		app:window.top.SocialNetwork
		,filter:'image'
		,handler:toUpload
	});
}


function toUpload(items){
	var album=$('#tree a.selected')
	if(album.length==0)return;
	var albumid=album[0].data.id;
	var l=items.length;
	while(l--){
		$("#waiting").show();
		$.ajax({
			url: window.top.remoteDataUrl+"nas/flickr/uploadphoto"
			,cache:false
			,data:{
				hash:window.top.SessionID
				,auth_token:window.top.flickrauth.token._content
				,path:decodeURI(items[l])
			}
			,type: "POST"
			,dataType:"xml"
			,success: function(data){
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
				addPotho2Set(data);
			}
			,error:function(data){
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}
			//,timeout:20000
			
		});
	}
}

function addPotho2Set(data){
	//<?xml version="1.0" encoding="utf-8"?><nas><photoid>5188830201</photoid></nas>
	$('#waiting').show();
	var sid=$("#tree a.selected")[0].data.id;
	var pid=$('photoid',data).text();
	if(sid==='noset'){
		//getSizes(pid);
		toRefresh();
	}
	else{
		FR({
			method:'flickr.photosets.addPhoto'
			,photoset_id:sid
			,photo_id: pid
			,jsoncallback:'toRefresh'
		});
	}
}

function toRefresh(){
	$('#tree a.selected').addClass('unknown').click();
}

function getSizes(pid){
	$('#waiting').show();
	FR({
		method:'flickr.photos.getSizes'
		,photo_id: pid
		,jsoncallback:'parseSizes'
	});
	
}

function parseSizes(resp){
	//{"sizes":{"canblog":1, "canprint":1, "candownload":1, "size":[{"label":"Square", "width":75, "height":75, "source":"http:\/\/farm2.static.flickr.com\/1274\/5189470616_0ab3b7cf42_s.jpg", "url":"http:\/\/www.flickr.com\/photos\/55662999@N03\/5189470616\/sizes\/sq\/", "media":"photo"}, {"label":"Thumbnail", "width":"100", "height":"75", "source":"http:\/\/farm2.static.flickr.com\/1274\/5189470616_0ab3b7cf42_t.jpg", "url":"http:\/\/www.flickr.com\/photos\/55662999@N03\/5189470616\/sizes\/t\/", "media":"photo"}, {"label":"Small", "width":"240", "height":"180", "source":"http:\/\/farm2.static.flickr.com\/1274\/5189470616_0ab3b7cf42_m.jpg", "url":"http:\/\/www.flickr.com\/photos\/55662999@N03\/5189470616\/sizes\/s\/", "media":"photo"}, {"label":"Medium", "width":"400", "height":"300", "source":"http:\/\/farm2.static.flickr.com\/1274\/5189470616_0ab3b7cf42.jpg", "url":"http:\/\/www.flickr.com\/photos\/55662999@N03\/5189470616\/sizes\/m\/", "media":"photo"}]}, "stat":"ok"}
	if(isError(resp)) return;	
	addPhoto(resp.sizes.size[1]);
}




function isError(resp){
	//{"stat":"fail", "code":96, "message":"Invalid signature"}	
	$('#waiting').hide();
	if (resp.stat&&resp.stat==='fail'){
		alert(resp.message);
		return true;
	}
	return false;
}


function FR(data){
	data.api_key='bb9ad1b48280c3348d1fbbf79fb82afd';
	if(window.top.flickrauth)data.auth_token=window.top.flickrauth.token._content;
	data.format='json';
	var names=[];
	for(var name in data){
		names.push(name);
	}
	names.sort();
	var api_sig='483833773cc7e100';
	for(var i=0,l=names.length;i<l;i++){
		api_sig += names[i]+data[names[i]];
	}
	data.api_sig=hex_md5(api_sig);
	$.getScript('http://api.flickr.com/services/rest/?'+$.param(data));
}



function bindEvent(){	
	$('#login').unbind().click(function() {
		window.top.flickrauth=null; 
		window.open('http://myisharing.com/flickr.html?origin='+window.location,'isharing');

	});
		
	$('#logout').unbind().click(toLogout);	
	$('#CREATE').unbind().click(toCreateSet);
	$('#UPLOAD').unbind().click(showUpload);
	$('#REFRESH').unbind().click(init);		
	
	var win=window.win.mask;
	var thiswin=window; 
	window.top.$(win)
		.droppable('destroy')
		.droppable({
		accept:'#main li.image'
		,drop: function(event, ui) {
				if(!window.top.flickrauth)return;
				var curWin=window.win;
				var $C;
				if(curWin.id=='App_MyNAS_Win_main')$C=window.top.MyNAS.mainWin.content.$C;
				if(curWin.id=='App_AlbumMaker_Win_main')$C=window.top.AlbumMaker.mainWin.content.$C; 
				var items=(ui.draggable.hasClass('image'))?[ui.draggable[0]]:null;
				if(ui.draggable.hasClass('selected')){
					var lis=window.top.$('li.selected.image',$C); 
					if(lis.length>0){
						items=null;
						items=lis; 
					}
				}
				if (!items)return;
				var itempaths=[]; 
				for(var i=0;i<items.length;i++){
					itempaths.push(items[i].getAttribute('webview').replace('?webview','?').replace('session='+window.top.SessionID,'').replace('login='+window.top.user,''));
				}; 
				thiswin.toUpload(itempaths);
		}
		,hoverClass: 'drophover'
	});
		
	
}
