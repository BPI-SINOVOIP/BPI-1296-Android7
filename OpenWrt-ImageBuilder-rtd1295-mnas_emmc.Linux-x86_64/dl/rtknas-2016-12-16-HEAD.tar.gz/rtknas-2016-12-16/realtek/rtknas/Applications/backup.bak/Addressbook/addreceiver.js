﻿$(function(){	
	window.App="Addressbook"; 
	loadLang();	
	layout();
	loadData();
	bindEvent();
});

function layout(){
	window.Layout=$('body').layout({ 
			center__paneSelector:"#main"
		,	west__paneSelector:"#left"  
		,	west__size:150
		,	west__spacing_open:0
		,	south__paneSelector:"#bottom"  
		,	south__size:80
		,	south__spacing_open:0
		,	contentSelector:".data"
	});
}

function bindEvent(){
	$("#OPEN").click(toOpen);
	$("#CANCEL").click(function(){		
		window.win.closeWin();
	});	
}

function loadData(){
		$("#waiting").show();
		$.ajax({
		   url: window.top.remoteDataUrl+"nas/get/addrbook/groups"
		   ,cache:false
		   ,type: "POST"
		   ,data: {
			   hash:window.top.SessionID		   
			}
		   ,cache: false
		   ,dataType: "xml"
		   ,success: function(data){
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
				showGroup(data);
			}
		   ,error: function(data) {
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}
		   //,timeout: 10000
		});
}


function showGroup(data){
	$("group",data).each(function (){
		var li = document.createElement('li');
		var a = document.createElement('a');		
		var name=$('name',this).text();
		a.name=name;
		if(name==""){
			name=$.l10n.__('Addressbook_text_all');
			a.className='all';
		}
		a.innerHTML='<b>'+name+'</b>';
		$(li).append(a).append("<ul class='user' style='display:none;'></ul>").appendTo($('#grouplist'));
		
		$(a).addClass('unknown').click(function(){
			$('#grouplist a.selected').removeClass('selected');
			$(this).addClass('selected');
			if($(this).hasClass('unknown'))loadMembers(this);
			else showMembers(this);
		});	
	});
	$('#grouplist a:first').click();
}


function loadMembers(node){
		$("#waiting").show();
		$.ajax({
		   url: window.top.remoteDataUrl+"nas/get/addrbook/members"
		   ,type: "POST"
		   ,cache:false
		   ,data: {
			   hash:window.top.SessionID
			   ,group:node.name
			}
		   ,cache: false
		   ,dataType: "xml"
		   ,success: function(data){
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
				$(node).removeClass('unknown');
				node.data=data;
				showMembers(node);
			}
		   ,error: function(data) {
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}
		   //,timeout: 10000
		 });
}






function showMembers(node){
	$('#userlist').empty();
	var col=window.win.fromWinObject.data.split(',');
	$("member",node.data).each(function (){
		var li = document.createElement('li');
		var a = document.createElement('a');	
		a.data={
			name:$('name',this).text().replace(/圕/g,' ').replace(/�C/g,' ')
			,server:$('server',this).text()
			,blog:$('blog',this).text()
			,phone:$('phone',this).text().replace(/�C/g,'圕')
			,address:$('address',this).text()
			,email:$('email',this).text().replace(/�C/g,'圕')
			,comment:$('comment',this).text()
		}
		a.innerHTML=a.data.name+'&lt;';
		for(var c=0;c<col.length;c++){
			if(col[c]==='email'){
				var emails=a.data.email.split('圕');
				for(var i=0,l=emails.length;i<l;i++){
					var span=document.createElement('span');
					span.data=emails[i];
					span.innerHTML=emails[i];
					$(span)
					.appendTo(a)
					.click(function(){$(this).toggleClass('selected');});
				}
				
			}
			if(col[c]==='phone'){
				var phones=a.data.phone.split('圕');
				for(var i=0,l=phones.length;i<l;i++){
					var span=document.createElement('span');
					span.data=phones[i];
					span.innerHTML=phones[i];
					$(span)
					.appendTo(a)
					.click(function(){$(this).toggleClass('selected');});
				}
			}
		}
		$(a).append('&gt;');
		
		$(li).append(a).appendTo($('#userlist'));
		
	});
}


function toOpen(){
	var a=[];
	$("#userlist a span.selected").each(function(){
		a.push(this.data);
	});
	window.win.fromWinObject.fn(a);
	window.win.closeWin();
}