﻿$(function(){
  	window.App="Downloader";
	layout();
	loadLang();
	loadData();

});


function loadData(){
		$("#waiting").show();
		$.ajax({
		   url:window.top.remoteDataUrl +'submit?q=vd+'+getRequest('id')
		   ,type: "GET"
		   ,cache:false
		   ,dataType: "text"
		   ,success: function(data){
				$("#waiting").hide();
				showData(data);
			}
		   ,error: function(data) {
				$("#waiting").hide();
			}
		   //,timeout: 10000
		 });
}


function layout(){
	window.Layout = $('body').layout({ 
			center__paneSelector:"#main" 
		,	north__paneSelector:"#top" 
		,	north__size:32
		,	north__spacing_open:0
		,	contentSelector:".data"
		,	center__onresize_end:function(){
				$(window).resize();
			}
	}); 
	
	$("ul.tabs a:eq(1)").click(function(){	$(window).resize();	});
}

function showData(data){	
	if($("#temp").length==0)$("body").append('<div id="temp" style="display:none;"></div>');
	$("#temp").html(data);	
	var t=$("#General td");
	
	$("#sourcesInfo > tbody > tr:first").remove();
	var s=$("#sourcesInfo > tbody > tr"); 	
	
	var type;
	
	for (var i=0,l=s.length;i<l;i++){
		if(i===0){
			type=s[0].children[1].innerHTML;
			type=type.split(' ');
			type=type[1];
		} 
		$("#General").append('<tr><th title="'+s[i].children[0].getAttribute('title')+'">'+s[i].children[0].innerHTML+'</th><td>'+($('select',s[i]).length>0?$('select',s[i]).val():s[i].children[1].innerHTML)+'</td></tr>');
	}
	/*
	t[0].innerHTML=s[0].innerHTML; 
	
	t[1].innerHTML=s[1].innerHTML;
	t[2].innerHTML=s[2].innerHTML;
	t[3].innerHTML=($("select",s[3]).length>0)?$("select",s[3]).val():s[3].innerHTML;
	t[4].innerHTML=($("select",s[4]).length>0)?$("select",s[4]).val():s[3].innerHTML;
	t[5].innerHTML=s[5].innerHTML;
	t[6].innerHTML=s[6].innerHTML;
	t[7].innerHTML=s[7].innerHTML;$("table",s[7]).css({display:'block', float:'left'});
	try{t[8].innerHTML=s[8].innerHTML;}catch(e){}
	if(type=="Donkey"){
		t[9].innerHTML=s[9].innerHTML;
		t[10].innerHTML=s[10].innerHTML;
		t[11].innerHTML=s[11].innerHTML;
		t[12].innerHTML=($("input",s[12]).length>0)?$("input",s[12]).val():s[12].innerHTML;
		$("#General >tbody > tr:gt(12)").remove();
	}
	else if(type=='BitTorrent'){
		
		for(var i=12;i<22;i++)t[i].innerHTML=s[i-3].innerHTML;
		for(var i=22;i<s.length;i++){
			$("#General").append("<tr><th>"+$(s[i]).prev().html()+"</th><td>"+s[i].innerHTML+"</td></tr>");
		}	
		$("#General > tbody > tr:eq(9), #General > tbody > tr:eq(10), #General > tbody > tr:eq(11)").remove();
	}
	else if(type=="FileTP"){
		$("#General > tbody > tr:gt(8)").remove();
	}
	else{
		
	}$("#General").show();
	*/
	
		
	
	
	
	
	$("#Tag2").html('<table/>');
	window.grid=$("#Tag2 table:first")[0];
	$("#sourcesTable tr:first").remove();
	s=$("#sourcesTable > tbody > tr");//.children(0).children();

	if(type=="FileTP"){
		$(window.grid).flexigrid({
			singleSelect:true
			,colModel : [
					{display: 'Num', name : 'Num', width : 36, sortable : false, align: 'left'}
					,{display: 'Name', name : 'Name', width : 100, sortable : false, align: 'left'}
					,{display: 'IP address', name : 'IP', width : 100, sortable : false, align: 'left'}
					,{display: 'Client Software', name : 'CS', width : 100, sortable : false, align: 'left'}
					,{display: 'Upload', name : 'UL', width : 50, sortable : false, align: 'left'}
					,{display: 'Download', name : 'DL', width : 50, sortable : false, align: 'left'}
					]
			});
		s.each(function(){
			var tds=$(">td",this);
			window.grid.grid.addRow({
				id:this.className
				,Num:tds[0].innerHTML
				,Name:tds[1].innerHTML
				,IP:tds[2].innerHTML
				,CS:tds[3].innerHTML
				,UL:tds[4].innerHTML
				,DL:tds[5].innerHTML
			});
		});
	}
	else if(type=="Donkey"){
		$(window.grid).flexigrid({
			singleSelect:true
			,colModel : [
					{display: 'Num', name : 'Num', width : 36, sortable : false, align: 'left'}
					,{display: 'Active', name : 'A', width : 36, sortable : false, align: 'left'}
					,{display: 'Client State', name : 'CS', width : 50, sortable : false, align: 'left'}
					,{display: 'Name', name : 'Name', width : 150, sortable : false, align: 'left'}
					,{display: 'Client Brand', name : 'CB', width : 50, sortable : false, align: 'left'}
					,{display: 'Client Release', name : 'CR', width : 50, sortable : false, align: 'left'}
					,{display: 'Overnert', name : 'O', width : 50, sortable : false, align: 'left'}
					,{display: 'Connection', name : 'C', width : 50, sortable : false, align: 'left'}
					,{display: 'Secure', name : 'S', width : 50, sortable : false, align: 'left'}
					,{display: 'IP Adress', name : 'IP', width : 100, sortable : false, align: 'left'}
					,{display: 'Country/Region', name : 'CC', width : 80, sortable : false, align: 'left'}
					,{display: 'Total Upload', name : 'tUL', width : 50, sortable : false, align: 'left'}
					,{display: 'Totol Download', name : 'tDL', width : 50, sortable : false, align: 'left'}
					,{display: 'Session Upload', name : 'sUL', width : 50, sortable : false, align: 'left'}
					,{display: 'Session Download', name : 'sDL', width : 50, sortable : false, align: 'left'}
					,{display: 'Rank', name : 'Rnk', width : 50, sortable : false, align: 'left'}
					,{display: 'Source Score', name : 'Src', width : 50, sortable : false, align: 'left'}
					,{display: 'Last OK', name : 'LO', width : 150, sortable : false, align: 'left'}
					,{display: 'Request Score', name : 'RS', width : 50, sortable : false, align: 'left'}
					,{display: 'Request Queue', name : 'RQ', width : 50, sortable : false, align: 'left'}
					,{display: 'Request Time', name : 'RT', width : 50, sortable : false, align: 'left'}
					,{display: 'Has Slot', name : 'H', width : 50, sortable : false, align: 'left'}
					,{display: 'Banned', name : 'B', width : 50, sortable : false, align: 'left'}
					,{display: 'Request Sent', name : 'Rs', width : 50, sortable : false, align: 'left'}
					,{display: 'Request Recieved', name : 'RR', width : 50, sortable : false, align: 'left'}
					,{display: 'Connected Time', name : 'CT', width : 100, sortable : false, align: 'left'}
					,{display: 'MD4', name : 'MD4', width : 250, sortable : false, align: 'left'}
					,{display: 'Chunk', name : 'CK', width : 50, sortable : false, align: 'left'}
					]
			});
		s.each(function(){
			$("table",this).remove();
			var tds=$(">td",this);
			window.grid.grid.addRow({
				id:this.className
				,Num:tds[0].innerHTML
				,A:tds[1].innerHTML
				,CS:tds[2].innerHTML
				,Name:tds[3].innerHTML
				,CB:tds[4].innerHTML
				,CR:tds[5].innerHTML
				,O:tds[6].innerHTML
				,C:tds[7].innerHTML
				,S:tds[8].innerHTML
				,IP:tds[9].innerHTML
				,CC:tds[10].title
				,tUL:tds[11].innerHTML
				,tDL:tds[12].innerHTML
				,sUL:tds[13].innerHTML
				,sDL:tds[14].innerHTML
				,Rnk:tds[15].innerHTML
				,Src:tds[16].innerHTML
				,LO:tds[17].innerHTML
				,RS:tds[18].innerHTML
				,RQ:tds[19].innerHTML
				,RT:tds[20].innerHTML
				,H:tds[21].innerHTML
				,B:tds[22].innerHTML
				,Rs:tds[23].innerHTML
				,RR:tds[24].innerHTML
				,CT:tds[25].innerHTML
				,MD4:tds[26].innerHTML
				,CK:tds[28].innerHTML
			});
		});
	}
	else if(type=="BitTorrent"){
		$(window.grid).flexigrid({
			singleSelect:true
			,colModel : [
					{display: 'Num', name : 'Num', width : 36, sortable : false, align: 'left'}
					,{display: 'UID', name : 'UID', width : 250, sortable : false, align: 'left'}
					,{display: 'Client Software', name : 'CS', width : 150, sortable : false, align: 'left'}
					,{display: 'IP Adress', name : 'IP', width : 100, sortable : false, align: 'left'}
					,{display: 'Port', name : 'PT', width : 100, sortable : false, align: 'left'}
					,{display: 'Country/Region', name : 'CC', width : 80, sortable : false, align: 'left'}
					,{display: 'Total Upload', name : 'tUL', width : 50, sortable : false, align: 'left'}
					,{display: 'Totol Download', name : 'tDL', width : 50, sortable : false, align: 'left'}
					,{display: 'Session Upload', name : 'sUL', width : 50, sortable : false, align: 'left'}
					,{display: 'Session Download', name : 'sDL', width : 50, sortable : false, align: 'left'}
					,{display: 'Interested', name : 'Ied', width : 50, sortable : false, align: 'left'}
					,{display: 'Choked', name : 'C', width : 50, sortable : false, align: 'left'}
					,{display: 'Allowed to Write', name : 'AW', width : 50, sortable : false, align: 'left'}
					,{display: 'Interesting', name : 'Iing', width : 50, sortable : false, align: 'left'}
					,{display: 'Already sent Interesting', name : 'AI', width : 50, sortable : false, align: 'left'}
					,{display: 'Already sent NOT Interesting', name : 'AN', width : 50, sortable : false, align: 'left'}
					,{display: 'Good', name : 'G', width : 50, sortable : false, align: 'left'}
					,{display: 'Incoming', name : 'IC', width : 50, sortable : false, align: 'left'}
					,{display: 'Registered Bitfield', name : 'RB', width : 50, sortable : false, align: 'left'}
					,{display: 'Connected Time', name : 'CT', width : 100, sortable : false, align: 'left'}					
					,{display: 'Last Optimist', name : 'LO', width : 50, sortable : false, align: 'left'}					
					,{display: 'Num Try', name : 'NT', width : 50, sortable : false, align: 'left'}
					,{display: 'DHT', name : 'DHT', width : 50, sortable : false, align: 'left'}
					,{display: 'Cache Extensions', name : 'CE', width : 50, sortable : false, align: 'left'}
					,{display: 'Fast Extensions', name : 'FE', width : 50, sortable : false, align: 'left'}
					,{display: 'uTorrent Extessions', name : 'UE', width : 50, sortable : false, align: 'left'}
					,{display: 'Azureus Messaging Protocol', name : 'AMP', width : 50, sortable : false, align: 'left'}
					,{display: 'Chunk', name : 'CK', width : 50, sortable : false, align: 'left'}
					]
			});
		s.each(function(){
			$("table",this).remove();
			var tds=$(">td",this);
			window.grid.grid.addRow({
				id:this.className
				,Num:tds[0].innerHTML
				,UID:tds[1].innerHTML
				,CS:tds[2].innerHTML
				,IP:tds[3].innerHTML
				,PT:tds[4].innerHTML
				,CC:tds[5].title
				,tUL:tds[6].innerHTML
				,tDL:tds[7].innerHTML
				,sUL:tds[8].innerHTML
				,sDL:tds[9].innerHTML
				,Ied:tds[10].innerHTML
				,C:tds[11].innerHTML
				,AW:tds[12].innerHTML
				,Iing:tds[13].innerHTML
				,AI:tds[14].innerHTML
				,AN:tds[15].innerHTML
				,G:tds[16].innerHTML
				,IC:tds[17].innerHTML
				,RB:tds[18].innerHTML
				,CT:tds[19].innerHTML
				,LO:tds[20].innerHTML
				,NT:tds[21].innerHTML
				,DHT:tds[22].innerHTML
				,CE:tds[23].innerHTML
				,FE:tds[24].innerHTML
				,UE:tds[25].innerHTML
				,AMP:tds[26].innerHTML
				,CK:tds[27].innerHTML
			});
		});
	}
	else{
	
	}
	
	$("#temp").remove();
	
} 


