﻿$(function(){
	window.App="Browser";
	loadLang();
	bindEvent();
	layout();
});

function layout(){	
	$('body').layout({ 
			center__paneSelector:"#main"
		,	north__paneSelector:"#top"  
		,	north__size:62
		,	north__spacing_open:0
		,	contentSelector:".data"
		//,	center__onresize_end: function(){  }
	}); 
 	$('#toolbar').layout({ 
			center__paneSelector:"#middle"
		,	west__paneSelector:"#left"  
		,	west__size:32
		,	west__spacing_open:0
		,	east__paneSelector:"#right"  
		,	east__size:400
		,	east__spacing_open:0
		//,	center__onresize_end: function(){  }
	}); 
	
	
	window.proxywin=document.createElement('iframe');
	//window.proxywin.style.cssText='display:none;';
	window.proxywin.src=window.top.remoteDataUrl+'nph-proxy.cgi';
	$('body').append(window.proxywin);
	

}

function bindEvent(){
	$('#addtab').click(function(){
		addTab();
	}).click();
	$('#scrollleft').click(function(){
		var w=$('#tabs td:first').width();
		$('#tagcontainer').animate({scrollLeft: $('#tagcontainer').scrollLeft()-w });
	});
	$('#scrollright').click(function(){
		var w=$('#tabs td:first').width();
		$('#tagcontainer').animate({scrollLeft: $('#tagcontainer').scrollLeft()+w });
	});	
	$("#url").keypress(function(e){
		if(e.which==13)$("#go").click();
	});		
	$("#go,#refresh").click(function(){	toBrowse();	});
	//$("#back").click(function(){	toHistory(-1);	});
	//$("#forward").click(function(){	toHistory(1);	});
	
}
	
function addTab(){
	var url='about:blank';
	$('#url').val(url);
	var td=document.createElement('td');
	td.innerHTML='<td><div class="tag"><div class="title">'+url+'</div><div class="close"></div></div></td>';
	var iframe=document.createElement('iframe');
	iframe.style.cssText='background:#fff;';
	iframe.src=url;
	if(!window.total)window.total=0;
	iframe.name='iframe'+window.total;
	window.total++;
	$('iframe').hide();
	td.$iframe=$(iframe);
	td.iframe=iframe;
	$('#tabs').append(td);
	$('#main').append(iframe);
	$('div.close',td).click(function(){
		if($(td).next().length>0)$(td).next().click();
		else if($(td).prev().length>0)$(td).prev().click();
		else addTab();
		$(td).remove();
		$(iframe).remove();
	});
	$(td).click(function(){
		$('iframe').hide();
		this.$iframe.show();
		$('#tabs td.selected').removeClass('selected');
		$(this).addClass('selected');
		$('#url').val(this.iframe.src);
	}).click();
	$('#tagcontainer').animate({scrollLeft: $('#tagcontainer')[0].scrollWidth });
}
	
function toBrowse(){
	var url=$('#url').val();
	var $td=$('#tabs td.selected');
	var td=$td[0];
	$('div.title',$td).html(url);
	if(url.indexOf('http://')!==0&&url.indexOf('https://')!==0){
		url ='http://'+url;
		$('#url').val(url);
	}
	if($('#checkproxy').is(':checked')&&window.proxywin.contentWindow){
		if($.browser.msie){
			var tg=$('#checkpage').is(':checked')?' target="_blank"':''; 
			var iframe=document.createElement('iframe');
			iframe.style.cssText='background:#fff;';
			iframe.src='about:blank';
			iframe.name=td.$iframe.attr('name');
			td.$iframe.remove();
			td.$iframe=$(iframe);
			td.iframe=iframe;
			$('#main').append(iframe);
			var thiswin=iframe.contentWindow;
			thiswin.document.write(window.proxywin.contentWindow.document.body.innerHTML.replace('<FORM', '<FORM style="display:none;"'+tg ));
			var f=thiswin.document.forms['URLform'];	
		}
		else{
			var thiswin=window.proxywin.contentWindow;
			var f=thiswin.document.forms['URLform'];
			f.target=td.$iframe.attr('name');
			if($('#checkpage').is(':checked'))f.target='_blank';
		}	
			var u=f['URL'];
			var s=f['if'];
			try{f.removeChild(s);}catch(e){}
			u.value=url;
			f.submit();		
	}
	else {
		if($('#checkpage').is(':checked'))window.open(url,'_blank');
		else $td[0].$iframe[0].src=url;
	}
}


function toHistory(d){
	var td=$('#tabs td.selected')[0];
	var w=td.iframe.contentWindow;
	w.history.go(d);
}