﻿$(function(){
	window.App="Addressbook";
	loadLang();	
	layout()
	bindEvent();
	loadData();
});


function layout(){
	
	$('body').layout({ 
			center__paneSelector:"#main"
		,	north__paneSelector:"#top"  
		,	north__size:60
		,	north__spacing_open:0
		,	west__paneSelector:"#left" 
		,	west__size:360
		,	west__spacing_open:5
		//,	contentSelector:".data"
		,	center__onresize_end: function(){ W.resizeAll(); }
	}); 
	var W=$('#left').layout({ 
			center__paneSelector:"#memberlist"
		,	west__paneSelector:"#grouplist" 
		,	west__size:180
		,	west__spacing_open:5
		//,	contentSelector:".data"
	});
	$('#toolbar').toolbar();
	
}


//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){	
	$("#REFRESH").click(loadData);
	$("#ADDGROUP").click(addGroup);
	$("#DELGROUP").click(delGroup);
	$("#EDITGROUP").click(editGroup);
	$("#ADDMEMBER").click(showAddMember);
	$("#DELMEMBER").click(delMember);
	$("#DELFROMGROUP").click(delFromGroup);
	$("#SAVE").click(toSave);
	$("#EDIT").click(function(){ $("#info, #edit").toggle(); });
	$("#IMPORT").click(showImport);
	$("#EXPORT").click(showExport);
}


function loadData(member){
		$("#waiting").show();
		$.ajax({
		   url: window.top.remoteDataUrl+"nas/get/addrbook/groups"
		   ,type: "POST"
		   ,cache:false
		   ,data: {
			   hash:window.top.SessionID		   
			}
		   ,cache: false
		   ,dataType: "xml"
		   ,success: function(data){
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
				showGroup(data,member);
			}
		   ,error: function(data) {
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}
		   //,timeout: 10000
		});
}


function showGroup(data,member){
	var ul = document.createElement('ul');
	ul.className="normallist group";
	$("group",data).each(function (){
		var li = document.createElement('li');
		var a = document.createElement('a');		
		var name=$('name',this).text();
		a.name=name;
		if(name==""){
			name=$.l10n.__('Addressbook_text_all');
			a.className='all';
		}
		a.innerHTML=name;
		$(li).append(a).appendTo(ul);
		
		$(a).addClass('unknown').click(function(){
			if($(this).hasClass('all')){
				$("#DELGROUP,#EDITGROUP").removeClass("enabled");
			}else{				
				$("#DELGROUP,#EDITGROUP").addClass("enabled");
			}
			$('#ADDMEMBER').addClass("enabled");
			$("#DELMEMBER,#DELFROMGROUP").removeClass("enabled");
			$('#edit,#info').hide();
			$("#grouplist a.selected").removeClass('selected');			
			$(this).addClass('selected');
			window.GROUP=this;
			if($(this).hasClass('unknown'))loadMembers(member);
			else showMembers(this.data,member);
		});	
	});
	var g=(window.GROUP)?window.GROUP.name:null;
	$("#grouplist a").droppable('destroy')
	$("#grouplist").html("").append(ul);
	
	
	if(g) $('#grouplist a[name='+g+']').click();
	else $('#grouplist a:first').click();
	
		
	$("#grouplist a").droppable('destroy').droppable({
		accept:"#memberlist a"
		,drop: function(event, ui){
			if( $(this).hasClass('all') && this.name==='')return;
			addGroupMember(this.name,ui.draggable[0].data.name);
		}
	});
	
}


function loadMembers(member){
		$("#waiting").show();
		$.ajax({
		   url: window.top.remoteDataUrl+"nas/get/addrbook/members"
		   ,type: "POST"
		   ,cache:false
		   ,data: {
			   hash:window.top.SessionID
			   ,group:window.GROUP.name
			}
		   ,cache: false
		   ,dataType: "xml"
		   ,success: function(data){
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
				$(window.GROUP).removeClass('unknown');
				window.GROUP.data=data;
				showMembers(data,member);
			}
		   ,error: function(data) {
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}
		   //,timeout: 10000
		 });
}






function showMembers(data,member){
	
	var m=(member)?member:$('#memberlist a.selected').attr('name');
	
	var ul = document.createElement('ul');
	ul.className="normallist user";
	$("member",data).each(function (){
		
		var li = document.createElement('li');
		var a = document.createElement('a');
		var name=$("name",this).text().replace(/�C/g,'圕');
		    name=name.split('圕');
		var firstname=name[0];
		var surname=(name[1])?name[1]:'';
		var showname=name.join(' ');
		var phone=$("phone",this).text().replace(/�C/g,'圕');
		    phone=phone.split('圕');
		var email=$("email",this).text().replace(/�C/g,'圕');
		    email=email.split('圕');
		var address=$("address",this).text().replace(/�C/g,'圕');
		    address=address.split('圕');
		var email0=email[0];
		var email1=(email[1])?email[1]:'';
		var phone0=phone[0];
		var phone1=(phone[1])?phone[1]:'';
		var phone2=(phone[2])?phone[2]:'';
		var address0=address[0];
		var address1=(address[1])?address[1]:'';
		a.data={
			firstname:firstname
			,surname:surname
			,name:$("name",this).text()
			,showname:showname
			,server:$('server',this).text()
			,blog:$('blog',this).text()
			,email0:email0
			,email1:email1
			,phone0:phone0
			,phone1:phone1
			,phone2:phone2
			,address0:address0
			,address1:address1
			,comment:$('comment',this).text()
		}
		a.innerHTML=a.data.showname;
		a.name=a.data.name;
		a.setAttribute('name',a.data.name);
		$(a).click(function(){
			$("#DELMEMBER,#DELFROMGROUP").addClass("enabled");
			if($('#grouplist a.selected').hasClass('all'))$("#DELFROMGROUP").removeClass("enabled");
			else $("#DELFROMGROUP").addClass("enabled");
			$("#memberlist a.selected").removeClass('selected');			
			$(this).addClass('selected');	
			window.MEMBER=this;
			$("#info").show();			
			$("#edit").hide();
			showInfo(this.data);
		});
		
		$(li).append(a).appendTo(ul);
		
	});
	
	$('#memberlist a').draggable('destroy')
	$("#memberlist").html("").append(ul);
	if(m) $('#memberlist a[name='+m+']').click();
	else $('#memberlist a:first').click();
	
	
	$('#memberlist a').draggable('destroy').draggable({
		helper: 'clone'
		,appendTo: '#dragging'
		,hoverClass: 'drophover'
		,cursor:'move'
	});
}

function showInfo(){			
	var data=window.MEMBER.data;
	$("#info_name").html(data.showname);
	$("#info_email0").html('<a href="#">'+data.email0+'</a>');
	$("#info_email1").html('<a href="#">'+data.email1+'</a>');
	$("#info_phone0").html(data.phone0);
	$("#info_phone1").html(data.phone1);
	$("#info_phone2").html(data.phone2);
	$("#info_address0").html(data.address0);
	$("#info_address1").html(data.address1);
	$("#info_server").html('<a href="'+data.server+'" target="_blank">'+data.server+'</a>');
	$("#info_blog").html('<a href="'+data.blog+'" target="_blank">'+data.blog+'</a>');
	$("#info_email0 a,#info_email1 a").click(function(){
		var email=this.innerHTML;
		window.top.System.sendEmail({email: email});
	});
	$("#name").val(data.firstname);
	$("#surname").val(data.surname);
	$("#email0").val(data.email0);
	$("#email1").val(data.email1);
	$("#phone0").val(data.phone0);
	$("#phone1").val(data.phone1);
	$("#phone2").val(data.phone2);
	$("#address0").val(data.address0);
	$("#address1").val(data.address1);
	$("#server").val(data.server);
	$("#blog").val(data.blog);
}


function addGroup(){	
	if(!$('#ADDGROUP').hasClass('enabled')){return};
	var name=prompt( $.l10n.__("Addressbook_text_inputgroup"),$.l10n.__("Addressbook_text_newgroup"));
	if(!name||name=="")return;
	name=name.replace(/(^\s*)|(\s*$)/g, '');
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/add/addrbook/group"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,user: window.top.user
			,name:name
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			window.GROUP={};
			window.GROUP.name=name;
			loadData();
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
	});
}

function delGroup(){
	if(!$('#DELGROUP').hasClass('enabled')){return};
	if(confirm($.l10n.__('Addressbook_alert_delgroup'))){
		$("#waiting").show();
		$.ajax({
			url: window.top.remoteDataUrl+"nas/del/addrbook/group"
			,cache:false
			,data:{
				hash:window.top.SessionID
				,name:window.GROUP.name
				}
			,type: "POST"
			,dataType:"xml"
			,success: function(data){
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
				window.GROUP=null;
				loadData();
			}
			,error:function(data){
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}
			//,timeout:20000
		});
	}
}

function editGroup(){
	if(!$('#EDITGROUP').hasClass('enabled')){return};
	var name=prompt( $.l10n.__("Addressbook_text_inputgroup"),$('#grouplist a.selected').html());
	if(!name||name=="")return;
	name=name.replace(/(^\s*)|(\s*$)/g, '');
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/edit/addrbook/group"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,name:window.GROUP.name
			,newname:name
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			window.GROUP.name=name;
			loadData();
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
	});
}


function showAddMember(data){
	$("#memberlist a.selected").removeClass('selected');
	$("#DELMEMBER,#DELFROMGROUP").removeClass("enabled");
	$("#main input").val('');
	$("#edit").show();
	$("#info").hide();
}


function toSave(){
	if($("#memberlist a.selected").length>0)editMember();
	else addMember();
}

function addMember(){
	if(!toValidate())return;
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/add/addrbook/member"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,name:$("#name").val()+'圕'+$("#surname").val()
			,email:$("#email0").val()+'圕'+$("#email1").val()
			,phone:$("#phone0").val()+'圕'+$("#phone1").val()+'圕'+$("#phone2").val()
			,address:$("#address0").val()+'圕'+$("#address1").val()
			,server:$("#server").val()
			,blog:$("#blog").val()	
			,group:window.GROUP.name
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			window.MEMBER={data:{name:$("#name").val()}};
			loadData($("#name").val()+'圕'+$("#surname").val());
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
	});
}

function editMember(){	
	if(!toValidate())return;
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/edit/addrbook/member"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,name:window.MEMBER.data.name
			,newname:$("#name").val()+'圕'+$("#surname").val()
			,email:$("#email0").val()+'圕'+$("#email1").val()
			,phone:$("#phone0").val()+'圕'+$("#phone1").val()+'圕'+$("#phone2").val()
			,address:$("#address0").val()+'圕'+$("#address1").val()
			,server:$("#server").val()
			,blog:$("#blog").val()
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			window.MEMBER.data.name=$("#name").val();
			loadData($("#name").val()+'圕'+$("#surname").val());
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
	});
}


function delMember(){
	if(!$('#DELMEMBER').hasClass('enabled')){return};
	if(confirm($.l10n.__('Addressbook_alert_delmember'))){
		$("#waiting").show();
		$.ajax({
			url: window.top.remoteDataUrl+"nas/del/addrbook/member"
			,cache:false
			,data:{
				hash:window.top.SessionID			
				,name:window.MEMBER.data.name
				}
			,type: "POST"
			,dataType:"xml"
			,success: function(data){
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
				loadData();
			}
			,error:function(data){
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}
			//,timeout:20000
		});
	}
}



function addGroupMember(g,m){
	if(!$('#ADDMEMBER').hasClass('enabled')){return};
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/add/addrbook/groupmember"
		,cache:false
		,data:{
			hash:window.top.SessionID			
			,group:g
			,friend:m
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			$("#grouplist a[name="+g+"]").addClass('unknown');
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
	});
}


function delFromGroup(){
	if(!$('#DELFROMGROUP').hasClass('enabled')){return};
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/del/addrbook/groupmember"
		,cache:false
		,data:{
			hash:window.top.SessionID			
			,group:window.GROUP.name
			,friend:window.MEMBER.data.name
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			$("#grouplist a[name="+window.GROUP.name+"]").addClass('unknown').click();			
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
	});
}


function showImport(){
	window.top.System.opendialog({
		path:''
		,filter:'*.csv|*.*'
		,single:true
		,handler:toImport
		,app:window.top.Addressbook
	});
}

function showExport(){
	window.top.System.opendialog({
		path:''
		,type:'save'
		,filter:'*.csv|*.*'
		,handler:toExport
		,app:window.top.Addressbook
	});

}


function toImport(path){
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/import/addrbook/members"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,path:path
		}
		,traditional:true
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			loadData();		
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
	});
}


function toExport(path){
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/export/addrbook/members"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,path:path
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;	
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
	});
}


function toValidate(){
	var fields = [
		{
			method : 'required',
			value : $('#name').val(), 
			element : $('#name')[0],
			param : null, 
			errParam : $.l10n.__('Addressbook_text_name')
		}
	]
	return validateFields(fields);
	
}
