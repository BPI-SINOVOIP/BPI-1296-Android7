﻿$(function(){
	window.App="Sharings";
	loadLang();	
	layout();
	bindEvent();
	loadData();
});

function layout(){	
	$('body').layout({ 
			center__paneSelector:"#main"
		,	north__paneSelector:"#top"  
		,	north__size:32
		,	north__spacing_open:0		
		,	south__paneSelector:"#bottom"  
		,	south__size:60
		,	south__spacing_open:0
		,	contentSelector:".data"
		//,	center__onresize_end: function(){ }
	}); 
}

function bindEvent(){
	$('#REFRESH').click(toRefresh);
	$('#EDIT').click(toEdit);
}

function loadData(){
	loadShare();
	loadPublish();
	loadAlbum();
};



function loadShare(){
	$('#waiting').show();	
	$.ajax({
	   url: window.top.remoteDataUrl+"nas/get/folder/owner"
	   ,cache:false
	   ,type: "POST"
	   ,data: {
		   hash:window.top.SessionID
		},
	   dataType: "xml",
	   success: function(data){
			$('#waiting').hide();
			if(window.top.checkAPIError(data))return;	
			parseShare(data);
		},
	   error: function(data) { 			   
			$('#waiting').hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//timeout:20000
	});

}

function parseShare(data){	
	$('#sharelist').empty();
	$("[nodeName='D:response']",data).each(function (){
		var li=document.createElement('li');
		var a=document.createElement('a');
		a.path=$("[nodeName='D:href']",this).text();
		$(a).html('<b>'+$("[nodeName='D:displayname']",this).text()+'</b>['+ decodeURI($("[nodeName='D:href']",this).text())+']');
		$(li).append(a).appendTo($('#sharelist'));
		$(a).click(function(){ 
			$('#sharelist li a.selected').removeClass('selected');
			$(this).addClass('selected');
		}).dblclick(function(){
			window.top.loadApp('MyNAS',function(){window.top.MyNAS.share( {app:window.top.Sharings,path:a.path,fn:toRefresh} )})
		});
	});	
}



function loadAlbum(){
	$('#waiting').show();	
	$.ajax({
	   url: window.top.remoteDataUrl+"nas/get/album/owner"
	   ,cache:false
	   ,type: "POST"
	   ,data: {
			hash:window.top.SessionID				   
		}
	   ,dataType: "xml"
	   ,success: function(data){
			$('#waiting').hide();
			if(window.top.checkAPIError(data))return;									
			parseAlbum(data);								
		}
	   ,error: function(data) { 			   
			$('#waiting').hide();
			alert ($.l10n.__("global_alert_getdataerror")); 
		}
		//timeout:20000
	});
}



function parseAlbum(data){
	$('#albumlist').empty();
	$("[nodeName='D:response']",data).each(function (){	
		var path= $("[nodeName='D:displayname']",this).text();
		var cover= $("[nodeName='R:cover']",this).text().split('?')[0];
		var name=path;
		var owner = $("[nodeName='R:author']",this).text();
		if(owner=='')owner= window.top.user; 
		var shareuser=$("[nodeName='R:sharer']",this);
		if(shareuser.length===0) return;
		var shared="shared";
		if(shareuser.length==1){
			if(shareuser.text()=="*")shared="published";
			if(shareuser.text()=="")shared="null";
		}
		var li=document.createElement("li");
		var a=document.createElement("a");
		$(li).addClass(shared);
		$(a).html('<b>'+name+'</b>');		
		$(li).append(a).append('<ul/>').appendTo($('#albumlist'));
		$(a).click(function(){ 
			$('#albumlist li a.selected').removeClass('selected');
			$(this).addClass('selected');	
		}).dblclick(function(){
			cover=cover===''?'/defaultpicture.jpg':cover.replace(window.top.urlpath,'')+'?thumbnail&session='+window.top.SessionID+'&login='+window.top.user; 
			var domain=window.top.location.protocol+"//"+window.top.NASinfo.registername+'.'+$.l10n.__('global_link_domainname');
			var albumurl=domain+'/album.html?author='+window.top.user;
			var albumrss=path+"_"+owner+".rss";
			var code='<a target="_blank" href="'+albumurl+'"><img src="'+domain+cover+'"/></a>'; //<object height="480" width="640" type="application/x-shockwave-flash" data="'+domain+'/cooliris.swf"><param name="allowscriptaccess" value="always"><param name="wmode" value="opaque"><param name="flashvars" value="feed='+encodeURIComponent(domain+'/'+encodeURIComponent(albumrss))+'"></object>
			window.top.loadApp('AlbumMaker',function(){window.top.AlbumMaker.share( {app:window.top.Sharings,path:path, shared:shared, info:shareuser, code:code, fn:toRefresh} )});
		});
	});
}


function loadPublish(){	
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/publish"
		,cache:false
		,data:{
			hash:window.top.SessionID
			}
		,type: "POST"
		,dataType:"xml"
		,traditional:true
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parsePublish(data);
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}



function parsePublish(data){
	$('#publishlist').empty();
	var p=[];
	$("record",data).each(function (){
		var li=document.createElement('li');
		var a=document.createElement('a');
		var path=$("path",this).text();
		if($.inArray(path,p)===-1){
			p.push(path);
			a.path=path;
			try{path=decodeURI(path);}catch(e){};
			$(a).html('<b>'+path+'</b>');
			$(li).append(a).appendTo($('#publishlist'));
			$(a).click(function(){ 
				$('#publishlist li a.selected').removeClass('selected');
				$(this).addClass('selected');
			}).dblclick(function(){
				window.top.loadApp('MyNAS',function(){window.top.MyNAS.publish( {app:window.top.Sharings,path:a.path,fn:toRefresh} )})
			});
		}
	});	
}


function toRefresh(){
	var t=$('ul.tabs a.selected').attr('href');
	switch(t){
		case '#share':
			loadShare();
		break;
		case '#publish':
			loadPublish();
		break;
		case '#album':
			loadAlbum();
		break;
	}
}


function toEdit(){
	var t=$('ul.tabs a.selected').attr('href'); 
	$(t+' a.selected').dblclick();
}