﻿$(function(){
	window.App="Downloader";	
	layout();
	loadLang();
	bindEvent();

});

function bindEvent(){
	$("#ADD").click(toAdd);
	$("#UPLOAD").click(toUpload);
	$("#CLEAR").click(toClear);
	$("#START").click(toStart);
	$("#PAUSE").click(toPause);
	$("#INFO").click(toInfo);
	$("#REFRESH").click(function(){ loadData($("#list ul a.selected")[0].id);	});
	$("#DIR").click(toDir);
	$("#SEEDDIR").click(toSeedDir);
	$("#list ul a").click(function(){	loadData(this.id);	});
	$("#all").click();
}

function loadData(option){
		option=(option=="all")?"":option;
		$("#waiting").show();
		$.ajax({			   
		   url: window.top.remoteDataUrl + 'submit?q=vd+' + option
		   ,type: "GET"
		   ,cache:false
		   ,dataType: "text"
		   ,success: function(data){
				$("#waiting").hide();
				showData(data);
			}
		   ,error: function(data) {
				$("#waiting").hide();
				alert($.l10n.__('Downloader_alert_noservice'));
			}
		   //,timeout: 10000
		 });
}


function layout(){
	window.Layout = $('body').layout({ 
			center__paneSelector:"#main" 
		,	north__paneSelector:"#top" 
		,	north__size:60
		,	north__spacing_open:0
		,	west__paneSelector:"#left" 
		,	west__size:200
		,	west__spacing_open:5
		,	contentSelector:".data"	
		,	center__onresize_end:function(){
				$(window).resize();
			}
	}); 
	$('#toolbar').toolbar();
	$("#list").treeview();
}

function showData(data){
	if(!window.grid){
		$("#main").html('<table/>');
		window.grid=$("#main table:first")[0];
		$(window.grid).flexigrid({
			singleSelect:false
			,colModel : [
				{display: '<label domain="l10n" msgid="Downloader_text_status"></label>', name : 'S', width : 24, sortable : false, align: 'left'}
				,{display: '<label domain="l10n" msgid="Downloader_text_network"></label>', name : 'N', width : 60, sortable : false, align: 'left',hide:true}
				,{display: '<label domain="l10n" msgid="Downloader_text_file"></label>', name : 'File', width : 150, sortable : false, align: 'left'}
				,{display: '<label domain="l10n" msgid="Downloader_text_size"></label>', name : 'Size', width : 50, sortable : false, align: 'left'}
				,{display: '<label domain="l10n" msgid="Downloader_text_progress"></label>', name : 'Percentage', width : 100, sortable : false, align: 'left'}
				,{display: '<label domain="l10n" msgid="Downloader_text_dowloaded"></label>', name : 'DLed', width : 60, sortable : false, align: 'left'}
				,{display: '<label domain="l10n" msgid="Downloader_text_comments"></label>', name : 'Cm', width : 60, sortable : false, align: 'left',hide:true}
				,{display: '<label domain="l10n" msgid="Downloader_text_sources"></label>', name : 'Src', width : 60, sortable : false, align: 'left',hide:true}
				,{display: '<label domain="l10n" msgid="Downloader_text_active"></label>', name : 'A', width : 60, sortable : false, align: 'left'}
				,{display: '<label domain="l10n" msgid="Downloader_text_avail"></label>', name : 'Avail', width : 60, sortable : false, align: 'left',hide:true}
				,{display: '<label domain="l10n" msgid="Downloader_text_age"></label>', name : 'Age', width : 60, sortable : false, align: 'left',hide:true}
				,{display: '<label domain="l10n" msgid="Downloader_text_last"></label>', name : 'Last', width : 60, sortable : false, align: 'left',hide:true}
				,{display: '<label domain="l10n" msgid="Downloader_text_rate"></label>', name : 'Rate', width : 60, sortable : false, align: 'left'}
				,{display: '<label domain="l10n" msgid="Downloader_text_ETA"></label>', name : 'ETA', width : 60, sortable : false, align: 'left',hide:true}
				,{display: '<label domain="l10n" msgid="Downloader_text_priority"></label>', name : 'Priority', width : 60, sortable : false, align: 'left',hide:true}
			]
		}); 
		window.setLang({app:window.App,el:$("#main")}); 
	}else{
		$('tr',window.grid).remove();
	}
	if($("#temp").length==0)$("body").append('<div id="temp" style="display:none;"></div>');
	$("#temp").html(data);	
	
	 var table=($("#temp table.downloaders"));
	 $("tr:first, table",table).remove();
	 $(table.children(0).children()).each(function(){ 
		 var id=$("input:checkbox:first",this).val(); 
		 var tds=$(">td",this);
		 var S=tds[0].innerHTML; 
		 var Status=(S=="P")?"paused":"";
		 S=(S=="P")?'<a class="icon s12 downloadstop"></a>':'<a class="icon s12 download"></a>';
		 //var R=tds[1].innerHTML; 
		 //var C=tds[2].innerHTML; 
		 //var R2=tds[3].innerHTML; 
		 var N=tds[4].innerHTML; 
		 var File=tds[5].innerHTML; 
		 var Size=tds[6].innerHTML; 
		 var Dowloaded=tds[7].innerHTML; 
		 var Percentage=tds[8].innerHTML+"%"; Percentage="<div class='progressbar' style='padding:0;margin:0;width:100%;'><div style='padding:0;margin:0;width:"+Percentage+"'></div><span>"+Percentage+"</span></div>";
		 var Cm=tds[9].innerHTML; 
		 var Src=tds[10].innerHTML; 
		 var A=tds[11].innerHTML; 
		 var Avail=tds[12].innerHTML; 
		 var Age=tds[13].innerHTML; 
		 var Last=tds[14].innerHTML; 
		 var Rate=tds[15].innerHTML; 
		 var ETA=tds[16].innerHTML; 
		 var Priority=tds[17].innerHTML; 
		window.grid.grid.addRow({
				id:id
				,S:S
				//,R:R
				//,C:C 
				//,R2:R2
				,N:N
				,File:File
				,Size:Size
				,Percentage:Percentage
				,DLed:Dowloaded
				//,Percentage:Percentage
				,Cm:Cm
				,Src:Src
				,A:A
				,Avail:Avail
				,Age:Age
				,Last:Last
				,Rate:Rate
				,ETA:ETA
				,Priority:Priority
		});
		
		$('tr:last',window.grid).addClass(Status); 
		
	});
	$("#temp").remove();
	enableTools();
	$('tr',window.grid).click(function(){
		itemEvent();
	}).dblclick(function(){		
		$("tr",window.gird).removeClass('trSelected');
		$(this).click();
		$("#INFO").click();
	});
	$('select',window.grid).change(function(){ 
		toSetPriority(this);
	});

} 

function enableTools(){
	$("#DOWNLOADER li").removeClass('enabled');
	$("#ADD, #REFRESH, #UPLOAD, #DIR, #SEEDDIR").addClass("enabled");
}

function itemEvent(){
	var trs=$("tr.trSelected",window.grid);
		if(trs.length>0){
			$("#CLEAR").addClass('enabled'); 
			if(trs.length==1){
				$("#INFO").addClass('enabled');
				if( trs.hasClass('paused') ){
					$("#START").addClass('enabled');
					$("#PAUSE").removeClass('enabled');
				}
				else{
					$("#START").removeClass('enabled');
					$("#PAUSE").addClass('enabled');
				}
			}
			else{
				$("#INFO").removeClass('enabled');
				$("#START").addClass('enabled');
				$("#PAUSE").addClass('enabled');
			}
		}
		else{
			enableTools();
		}
}


function toAdd(){
	if(!$("#ADD").hasClass('enabled'))return;
	var name=prompt($.l10n.__("Downloder_text_downloadurl"),"");
	if(name==null||name.replace(/\s/g,"")=="")return;
	$.ajax({
		url:window.top.remoteDataUrl +'submit'
		,type: "GET"
		,data:{q:name}
		,dataType: "text"
		,success: function(data){
			$("#waiting").hide();
			$("#REFRESH").click();
		}
		,error: function(data) {
		$("#waiting").hide();
		}
		   //,timeout: 10000
		});
}



function toClear(){
	if(!$("#CLEAR").hasClass('enabled'))return;
	var trs=window.grid.grid.getSelectedRows();
	var s="";
	for(var i=0;i<trs.length;i++){
		s += "&cancel="+trs[i].id;
	}
	$.ajax({
		   url:window.top.remoteDataUrl +'files'
		   ,type: "GET"
		   ,data:s
		   ,cache:false
		   ,dataType: "text"
		   ,success: function(data){
				$("#waiting").hide();
				$("#REFRESH").click();
			}
		   ,error: function(data) {
				$("#waiting").hide();
			}
		   //,timeout: 10000
		 });
}


function toStart(){
	if(!$("#START").hasClass('enabled'))return;
	var trs=window.grid.grid.getSelectedRows();
	var s="";
	for(var i=0;i<trs.length;i++){
		s += "&resume="+trs[i].id;
	}
	$.ajax({
		   url:window.top.remoteDataUrl +'files'
		   ,type: "GET"
		   ,data:s
		   ,cache:false
		   ,dataType: "text"
		   ,success: function(data){
				$("#waiting").hide();
				$("#REFRESH").click();
			}
		   ,error: function(data) {
				$("#waiting").hide();
			}
		   //,timeout: 10000
		 });
}

function toPause(){
	if(!$("#PAUSE").hasClass('enabled'))return; 
	var trs=window.grid.grid.getSelectedRows();
	var s=""; 
	for(var i=0;i<trs.length;i++){
		s += "&pause="+trs[i].id;
	}
	$.ajax({
		   url:window.top.remoteDataUrl +'files'
		   ,type: "GET"
		   ,data:s
		   ,cache:false
		   ,dataType: "text"
		   ,success: function(data){
				$("#waiting").hide();
				$("#REFRESH").click();
			}
		   ,error: function(data) {
				$("#waiting").hide();
			}
		   //,timeout: 10000
		 });
}


function toSetPriority(s){
	$.ajax({
		   url:window.top.remoteDataUrl +'submit?q=priority+'+s.value+"+"+s.id.replace('selectPriority','')
		   ,type: "GET"
		   ,dataType: "text"
		   ,cache:false
		   ,success: function(data){
				$("#waiting").hide();
				$("#REFRESH").click();
			}
		   ,error: function(data) {
				$("#waiting").hide();
			}
		   //,timeout: 10000
		 });
}


function toInfo(){
	if(!$("#INFO").hasClass('enabled'))return;
	var trs=window.grid.grid.getSelectedRows();
	window.top.Downloader.Info(trs[0].id);
}

function toUpload(){
	if(!$("#UPLOAD").hasClass('enabled'))return;
	window.top.System.toUpload(window.top.root+'downloads/torrents/incoming/');
}


function toDir(){
	window.top.System.viewDir(window.top.root+'downloads/incoming/');
}


function toSeedDir(){
	window.top.System.viewDir(window.top.root+'downloads/torrents/seeded/');
}