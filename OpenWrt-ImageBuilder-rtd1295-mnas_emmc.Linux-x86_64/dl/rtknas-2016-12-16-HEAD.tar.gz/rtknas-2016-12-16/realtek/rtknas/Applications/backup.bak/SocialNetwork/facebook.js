﻿$(function(){				
		var access_token=getRequest('access_token');
		if(access_token&&access_token!==''){
			window.opener.init(access_token);
			window.close();
			return;
		}
		window.App="SocialNetwork";	
		layout();
		loadLang();	
		bindEvent();
		init();
});



function layout(){	
	$('body').layout({ 
			center__paneSelector:"#main"
		,	north__paneSelector:"#top"  
		,	north__size:80
		,	north__spacing_open:0
		,	west__paneSelector:"#left"  
		,	west__size:200
		,	west__spacing_open:0
		//,	center__minWidth:400
		,	contentSelector:".data"
	}); 
}

function init(access_token){
	if(access_token)window.top.facebooktoken=access_token;
	if(window.top.facebooktoken){
		loadUserInfo();	
		loadAlbum();
		$('#login').hide();
		$('#logout,#REFRESH').show();
	}
	else{
		$('#login').show();
		$('#logout,#REFRESH').hide();
		$('#login').click();
	}
}
	  
function toLogout(){
	window.open('http://www.facebook.com/','_blank');
	$('#login').show();
	$('#logout,#REFRESH').hide();	
	$('#username').html('');
	$('#userphoto').attr('src','icons/user.gif');
	window.top.facebooktoken=null;
	$('#tree,#data').empty();

}


function loadUserInfo(){
	$('#waiting').show();
	FB({
	   url:'me'
	   ,callback:'showUserinfo'
	})
}



function showUserinfo(resp){
	$('#waiting').hide();
	if(isError(resp)) return;
	$('#username').html( resp.name ); 
	$('#userphoto').attr( 'src','https://graph.facebook.com/'+resp.id+'/picture' ); 
}



function loadAlbum() {
	$('#waiting').show();
	FB({
	   url:'me/albums'
	   ,callback:'showAlbum'
	})
};



function showAlbum(resp){
	$('#waiting').hide();
	if(isError(resp)) return; 
	var data=resp.data;
	var a=$('#tree a.selected');
	if(a.length>0)var id=a.data.id;
	$('#tree').html('<ul class="normallist album"></ul>');
	var $ul=$('#tree ul');
	
	
    for (var i=0, l=data.length; i<l; i++) {
		var album = data[i],
        li = document.createElement('li'),
        a = document.createElement('a');
		a.data={
			id: album.id
			,name:album.name
			//,description: $('description',this).text()
			,link:album.link
		}; 
		a.id='album'+album.id;
		a.innerHTML = album.name;
		a.className='unknown';
		//a.href = album.link;
		$(li).append(a).appendTo($ul);
    }
	
	$('a',$ul).click(function(){
		$('#tree a.selected').removeClass('selected');
		$(this).addClass('selected');
		if($(this).hasClass('unknown')){
			loadContent();
		}else{
			showContent(this.data.resp);
		}
	});
	var a=$('#album'+id,$ul);
	if(a.length==0)a=$('a:first',$ul);
	a.click();
	
}


function loadContent(){
	$('#waiting').show();
	var id=$("#tree a.selected")[0].data.id;
	FB({
	   url:id+'/photos'
	   ,callback:'showContent'
	})
	
}

function showContent(resp){
	$('#waiting').hide();
	if(isError(resp)) return;
	$('#tree a.selected').removeClass('unknown');
	var data=resp.data;
	$('#tree a.selected')[0].data.resp=resp;
	$('#data').html('');
	 for (var i=0, l=data.length; i<l; i++) {
		var photo = data[i];
		var div=document.createElement('div');
		div.data={
			id:photo.id
		}
		div.style.cssText='background:#f2f2f2 url('+photo.picture+') no-repeat center center;float:left;';
		$('#data').append(div);
    }
	$('#data div').click(function(){
		$('#data div.selected').removeClass('selected');
		$(this).addClass('selected');		
	});
	
}


function showUpload(){
	if($('#tree a.selected').length===0)return;
	window.top.System.opendialog({
		app:window.top.SocialNetwork
		,filter:'image'
		,handler:toUpload
	});
}


function toUpload(items){
	var album=$('#tree a.selected')
	if(album.length==0)return;
	var albumid=album[0].data.id;
	var l=items.length;
	while(l--){
		$("#waiting").show();
		$.ajax({
			url: window.top.remoteDataUrl+"nas/facebook/uploadphoto"
			,cache:false
			,data:{
				hash:window.top.SessionID
				,access_token:window.top.facebooktoken
				,albumid:albumid
				,path:decodeURI(items[l])
			}
			,type: "POST"
			,dataType:"xml"
			,success: function(data){
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
				var src=$('picture',data).text();
				$('#data').append('<div style="background:url('+src+') no-repeat center center;width:130px;height:130px;margin:2px;float:left;"></div>');
				album.addClass('unknown');
			}
			,error:function(data){
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}
			//,timeout:20000
			
		});
	}
}



function toCreate(){
	if(!window.top.facebooktoken)return;
	var name=prompt($.l10n.__('SocialNetwork_text_newalbum'),'');
	if(!name||name=='')return;
	$("#waiting").show();
	//FB('me/albums', 'name='+encodeURIComponent(name), 'loadAlbum','post');
	FB({
	   url:'me/albums'
	   ,callback:'loadAlbum'
	   ,method:'post'
	   ,name:name
	})
}


function isError(resp){
	if (!resp || resp.error){
		alert(resp.error.error_msg);
		return true;
	}
	return false;
}


function FB(data){
	//url='https://graph.facebook.com/'+url;
	//if(!method)method='get';
	//$.getScript(url+'?access_token='+window.top.facebooktoken+'&callback='+callback+'&method='+method+'&'+data);
	
	var url='https://graph.facebook.com/'+data.url;
	data.url=null;
	data.access_token=window.top.facebooktoken;
	if(!data.method)data.method='get';
	$.getScript(url+'?'+$.param(data));
}






function bindEvent(){	
	
	$('#login').unbind().click(function() {
		window.open('https://graph.facebook.com/oauth/authorize?scope=publish_stream%2Cuser_photos&client_id=166117803477556&type=user_agent&display=popup&redirect_uri='+'http://myisharing.com/fb.html?origin='+encodeURIComponent(window.top.urlpath+'Applications/SocialNetwork/facebook.html'),'_blank','width=600,height=400,toolbar=0,menubar=0');
	});
	
	$('#logout').unbind().click(toLogout);	
	$('#CREATE').unbind().click(toCreate);	
	$('#UPLOAD').unbind().click(showUpload);
	$('#REFRESH').unbind().click(init);
	
	var win=window.win.mask;
	var thiswin=window;
	window.top.$(win)
		.droppable('destroy')
		.droppable({
		accept:'#main li.image'
		,drop: function(event, ui) {
				var curWin=window.win;
				var $C;
				if(curWin.id=='App_MyNAS_Win_main')$C=window.top.MyNAS.mainWin.content.$C;
				if(curWin.id=='App_AlbumMaker_Win_main')$C=window.top.AlbumMaker.mainWin.content.$C; 
				var items=(ui.draggable.hasClass('image'))?[ui.draggable[0]]:null;
				if(ui.draggable.hasClass('selected')){
					var lis=window.top.$('li.selected.image',$C); 
					if(lis.length>0){
						items=null;
						items=lis; 
					}
				}
				if (!items)return;
				var itempaths=[]; 
				for(var i=0;i<items.length;i++){
					itempaths.push(items[i].getAttribute('webview').replace('&webview','').replace('session='+window.top.SessionID,'').replace('login='+window.top.user,''));
				};			 
				thiswin.toUpload(itempaths);
		}
		,hoverClass: 'drophover'
	});
		
}
	  