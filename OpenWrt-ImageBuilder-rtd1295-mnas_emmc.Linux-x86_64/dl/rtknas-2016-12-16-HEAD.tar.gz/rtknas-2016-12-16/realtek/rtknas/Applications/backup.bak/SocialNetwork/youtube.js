﻿$(function(){
	  
	window.App="SocialNetwork";	
	loadLang();	
	layout();
	bindEvent();
	init();
});


function layout(){
	$('body').layout({ 
			center__paneSelector:"#main"
		,	north__paneSelector:"#top"  
		,	north__size:80
		,	north__spacing_open:0
		//,	center__minWidth:400
		,	contentSelector:".data"
	}); 
}



function init(){ 
	if(window.top.youtubetoken){
		loadData();
		return;
	}	
	
 	var token=getRequest("token"); 
	if(!token||token===''){
		$('#login').show();
		$('#logout,#REFRESH').hide();
		$('#login').click();
		return;
	}
	else{
		token=decodeURIComponent(token);
		window.opener.getSessiontoken(token);
		window.close();
	}
}

function toLogout(){
	window.open('http://www.youtube.com/','_blank');
	$('#login').show();
	$('#logout,#REFRESH').hide();
	$('#username').html('');
	$('#userphoto').attr('src','icons/user.gif');
	window.top.youtubetoken=null;
	$('#tree,#data').empty();
}


function getSessiontoken(token){
	    $("#waiting").show();		
		$.ajax({
			url:window.top.remoteDataUrl+"nas/youtube/proxy/"
			,cache:false
			,data:{
			    hash:window.top.SessionID
			    ,host:'www.google.com'
			    ,path:'/accounts/AuthSubSessionToken'
			    ,token:token
			}
			,type: "GET"
			,dataType:"text"
			,success: function(data){ 
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
				window.top.youtubetoken=data.split('Token=')[1];
				bindEvent();
				loadData();
			}
			,error:function(data){
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}			
		});
}





function loadData(){
	$('#login').hide();
	$('#logout,#REFRESH').show();	
	$("#waiting").show();	
	$.ajax({
			url:window.top.remoteDataUrl+"nas/youtube/proxy/"
			,cache:false
			,data:{
				hash:window.top.SessionID
			    	,host:'gdata.youtube.com'
			    	,path:'/feeds/api/users/default/uploads'  //&alt=json-in-script&callback=parseData
			   	,token:window.top.youtubetoken
			}
			,type: "GET"
			,dataType:"xml"
			,complete: function(HTTPRequest){ 
				$("#waiting").hide();
				var data=stringToXML(HTTPRequest.responseText);
				if(window.top.checkAPIError(data))return;
				parseData(data);
			}
	});
	$.ajax({
			url:window.top.remoteDataUrl+"nas/youtube/proxy/"
			,cache:false
			,data:{
				hash:window.top.SessionID
			    	,host:'gdata.youtube.com'
			    	,path:'/feeds/api/users/default'  //&alt=json-in-script&callback=parseData
			   	,token:window.top.youtubetoken
			}
			,type: "GET"
			,dataType:"xml"
			,complete: function(HTTPRequest){ 
				$("#waiting").hide(); 
				var data=stringToXML(HTTPRequest.responseText);
				if(window.top.checkAPIError(data))return;
				parseUser(data);
			}
	});
}



function parseUser(data){
	$('#username').html( $('[nodeName="yt:username"]',data).text() ); 
	$('#userphoto').attr( 'src',$('[nodeName="media:thumbnail"]',data).attr('url') ); 
}


function parseData(data){
	$('#data').empty();
	addItem(data);
}


function addItem(data){
	$('entry',data).each(function(){
		var div=document.createElement('div');
		var title = $('title',this).text(); 
		var thumbnail=$("[nodeName='media:thumbnail']:first",this).attr('url');
		var img=document.createElement('img');
		img.src=thumbnail;
		var label=document.createElement('label');
		label.innerHTML=title;
		$(div).append(img).append(label).appendTo($('#data'));
		$(div).click(function(){
			$('div.selected').removeClass('selected');
			$(this).addClass('selected');
		});
	});
}


function showUpload(){
	if(!window.top.youtubetoken)return;
	window.top.System.opendialog({
		app:window.top.SocialNetwork
		,filter:'media|*.*'
		,handler:toUpload
	});
}


function toUpload(items){
	var l=items.length;
	while(l--){
		$("#waiting").show();
		$.ajax({
			url: window.top.remoteDataUrl+"nas/youtube/upload"
			,cache:false
			,data:{
				hash:window.top.SessionID
				,token:window.top.youtubetoken
				,path:decodeURI(items[l])
			}
			,type: "POST"
			,dataType:"xml"
			,success: function(data){
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
				addItem(data);
			}
			,error:function(data){
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}
			//,timeout:20000
			
		});
	}
}


function bindEvent(){	
  if(!window.top.youtubetoken){
	$('#login').unbind().click(function() {
		window.top.youtubetoken=null; 					   	
		window.open('https://www.google.com/accounts/AuthSubRequest?next='+window.location+'&scope=http://gdata.youtube.com&session=1&secure=0','_blank','width=1000,height=500,toolbar=0,menubar=0');		
	});	
  }else{
	$('#UPLOAD').unbind().click(showUpload);		
	$('#REFRESH').unbind().click(init);
	$('#logout').unbind().click(toLogout);	
	
	var win=window.win.mask;
	var thiswin=window; 
	window.top.$(win)
		.droppable('destroy')
		.droppable({
		accept:'#main li.file'
		,drop: function(event, ui) {
				var curWin=window.win;
				var $C;
				if(curWin.id=='App_MyNAS_Win_main')$C=window.top.MyNAS.mainWin.content.$C;
				if(curWin.id=='App_AlbumMaker_Win_main')$C=window.top.AlbumMaker.mainWin.content.$C; 
				var items=(ui.draggable.hasClass('image'))?[ui.draggable[0]]:null;
				if(ui.draggable.hasClass('selected')){
					var lis=window.top.$('li.selected.file',$C); 
					if(lis.length>0){
						items=null;
						items=lis; 
					}
				}
				if (!items)return;
				var itempaths=[]; 
				for(var i=0;i<items.length;i++){
					itempaths.push(items[i].getAttribute('webview').replace('?webview','?').replace('session='+window.top.SessionID,'').replace('login='+window.top.user,''));
				}; 
				thiswin.toUpload(itempaths);
		}
		,hoverClass: 'drophover'
	});	
	}
}