﻿$(function(){
	window.App="SocialNetwork";
	loadLang();	
	bindEvent();

});


function bindEvent(){
	$("#facebook").click(function(){		
		window.top.SocialNetwork.facebook();
	});

	$("#flickr").click(function(){		
		window.top.SocialNetwork.flickr();
	});
	
	$("#youtube").click(function(){		
		window.top.SocialNetwork.youtube();
	});
	
	$("#picasa").click(function(){		
		//window.top.SocialNetwork.picasa();
	});
	
	
	//$("#dropbox").click(function(){		
		//window.top.SocialNetwork.dropbox();
	//});
	
	
	
	$("#renren").click(function(){		
		window.top.SocialNetwork.renren();
	});
}