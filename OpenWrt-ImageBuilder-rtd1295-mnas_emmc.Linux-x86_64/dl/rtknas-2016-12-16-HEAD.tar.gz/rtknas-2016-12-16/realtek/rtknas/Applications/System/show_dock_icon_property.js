﻿$(function(){	
	window.App="System";
	bindEvent();
	loadLang();
	loadData();
});


function bindEvent(){
	$("#CANCEL").click(function(){		
		window.win.closeWin();
	});	
	$("#BROWSE").click(showDialog);
	$("#REMOVE").click(toRemove);
}

function loadData(){
	var o=window.win.fromWinObject;
	var icon=o.icon;
	window.ICON=icon; 
	var customedicon=icon.customedicon;
	var src=icon.original_iconpath;
	var name='<label domain="l10n" msgid="'+icon.name+'">'+$.l10n.__(icon.name)+'<label>'; 
	$('#icon').hide().attr('src',src);
	$('#customedicon').hide().attr('src',icon.customedicon+'?hash='+window.top.SessionID+(/(\.png|\.gif)$/.test(icon.customedicon)?'':'&thumbnail')).show();		
	if(icon.customedicon!==''){
		$('#icon').hide();
		$('#customedicon').show();
		$('#REMOVE').show();
	}else{
		$('#icon').attr('src',src).show();
		$('#customedicon').hide();
		$('#REMOVE').hide();
	}	
	$('#name').html(name);
}


function showDialog(){
	window.top.System.opendialog({
		path:''
		,filter:'image'
		,single:true
		,handler:toChange
		,app:window.top.System
	});
}


function toRemove(path){
	$('#icon').show();
	$('#customedicon').hide();
	$('#REMOVE').hide();
	window.ICON.customedicon='';
	setDock();
}



function toChange(path){
	$('#icon').hide();
	$('#customedicon').attr('src',path+'?hash='+window.top.SessionID+(/(\.png|\.gif)$/.test(path)?'':'&thumbnail')).show();
	$('#REMOVE').show();
	window.ICON.customedicon=decodeURI(path);
	setDock();
}


function setDock(){
	window.top.Dean.OS.Desktop.resetDockIcon(window.ICON);
	window.top.Dean.OS.Desktop.changeDockXML(window.ICON);
	window.top.Dean.OS.Desktop.putDockXML();
}
