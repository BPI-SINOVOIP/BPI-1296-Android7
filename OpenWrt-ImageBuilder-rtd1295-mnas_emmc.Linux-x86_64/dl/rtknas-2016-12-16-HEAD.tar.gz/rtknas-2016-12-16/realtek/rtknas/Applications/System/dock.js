﻿$(function(){
	window.App="System";
	loadLang();	
	bindEvent();
	loadData();
});


function bindEvent(){
	$("#APPLY").click(toApply);
	$("#CANCEL").click(function(){window.win.closeWin();});
	$('#restore').click(function(){
		window.top.Dean.OS.Desktop.restoreDock();
	});
}



function loadData(){
	$.ajax({
		url:window.top.root+'home/.dock.conf'
		,data:{
			hash:window.top.SessionID
		}
		,type:'get'
		,cache:false
		,dataType:'xml'
		,success:function(data){parseData(data);}
		,error:function(data){loadDefaultData();}
	});
}

function loadDefaultData(){
	$.ajax({
		url:window.top.urlpath+'Applications/System/dock.conf.xml'
		,type:'get'
		,dataType:'xml'
		,success:function(data){window.DockXML=data;parseData(data);}
	});

}


function parseData(data){
	var ps=$('dock preferences',data); 
	$('#size').val($('size',ps).text());
	$('#zoom').val($('zoom',ps).text());
	if($('autohide',ps).text()==='true')$('#autohide').attr('checked','checked');
	else $('#autohide').removeAttr('checked');
	$('input:radio[value='+$('position',ps).text().toLowerCase()+']').attr('checked','checked');	
}





function toApply(){
	if(!toValidate())return;
	var p={
		size:$("#size").val()-0
		,zoom:$("#zoom").val()-0
		,align:$("input[name='align']:checked").val()
		,idle:$("#autohide").is(':checked')?1000:0
		,autohide:$("#autohide").is(':checked')
	}
	window.top.Dean.OS.Desktop.setDock(p);
	toSave(p);
}




function toSave(preferences){
	//try{if(window.top.NASinfo.storage.writable==='no'){window.top.System.NoHome();return;}}catch(e){}
	var xml='<?xml version="1.0" encoding="UTF-8"?><dock><preferences><size>'+preferences.size+'</size><position>'+preferences.align+'</position><zoom>'+preferences.zoom+'</zoom><autohide>'+preferences.autohide+'</autohide></preferences></dock>';
	var options = {
            content: xml
            ,content_type:  'text/xml'                   
	};
	window.top.webdav.PUT({}, window.top.root+'home/.dock.conf', options);
}


function toValidate(){
	var fields = [
		{
			method : 'required',
			value : $('#size').val(), 
			element : $('#size')[0],
			param : null, 
			errParam : $.l10n.__('System_dock_text_size')
		}
		,{
			method : 'required',
			value : $('#zoom').val(), 
			element : $('#zoom')[0],
			param : null, 
			errParam : $.l10n.__('System_dock_text_zoom')
		}
		,{
			method : 'range',
			value : $('#size').val(), 
			element : $('#size')[0],
			param : [16,128], 
			errParam : [$.l10n.__("System_dock_text_size"),16,128]
		}
		,{
			method : 'range',
			value : $('#zoom').val(), 
			element : $('#zoom')[0],
			param : [1,6], 
			errParam : [$.l10n.__("System_dock_text_zoom"),1,6]
		}
	]
	return validateFields(fields);
	
}
