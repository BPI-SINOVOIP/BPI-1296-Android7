﻿$(function(){	
	window.App="System";
	loadLang();
	$("body,#close").click(function(){	window.win.closeWin();	});
})
