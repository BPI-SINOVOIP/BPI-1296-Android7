﻿$(function(){
	window.App="System";
	loadLang();
	$("#quit").click(function(){	quit();	});
	$("#logout").click(function(){	restart();	});
	$("#cancel").click(function(){	cancel();	});
	if(window.top.privilege!=='0')$("#quit").remove();
})


function cancel(){
	window.parent.curWin.closeWin();
}
function quit(){
	/*logout(	function(){
		window.open(window.top.urlpath,"_top");
		window.top.close();		
	});*/
	window.location="../Preference/poweroff.html";
}
function restart(){
	logout(	function(){window.open(window.top.urlpath,"_top");}	);
	
}

function logout(fn){
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/logout"
		,data:{
			hash:window.top.SessionID
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			if(window.top.checkAPIError(data))return;
			fn.apply();
		}		
		,error:function(data){
			fn.apply();
		}
	});
}