﻿$(function(){	
	window.App="MyNAS";
	bindEvent();
	loadLang();
	loadData();
});


function bindEvent(){
	$("#CANCEL").click(function(){		
		window.win.closeWin();
	});
	$("#SAVE").click(toSave);
	$("#RESET").click(toReset);
}

function loadData(o){
	var o=$.extend({
		size:window.win.fromWinObject.data.size
		,grid:window.win.fromWinObject.data.grid
		,text:window.win.fromWinObject.data.text
	},o);
	$('#size').text(o.size);
	$('#grid').text(o.grid);
	$('#text').text(o.text);

	$('#iconsize').slider('destory').slider({
		value:o.size,
		min: 64,
		max: 256,
		step: 8,
		slide: function( event, ui ) {
			$('#size').text(ui.value);
			toChange();
		},
		stop:function(){
			window.win.fromWinObject.save();
		}
	});
	$('#gridsize').slider('destory').slider({
		value:o.grid,
		min: 0,
		max: 128,
		step: 1,
		slide: function( event, ui ) {
			$('#grid').text(ui.value);
			toChange();
		},
		stop:function(){
			window.win.fromWinObject.save();
		}
	});
	$('#textsize').slider('destory').slider({
		value:o.text,
		min: 11,
		max: 22,
		step: 1,
		slide: function( event, ui ) {
			$('#text').text(ui.value);
			toChange();
		},
		stop:toSave
	});
}


function toChange(){
	window.win.fromWinObject.change({
		size:$('#size').text()-0
		,grid:$('#grid').text()-0
		,text:$('#text').text()-0
		,changeicon:true
		,save:false
	});
}

function toSave(){
	window.win.fromWinObject.save();
}

function toReset(){
	loadData({size:64, grid:16, text:12});
	window.win.fromWinObject.change({
		size:$('#size').text()-0
		,grid:$('#grid').text()-0
		,text:$('#text').text()-0
		,changeicon:true
		,save:true
	});
	//window.win.closeWin();
}


