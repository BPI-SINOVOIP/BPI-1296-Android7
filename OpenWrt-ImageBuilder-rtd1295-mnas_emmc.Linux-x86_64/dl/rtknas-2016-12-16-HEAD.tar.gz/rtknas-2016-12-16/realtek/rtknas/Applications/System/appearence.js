﻿$(function(){	
	window.App="System";
	bindEvent();
	loadLang();
	loadThemes();
	loadAppearence();
});


function bindEvent(){		
	$("#check").click(function(){
		if($(this).is(':checked')){
			$("#interval").removeAttr('disabled');
			$('#nopic').removeAttr('checked').attr('disabled','disabled');
		}
		else{
			$('#nopic,#interval').removeAttr('disabled');
		}
	});
	
	$("#nopic").click(function(){
		if($(this).is(':checked')){
			$('#check').removeAttr('checked').attr('disabled','disabled');
			$("#interval,#position").attr('disabled','disabled');
		}
		else{
			$('#check,#position,#interval').removeAttr('disabled');
		}
	});
	
	
	$("#interval").keyup(function(event){  
		var v=$(this).val().replace(/[^\d]/g,'')					  
		$(this).val(v);	
	}).blur(function(){
		var v=$(this).val().replace(/[^\d]/g,'')					  
		$(this).val(v);	
	});
	
	
	$("#APPLY").click(function(){	apply();	});
	
	$("#CANCEL").click(function(){		
		window.win.closeWin();
	});
	
	$("#SYSTEM").click(function(){	loadSystemPath();	});
	$("#OPEN").click(function(){	window.top.System.selectDir({handler: loadPath});	});
}

function loadAppearence(){
	$.ajax({
		url:window.top.root+'home/.appearence.conf'
		,data:{
			hash:window.top.SessionID
		}
		,type:'get'
		,dataType:'xml'
		,success:function(data){parseAppearence(data);}
		,error:function(data){loadDefaultAppearence();}
	});
};

function loadDefaultAppearence(){
	$.ajax({
		url:window.top.urlpath+'Configurations/System/appearence.conf.xml'
		,type:'get'
		,dataType:'xml'
		,success:function(data){parseAppearence(data);}
	});

};


function parseAppearence(data){
	var preferences={
		bgcolor:$('bgcolor',data).text()
		,image:{
			show:$('image show',data).text()
			,url:$('image url',data).text()
			,position:$('image position',data).text()
		}
		,slideshow:{
			show:$('slideshow show',data).text()
			,path:$('slideshow path',data).text()
			,interval:$('slideshow interval',data).text()
		}
		,theme:$('theme',data).text()		
		,lang:$('lang',data).text()
	};


	$("#path").val(preferences.slideshow.path); 
	$("#dummypath").val(decodeURI(preferences.slideshow.path).replace(/^\/dav\//,'/'));
	$("#interval").val(preferences.slideshow.interval);	
	if($("#path").val()==='/Wallpapers/'){loadSystemPath();}
	else{loadPath();}
	$('#position option[value='+preferences.image.position+']').attr('selected','selected');
	if(preferences.image.show==='true') {
		if(preferences.slideshow.show==='true') {
			$("#check").click(); 
		}
	}else{
		$("#nopic").click();		
	}
	if(preferences.bgcolor)$('#bgcolor').val(preferences.bgcolor);
	$('#colorSelector div').css('backgroundColor', preferences.bgcolor);
	$('#colorSelector').ColorPicker({
		color: preferences.bgcolor ? preferences.bgcolor.substring(1):'ff0000',
		onShow: function (colpkr) {
			$(colpkr).fadeIn(500);
			return false;
		},
		onHide: function (colpkr) {
			$(colpkr).fadeOut(500);
			return false;
		},
		onChange: function (hsb, hex, rgb) {
			$('#colorSelector div').css('backgroundColor', '#' + hex);
			$('#bgcolor').val('#' + hex);
		}
	});


}



function loadThemes(){
	$("#themesList").load(window.top.urlpath+"Configurations/System/themes.html",function(){
		$("#themesList li").click(function(){
			$("#themesList li.selecte").removeClass("selected");
			$(this).addClass("selected");
			$("#themeImage")[0].src=$("img",this)[0].src;
			window.selectedTheme=$('label',this).html();
		});
		$("#themesList li:first").click();
	});
}


function loadSystemPath(){
	$("#path").val('/Wallpapers/');
	var html='<ul class="iconlist">';
	for(var i=0;i<6;i++){
		html +='<li webview="'+window.top.urlpath+'Wallpapers/.webview/'+i+'.jpg.jpg" path="/Wallpapers/'+i+'.jpg" class="file image"><a name="'+i+'.jpg"><div class="img"><img src="'+window.top.urlpath+'Wallpapers/.thumbnail/'+i+'.jpg.jpg"></div><div class="text"><span class="name"><label>'+i+'.jpg</label></span></div></a></li>'
	}
	html += '</ul>';
	$("#desktopImagesList").html(html);
	$("#desktopImagesList img").bind('load',function(){
		this.style.marginTop=px((this.parentNode.offsetHeight-this.offsetHeight)/2);
	});
	bindContentEvent(); 
}


function loadPath(path){
	$("#waiting").show();
	if(path){
		$("#path").val('/dav'+path);
		$("#dummypath").val( decodeURI(path));
	}
	else{
		path=$("#path").val();
	}
	var option = {depth: "1",operation: "allprop"};
	var handler = {
		//onSuccess: function(result){	alert('Request SUCCEEDED with status = ' + result.status + ': ' + result.statusstring);	}
		onError: function(result){
			alert($.l10n.__('global_webdav_requestfail').replace('{0}', result.status).replace('{1}', result.statusstring))
		}
		,onComplete: function(result){
			$("#waiting").hide();
			showData(result.content)
		}
	};
	window.top.webdav.PROPFIND(handler, $("#path").val(), option);
}




function showData(data){			
	$("#desktopImagesList").html("<ul class='iconlist'></ul>");
		$("[nodeName='D:response']",data).each(function (){
			var collection=($("[nodeName='D:collection']",this).length>0)?'dir':'file';
			if(collection!="dir"){
				var path= $("[nodeName='D:href']",this).text();
				var lpath=path.toLowerCase();
				var name=path.split('/');
				name=(path[path.length-1]=='/')?name[name.length-2]:name[name.length-1];
				try{name=decodeURI(name);}catch(e){}				
				if(/.jpg$/.test(lpath)||/.jpeg$/.test(lpath)||/.gif$/.test(lpath)||/.png$/.test(lpath)||/.bmp$/.test(lpath)){
					var container=($("#desktopImagesList ul"));	
					var li = document.createElement('li');
					li.thumbnail= path+  '?thumbnail&session='+window.top.SessionID+'&login='+window.top.user;
					//li.webview= path + '?webview&session='+window.top.SessionID+'&login='+window.top.user;
					//li.setAttribute('webview',li.webview);
					li.path=path;	
					li.setAttribute('path',li.path);
					$(li).addClass("file image");
					var a = document.createElement('a');
					a.path=path;	
					var img = document.createElement('img');
					img.src=li.thumbnail;
					img.style.padding="0px";	
					var div = document.createElement('div');
					div.className='text';
					div.innerHTML='<span class="name"><label>'+name+'</label></span>'
					var imgdiv = document.createElement('div');
					imgdiv.className='img';
					$(imgdiv).append(img);
					$(a).append(imgdiv).append(div).appendTo(li);								
					$(li).appendTo(container); 							
					img.onload=function(){
						this.style.marginTop=px((this.parentNode.offsetHeight-this.offsetHeight)/2);
					}
				}
			}
		});
		bindContentEvent();
}


function bindContentEvent(){
	$('#desktopImagesList li').click(function(){
		$('#desktopImagesList li.selected').removeClass('selected');
		$(this).addClass('selected'); 
		window.selectedImage=this.getAttribute('path')+'?session='+window.top.SessionID+'&login='+window.top.user;
	});
	$('#desktopImagesList li:first').click();
}






function apply(){ 
	if($("#Tag1").is(":visible")){ 
		var preferences={
			bgcolor:$('#bgcolor').val()
			,image:{
				show:$('#nopic').is(':checked')?'false':'true'
				,url:window.selectedImage
				,position:$('#position').val()
			}
			,slideshow:{
				show:$('#check').is(':checked')?'true':'false'
				,path:$("#path").val()
				,interval:$("#interval").val()
			}

		}
		window.top.Dean.OS.Desktop.setAppearence(preferences,true);		
	}
	if($("#Tag2").is(":visible")&&window.selectedTheme){
		window.top.Dean.OS.Desktop.setTheme(window.selectedTheme);
	}
	
	if($("#Tag3").is(":visible")){
		window.top.Dean.OS.Desktop.setLang($("#LANG").val());
                var url = window.top.document.URL;
		url = url.split("&id=");
		window.top.document.location.href = window.top.urlpath + 'Applications/System/os.html?lang=' + $("#LANG").val() + '&id=' + url[1];
		setCookie('userlang', $("#LANG").val());
	}
}
