﻿$(function(){
	window.App="System";
	bindEvent();
	loadLang();
})


function cancel(){
	window.parent.curWin.closeWin();
}


function bindEvent(){
	$('#CANCEL').click(cancel);
	$('#YES').click(YES);
	$('#NO').click(NO);
	var o=window.win.fromWinObject;
	if(o.str)$('#info').html(o.str);
}


function YES(){
	var o=window.win.fromWinObject;
	cancel();
	if(o.yes)o.yes();
}


function NO(){
	var o=window.win.fromWinObject;
	cancel();
	if(o.no)o.no();
}