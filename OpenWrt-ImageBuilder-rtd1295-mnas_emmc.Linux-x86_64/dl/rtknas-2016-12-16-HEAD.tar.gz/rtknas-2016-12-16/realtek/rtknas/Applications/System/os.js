﻿$(function(){
	window.App="System";
	window.SessionID=getRequest("id");
	window.hostpath=window.location.protocol+"//"+window.location.host+'/';
	window.urlpath=(window.location.protocol+"//"+window.location.host+window.location.pathname).replace("/Applications/System/os.html","/"); 
	if(!window.SessionID){
		window.location=window.urlpath;
		return;
	}
	window.shortpath=(window.location.protocol+"//"+window.location.host+window.location.pathname).replace("/Applications/System/os.html","");	
	window.relativepath=window.urlpath.replace(window.hostpath,'/'); 
	window.root='/dav/';
	window.remoteDataUrl=getRequest("remoteDataUrl");//系统数据目录
	window.Lang=getRequest("lang").replace('_','-');		
	window.user=getRequest("user");
	window.privilege=getRequest("privilege");
	window.modulus=getRequest("modulus");
	window.public=getRequest("public");
	window.uploadproxy={path:null,force:false};
	window.availablesize=0;
	window.top.webdav = new window.top.Webdav({url:''});
	setLang();
	setValidatorMessages();
	init();
});



function init(){
	Dean.OS.Desktop.init(); 
	$('body').show();
}

function loadNASregister(){
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/register"
		,cache:false
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			if(window.top.checkAPIError(data))return;
				if(window.top.NASinfo){
					window.top.NASinfo.registername = $('register',data).text();
				}else{
					window.NASinfo={
						registername:$('register',data).text()
					};
				}
				window.top.document.title=window.NASinfo.registername;
			}
	});
}

function loadNASinfo(){
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/info"
		,cache:false
		,async:false
		,data:{hash:window.top.SessionID}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			if(window.top.checkAPIError(data))return;
			window.top.NASinfo={
				ip:$('ipaddr:first',data).text()
				,vpnip:$('vpnip',data).text()
				,upnp:$('upnpaddr',data).text()
				,hostname:$('hostname',data).text()
				,mac:$('hwaddr',data).text().replace(/:/g,'')
				,time:$('date',data).text()
				,registername:$('register',data).text()
				,version:$('version',data).text()
				,package:$('package',data).text()
				,storage:{
					available:$('storage available', data).text()
					,used:$('storage used', data).text()
					,blocks:$('storage blocks', data).text()
					,usedpercent:$('storage usedpercent', data).text()
					,writable:$('storage writable', data).text()
				}
			};
			//$.getScript('http://'+$.l10n.__('global_link_registerhost')+':'+$.l10n.__('global_link_registerport')+'/gui/report_upnp_lan_addr?key='+window.top.NASinfo.mac.replace(/:/g,'')+'&upnp_addr='+window.top.NASinfo.upnp+'&lan_addr='+window.top.NASinfo.ip); 
			window.top.document.title=window.top.NASinfo.registername;
			//$.l10n.__('global_title_productname')+':'+ window.top.NASinfo.hostname;
			window.top.Dean.OS.Desktop.setSystemDateTime(window.top.NASinfo.time);	
			if(window.privilege==='0'&&window.top.NASinfo.storage.writable==='no'){
				$('a.HOME0, a.HOME1, a.PUBLIC, a.DOWNLOAD, a.SHARED',$('#App_MyNAS_Win_main #left div.TREE ')).parent().hide();
				$('#App_MyNAS_Win_main #main .MAIN').empty();
				window.System.NoHome();
			}else{
				$('a.HOME0, a.HOME1, a.PUBLIC, a.DOWNLOAD, a.SHARED',$('#App_MyNAS_Win_main #left div.TREE ')).parent().show();
			}
		}
	});
}
