﻿$(function(){	
	window.App="System";
	bindEvent();
	loadLang();
	loadData();
});


function bindEvent(){
	$("#CANCEL").click(function(){		
		window.win.closeWin();
	});	
	$("#BROWSE").click(showDialog);
	$("#REMOVE").click(toRemove);
}

function loadData(){
	var o=window.win.fromWinObject;
	var icon=o.icon; 
	window.ICON=icon;
	var originalicon=icon.icon;
	var customedicon=icon.customedicon;
	var src=icon.original_iconpath;
	var msgid=icon.msgid;
	var name=icon.data.displayname;
	var path=icon.file.replace(/^\/dav\//,'/');
	$('#icon').hide().attr('src',src);
	$('#customedicon').hide().attr('src',icon.customedicon+'?hash='+window.top.SessionID+(/(\.png|\.gif)$/.test(icon.customedicon)?'':'&thumbnail')).show();		
	if(icon.customedicon!==''){
		$('#icon').hide();
		$('#customedicon').show();
		$('#REMOVE').show();
	}else{
		$('#icon').attr('src',src).show();
		$('#customedicon').hide();
		$('#REMOVE').hide();
	}	
	$('#name').html(name);
	$('#path').html(decodeURI(path));
	setLang({el:$('#name')});
}


function showDialog(){
	window.top.System.opendialog({
		path:''
		,filter:'image'
		,single:true
		,handler:toChange
		,app:window.top.System
	});
}


function toRemove(path){
	$('#icon').show();
	$('#customedicon').hide();
	$('#REMOVE').hide();
	window.ICON.customedicon='';
	setDesktop();
}



function toChange(path){
	$('#icon').hide();
	$('#customedicon').attr('src',path+'?hash='+window.top.SessionID+(/(\.png|\.gif)$/.test(path)?'':'&thumbnail')).show();
	$('#REMOVE').show();
	window.ICON.customedicon=decodeURI(path);
	setDesktop();
}


function setDesktop(){
	window.top.Dean.OS.Desktop.resetDesktopIcon(window.ICON);
	window.top.Dean.OS.Desktop.changeDesktopXML(window.ICON);
	window.top.Dean.OS.Desktop.putDesktopXML();
}
