﻿// freespace of which size less than MIN_FREESPACE is ignored
var MIN_FREESPACE = 8*1024*1024;

$(function(){
	window.App="DiskManager";
	layout();
	loadLang();
	loadRaidTab();
	loadData();
	bindEvent();
});

/* AjaxCall
 * ========================================
 * Ajax call for general purpose
 * the functionality depends on url given inside the argument
 */
function AjaxCall(args) {

	if (args.url === undefined) {
		alert("AjaxCall: no url");
		$("#waiting").hide();
		return;
	}
	if (args.data === undefined)			args.data = {};

	if (typeof args.data === "string")		args.data += "&hash=" + window.top.SessionID;
	else if (typeof args.data === "object")	args.data["hash"] = window.top.SessionID;

	$.ajax({
		url: window.top.remoteDataUrl + args.url
		,cache: false
		,data: args.data
		,type: "POST"
		,dataType: "xml"
		,success: (args.success !== undefined)?
			args.success
			:function (returndata) {
				if (window.top.checkAPIError(returndata)) {	$('#waiting').hide();return; }
				parseData(returndata, args.nodepath);
				$("#waiting").hide();
			}
		,error: (args.error !== undefined)?
			args.error
			:function(returndata) {
				alert ( $.l10n.__("global_alert_getdataerror") );
				$("#waiting").hide();
			}
		,async: (args.async === undefined)?true:args.async
	});
}

function layout(){

	$("#DESTROY,#REBUILD,#CREATE").hide();

	window.Layout = $('body').layout({ 
			center__paneSelector:"#main" 
		,	north__paneSelector:"#top" 
		,	north__size:60
		,	north__spacing_open:0
		,	west__paneSelector:	"#left" 
		,	west__size:	260
		,	west__spacing_open:	0
		,	contentSelector:".content"
		//,	center__onresize_end: function(){ }
	}); 
	
	
	$('#toolbar').toolbar();
	window.$PARTITIONS=$("#partitions");
	window.RAIDPATHS=[]; 
	
	window.grid=$("#raidlist table:first")[0];
	$(window.grid).flexigrid({
		singleSelect:true
		,colModel : [
			{display: '<label domain="l10n" msgid="DiskManager_table_operation"></label>', name : 'Delete', width : 50, sortable : false, align: 'left'}
			,{display: '<label domain="l10n" msgid="DiskManager_table_path"></label>', name : 'Path', width : 200, sortable : false, align: 'left'}
			,{display: '<label domain="l10n" msgid="DiskManager_table_size"></label>', name : 'Size', width : 200, sortable : false, align: 'left'}
		]
	});
	$("ul.tabs a:eq(1)").click(function(){	window.grid.grid.Resize();	});

}

function loadRaidTab() {
	var args = {
		url:    "nas/get/issupportraid",
		data: {
			isinternal: "no"
		},
		success:function(returndata) {
			if ($("issupportraid:first", returndata).text() === "yes") {
				$("#raid_tab").show()
			}
			else {
				$("#raid_tab").hide()
			}
		},
	};

	$("#waiting").show();
	AjaxCall(args);
}

function bindEvent(){
	//$("#AUTO").click(autoDisks);
	$("#INFO").click(showInfoWin);
	$("#FORMAT").click(showFormat);
	$("#MOUNT").click(showMount);
	$("#UNMOUNT").click(unmountPartition);
	$("#FORMATPARTITION").click(formatPartition);
	$("#ERASE").click(toErase);
	$("#SMART").click(showSmart);
	//$("#ERASEDEVICE").click(function(){	$("#ERASE").click();	});
	$("#CREATEPARTITION").click(createPartition);
	$("#DELETE").click(deletePartition);
	//$("#DELETEPARTITION").click(deletePartition);
	$("#MOUNTPARTITION").click(mountPartition);
	$("#EXTENDPARTITION1").click(extendPartition);
	$("#EXTENDPARTITION2").click(extendPartition);
	$("#mountasashome").click(function() {
		if ($(this).attr('checked'))
			$("#mountpoint").val('home').attr('disabled','disabled');
		else
			$("#mountpoint").val('').removeAttr('disabled');
	});
	$("#CLEAR").click(clearRaid);
	$("#DESTROY").click(destroyRaid);
	$("#REFRESH").click(loadData);
	$("#OPTION").click(showOption);
	$("#CREATE").click(createRaid);
	$("#DETECT").click(detectRaid);
	$("#REBUILD").click(rebuildRaid);
	$('#raidlist').droppable({
			accept:'#devicelist a'
			,drop: function(event, ui) {
				addPartitionToRaidList(ui.draggable[0], true);
			}
			,hoverClass: 'drophover'
	}); 
	$("#partitionsize").change(function(){
		var v=$(this).val();
		toCalculatePartition();
	});
	$(window).resize(function(){ window.setTimeout(function(){$('div.pointer',window.$PARTITIONS).trigger('resize');},200); });//??
}

function loadData(path){

	var d = $('#devicelist a.selected')[0];
	if (d) 		d = d.data.path;

	var args = {
		url:		"nas/get/devices",
		nodepath:	d
	};

	$("#waiting").show();
	AjaxCall(args);
}


function parseData(data, nodepath){
    // Hide swap warnning messages
	//window.noswap=true;

	window.noswap=false;

	$("#devicelist").html('<ul class="disklist"></ul>');
	window.$TREE=$("#devicelist ul");
	window.$TREE.treeview({collapsed:false});

	var raids=[];
	$('device',data).each(function(){
		if($('>raid',this).length>0){
			raids.push($('>path',this).text());
		};
	});

	$('device',data).each(function(){
		if($('length:first',this).text()!='0'){
			var li=document.createElement("li");
			var a=document.createElement("a");
			a.data={		
				path:$(this).children('path').text()
				,serial:$(this).children('serial').text()
				,model:$(this).children('model').text()
				,connectiontype:$(this).children('connectiontype').text()
				,cylinder:$(this).children('cylinder').text()-0
				,head:$(this).children('head').text()-0
				,sector:$(this).children('sector').text()-0
				,length:$(this).children('length').text()-0
				,sectorsize:$(this).children('sectorsize').text()-0
				,psectorsize:$(this).children('psectorsize').text()-0
				,partitions:$(this).children('partition')
				,raid:$(this).children('raid')
				,external:$(this).children('external').text()
				,start:0
				,raidmember:$(this).children('raidmember').text()
				,type:$(this).children('type').text()
			};
			//??
			if($.inArray(a.data.raidmember,raids)>-1)$(a).addClass('raidlive');

			a.data.size=a.data.length*a.data.sectorsize;
			a.innerHTML=a.data.model; 
			if (a.data.raidmember) {
				var raid_path_arr = a.data.raidmember.split('/');
				a.innerHTML = a.innerHTML.concat(' ['+raid_path_arr[raid_path_arr.length-1]+']');
			}
			a.className="device";
			if(a.data.raidmember!=='')$(a).addClass('raidpart');
			a.setAttribute('path',a.data.path)
			var ul=document.createElement("ul");
			var eul=document.createElement("ul");
			
			var l=a.data.length;
			var ps=a.data.partitions;

			for(var i=0;i<ps.length;i++){
				var p=$(ps[i])
				var pdata={		
					path:$('path',p).text()
					,available:$('available',p).text()
					,used:$('used',p).text()
					,usedpercent:($('usedpercent',p).text()===''?'0%':$('usedpercent',p).text()+'%')
					,label:$('label',p).text()
					,mountpoint:$('mountpoint',p)
					,mountpointtext:''
					,start:$('start',p).text()-0
					,end:$('end',p).text()-0
					,length:$('length',p).text()-0
					,sectorsize:a.data.sectorsize
					,type:$('type',p).text()
					,flags:$('flags',p).text()
					,fs:$('fs',p).text()
					,fssize:$('blocks',p).text()
					,raidmember:$('raidmember',p).text()
					,device:a
				};

				if(pdata.type==='extended'){
					var extended_start=pdata.start;
					var extended_end=pdata.end;
				}
				
				pdata.size=pdata.length*pdata.device.data.sectorsize;
				if(!pdata.fssize) pdata.fssize = pdata.size
				var pli=document.createElement("li");
				var pa=document.createElement("a");
				pa.data=pdata;
				pa.innerHTML= ((pa.data.label=="")?pa.data.path : pa.data.label)+' '+formatBytes(pa.data.size);//+'('+pa.data.usedpercent+')';
				if (pdata.raidmember) {
					var raid_path_arr = pdata.raidmember.split('/');
					pa.innerHTML = pa.innerHTML.concat(' ['+raid_path_arr[raid_path_arr.length-1]+']');
					$(a).addClass('hasraidpart');
				}

				if(pdata.flags.indexOf('msftres') >= 0 ){
					$(pa).addClass('msftres');
				}

				//??
				if($.inArray(pa.data.raidmember,raids)>-1)$(pa).addClass('raidlive');

				//if(data.type==='extended')pa.innerHTML='<label domain="l10n" msgid="DiskManager_text_extended>'+$.l10n.__('DiskManager_text_extended')+'</label>';
				if(pa.data.type==='extended')pa.innerHTML='Extended Partitions';
				pa.setAttribute('path',pa.data.path)
				$(pa).addClass(pa.data.type);
				if(pa.data.mountpoint.length>0){
					$(pa).addClass('mounted');
					$(pa.data.device).addClass('hasmounted');
					$(pa.data.mountpoint).each(function(){
						pa.data.mountpointtext += $(this).text()+",";
						if ($(this).text() === "/home") {
							$(pa).addClass("homemounted");
						}
					});
				}
				if(pa.data.fs==='swap'&&pa.data.mountpointtext!=='')window.noswap=false;
				if(pa.data.fs!='')$(pa).addClass('formatted');
				if(pa.data.raidmember!==''){
					$(pa).addClass('raidpart');
					$(a).addClass('hasraidpartr');
				}
				if(a.data.raid.children().length>0)$(pa).addClass('raidpartition');
				if(pa.data.type==='logic'){
					$(pli).append(pa).appendTo(eul);
				}
				else{
					$(pli).append(pa).appendTo(ul);	
				}
				
				if(pa.data.type==='extended'){
					$(pa).after(eul);
				}
		}

		a.partitions=ul;
		if(a.data.type!==''||a.data.model==='RAID'){
			var raid_level = $('level', a.data.raid).text();
			var raid_path_arr = a.data.path.split('/');
			if (raid_level.length > 0) {
				a.innerHTML = a.innerHTML.concat(' ('+raid_level+') ['+raid_path_arr[raid_path_arr.length-1]+']');
			}
			$(li).append(a).append(ul).appendTo(window.$TREE);
		}
		else{			
			$(a).addClass('fail');
			$(li).append(a).append('<ul><li><a><span class="failed">Unknown Device!</span></a></li></ul>').appendTo(window.$TREE);
		}

		if(a.data.raid.children().length>0){
			$(a).addClass('raiddevice');
			if($('syncpercent',a.data.raid).length>0)$(a).append(' <span>[Rebuilding:'+$('syncpercent',a.data.raid).text()+']</span>')
			if(a.data.partitions.length>0)$(a).addClass('hasraidpartitions');
		}
		window.$TREE.treeview({add:$(li)});
	}
		if(window.noswap)$('#noswap').show();
		else{$('#noswap').hide();}
		//收集自由空间
		if($('a.extended',ul).length>0){
			var ps_start=extended_start;//a.data.length;
			var ps_end=extended_end;
			var $pe=$('a.logic',ul);
			if($pe.length>0){
				for(var i=0,pel=$pe.length;i<pel;i++){
					ps_end=$pe[i].data.start;
					if(ps_end-ps_start>(MIN_FREESPACE/a.data.sectorsize)){
						var fsli=document.createElement("li");
						var fsa=document.createElement("a");
						$(fsa)
							.addClass('freelogic')
							.attr('path','freelogic_'+ps_start)
							.html("Free Space");
						fsa.data={
							path:'freelogic_'+ps_start
							,type:'freelogic'
							,device:a
							,start:ps_start
							,length:ps_end-ps_start+1
							,size:(ps_end-ps_start+1)*a.data.sectorsize
							,sectorsize:a.data.sectorsize
							,available:(ps_end-ps_start+1)*a.data.sectorsize
							,used:''
							,usedpercent:''
							,label:''
							,mountpointtext:''
							,flags:''
							,fs:''
						}
						$(fsli).append(fsa).appendTo(eul);
						$($pe[i].parentNode).before(fsli);
					}
					ps_start=$pe[i].data.end+1;
					if(i===pel-1){
						ps_end=extended_end; 
						if(ps_end-ps_start>(MIN_FREESPACE/a.data.sectorsize)){
							var fsli=document.createElement("li");
							var fsa=document.createElement("a");
							$(fsa)
								.addClass('freelogic')
								.attr('path','freelogic_'+ps_start)
								.html("Free Space");
							fsa.data={
								path:'freelogic_'+ps_start
								,type:'freelogic'
								,device:a
								,start:ps_start
								,length:ps_end-ps_start+1
								,size:(ps_end-ps_start+1)*a.data.sectorsize
								,sectorsize:a.data.sectorsize
								,available:(ps_end-ps_start+1)*a.data.sectorsize
								,used:''
								,usedpercent:''
								,label:''
								,mountpointtext:''
								,flags:''
								,fs:''
							}
							$(fsli).append(fsa).appendTo(eul);
						}
					}
				}
			}
			else{
				var fsli=document.createElement("li");
				var fsa=document.createElement("a");
				$(fsa)
					.addClass('freelogic')
					.attr('path','freelogic_'+ps_start)
					.html("Free logic["+(ps_end-ps_start+1)+']');
				fsa.data={
					path:'freelogic_'+ps_start
					,type:'freelogic'
					,device:a
					,start:ps_start
					,length:ps_end-ps_start+1
					,size:(ps_end-ps_start+1)*a.data.sectorsize
					,sectorsize:a.data.sectorsize
					,available:(ps_end-ps_start+1)*a.data.sectorsize
					,used:''
					,usedpercent:''
					,label:''
					,mountpointtext:''
					,flags:''
					,fs:''
				}
				$(fsli).append(fsa).appendTo(eul);
			}
		}
		
		var ps_start = 0;
		var ps_end = 0;
		var $pe = $('a.primary, a.extended', ul);

		// collect freespace
		for (var i = 0, pel = $pe.length; i < pel+1; i++) {
			if (i == pel)	ps_end = a.data.length;
			else			ps_end = $pe[i].data.start;

			if (pel == 0 || ps_end-ps_start > (MIN_FREESPACE/a.data.sectorsize)) {
				var fsli=document.createElement("li");
				var fsa=document.createElement("a");
				$(fsa)
					.addClass('freespace')
					.attr('path','freespace_'+ps_start+'('+a.data.path+')')
					.html("Free Space");
				fsa.data={
					path:'freespace_'+ps_start+'('+a.data.path+')'
					,type:'freespace'
					,device:a
					,start:ps_start
					,length:ps_end-ps_start
					,size:(ps_end-ps_start)*a.data.sectorsize
					,fssize:(ps_end-ps_start+1)*a.data.sectorsize //freespace no fs, use size instead
					,sectorsize:a.data.sectorsize
					,available:(ps_end-ps_start)*a.data.sectorsize
					,used:''
					,usedpercent:''
					,label:''
					,mountpointtext:''
					,flags:''
					,fs:''
				}
				$(fsli).append(fsa).appendTo(ul);
				if (i != pel)
					$($pe[i].parentNode).before(fsli);
			}
			if (i != pel)
				ps_start=$pe[i].data.end+1;
		}
	});
	
	$(' a.freespace',$('a.device.raidpart',$TREE).next()).parent().remove();//??隐藏raidpart的freespace
	$('a.primary, a.logic',$('a.device.raidpart',$TREE).next()).parent().remove();	//if disk is part of raid then hide all partitions
	$('a.msftres',$TREE).parent().remove();

	$('a',window.$TREE).click(function(){
		$('a.selected',window.$TREE).removeClass('selected');
		$(this).addClass('selected'); 
		enableToolbar();
		showInfo(); 
	});

	$("a.primary, a.logic, a.device, a.freespace",window.$TREE).draggable({
	// 只做磁盘的 RAID
	//$("a.device",window.$TREE).draggable({
		helper: 'clone'
		,appendTo: '#dragging'
		,cursor:'move'
		,revert:true
		//,start:function(){	}
		//,stop:function(){	}
	});
	
	if (nodepath && $('a[path='+nodepath+']',window.$TREE).length > 0) {
		$('a[path='+nodepath+']',window.$TREE).click();
	}
	else {
		$('a.device:first',window.$TREE).click();
	}
}

function enableToolbar(){
	$('#top ul li').removeClass('enabled');
	$('#INFO').addClass('enabled');
	$('#REFRESH,#OPTION').addClass('enabled');
	var $n=$('a.selected',window.$TREE);
	if ($n.hasClass('device')) {	//??$n.hasClass('raidlive')
		if(!($n.hasClass('raidpart') || $n.hasClass('hasraidpart')
			|| $n.hasClass('mounted') || $n.hasClass('hasmounted')))
			$('#ERASE').addClass('enabled');
		if(!$n.hasClass('raiddevice') && $n[0].data.connectiontype=='ata')
			$('#SMART').addClass('enabled'); 
	}
	else if ($n.hasClass('primary') || $n.hasClass('logic')) {
		//?? raidpart 去掉可以删除  $n.hasClass('raidlive')
		if (!($n.hasClass('raidpart') || $n.hasClass('mounted'))) {
			//if(!$n.hasClass('raidpartition'))??
			$('#DELETE').addClass('enabled');
			$('#FORMAT').addClass('enabled');
		}
		if($n.hasClass('mounted'))
			$('#UNMOUNT').addClass('enabled');
		else
			if($n.hasClass('formatted'))$('#MOUNT').addClass('enabled');

	}
	else if($n.hasClass('extended')) {
			$('#DELETE').addClass('enabled');
	}
	else if($n.hasClass('freespace')) {
			//
	}
}


function showInfoWin(){
	var $n=$('a.selected',window.$TREE);
	if($n.hasClass('device'))window.top.DiskManager.showInfo( $('#deviceinfo').html() );
	else window.top.DiskManager.showInfo( $('#partitioninfo').html() );
}


function showInfo(){
	$("tr",window.grid).remove();
	$("#tables table").hide();
	$('#raidinfo').html('');
	$("#DESTROY,#REBUILD").hide();
	$("#CREATE").show();
	$("tr",window.grid).remove();	
	var $n = $('a.selected',window.$TREE);
	var n = $n[0];
	var data = n.data;

	if (!data)	return;
	if ($n.hasClass('device')) {
		$("#Dpath").html(data.path);
		$("#Dserial").html(data.serial);
		$("#Dmodel").html(data.model);
		$("#Dlength").html(formatBytes(data.size) +" ("+ data.size +" bytes)");
		$("#Dconnectiontype").html(data.connectiontype);
		$("#Dcylinder").html(data.cylinder);
		$("#Dhead").html(data.head);
		$("#Dsector").html(data.sector);
		$("#Dsectorsize").html(formatBytes(data.psectorsize));
		$("#Dmodel").html(data.model);
		$("#deviceinfo").show();
		if($n.hasClass('raiddevice')){
			$("#DESTROY,#REBUILD").show();
			$("#CREATE").hide();
			$('#raidinfo').html('<pre><code>'+$('sync',data.raid).text()+'\n'+$('detail',data.raid).text()+'</code></pre>').show();
			$("#raidtypelist option[value="+$('level',data.raid).text().replace('raid','')+"]").attr('selected','selected');
			$('raiddevice',data.raid).each(function(){
					addPartitionToRaidList( $(this).text()  );
				});
		}
		showPartitionMap(n);
	}
	else {
		$("#Ppath").html(data.path);
		$("#Plabel").html(data.label);
		$("#Pmount").html(data.mountpointtext);
		$("#Plength").html(formatBytes(data.fssize) +" ("+ data.fssize +" bytes)");
		$("#Pfs").html(data.fs);
		$("#Ptype").html(data.type);
		$("#Pflags").html(data.flags);
		$("#Ppath").html(data.path);
		$("#Pavailable").html(formatBytes(data.available));
		$("#Pused").html(formatBytes(data.used)+'('+data.usedpercent+')');
		$("#PusedMap div").css({width:data.usedpercent});
		if(window.noswap)$("#partitioninfo").hide();
		else $("#partitioninfo").show();
		showPartitionMap(n.data.device);
		var $pmap=$("div[path="+data.path+"]",window.$PARTITIONS)
		$("div",window.$PARTITIONS).removeClass('selected');
		$pmap.addClass('selected');
		$('div.pointer',window.$PARTITIONS).show().unbind('resize').bind('resize',function(){
				$(this).css({top:$pmap.position().top-3,left:-3,width:$pmap.width(), height:$pmap.height()});
			}).trigger('resize');
		
		if (data.fs === '')	$('#FORMAT').click();
		if (data.fs !== '' && data.mountpointtext === '')	$('#MOUNT').click();
		if (data.type === 'freespace' || data.type==='freelogic') {
			$("#partitionsize")[0].data = {
				length:data.length
				,sectorsize:data.sectorsize
				,devicelength:data.device.data.length
			};
			$("#partitionsize").val(formatBytesNumber(data.length*data.device.data.sectorsize, 2));
			$("#partitionbytes").html(formatBytes(data.length*data.device.data.sectorsize));
			$("#partitiontypelist").empty();
			$("#table_partition").show();
		}

		if (data.device.data.type !== 'msdos') {
			$("#partitiontypelist").parent().parent().hide();
		}
		else if (data.type === 'freespace') {
			$("#partitiontypelist").parent().parent().show();
			var primary = $('a.primary', data.device.parentNode).length;
			var extend = $('a.extended', data.device.parentNode).length;

			// There are 4 primary partitions at most
			if (primary < 4) {
				$("#partitiontypelist").append('<option value="primary" domain="l10n" msgid="DiskManager_text_primary">'+
					$.l10n.__('DiskManager_text_primary')+'</option>');
			}
			// There are 1 extend partition at most
			if (extend === 0) {
				$("#partitiontypelist").append('<option value="extended" domain="l10n" msgid="DiskManager_text_extended">'+
					$.l10n.__('DiskManager_text_extended')+'</option>');
			}

			if ((primary + extend) === 4) {
				$("#partitiontypelist").empty();
				$("#table_partition").hide();
			}
		}
		else if (data.type === 'freelogic') {
			$("#partitiontypelist").append('<option value="logic" domain="l10n" msgid="DiskManager_text_logic" selected="selected">'+
				$.l10n.__('DiskManager_text_logic')+'</option>');
		}
		// Hide the list so users choose the first type(primary) unconsciously
		// hence, there's no freelogic partition being created
		$("#partitiontypelist").parent().parent().hide();
	}
}

function showFormat(){
	if(!$("#FORMAT").hasClass('enabled'))return;
	//$('#INFO').addClass('enabled');
	$("#tables table").hide();
	if(!window.noswap)$("#partitioninfo").show();
	$("#table_format").show();
	var $n=$('div.selected',window.$PARTITIONS);
	var n=$n[0];
	if(n){
		$("#vloumelabel").val(n.data.label);
		$("#fslist option[valeu="+n.data.fs+"]").attr('selected','selected');
	}
}

function showMount(){
	if(!$("#MOUNT").hasClass('enabled'))return;
	//$('#INFO').addClass('enabled');
	$("#tables table").hide();
	if(!window.noswap)$("#partitioninfo").show();
	$("#table_mount").show();
	var a=$('a.selected',window.$TREE)[0];
	if (a.data.fs==='swap' || a.data.device.data.external==="yes"){
		$("#mountpoint").val('').attr('disabled','disabled');
		$("#mountasashome").removeAttr('checked').attr('disabled','disabled');
	}
    else if(a.data.device.data.connectiontype=='memstick'){
		$("#mountpoint").val('').removeAttr('disabled');
		$("#mountasashome").removeAttr('checked').attr('disabled','disabled');
    }
	else if ($(".homemounted", window.$TREE).length == 0) {
		$("#mountpoint").val('home').attr('disabled', 'disabled');
		$("#mountasashome").attr('checked', true).attr('disabled', 'disabled');
	}
	else{
		$("#mountpoint").val('').removeAttr('disabled');
		$("#mountasashome").removeAttr('disabled').removeAttr('checked');
	}
}

function showPartitionMap(device){
	var $PS=window.$PARTITIONS;
	$PS.html('');
	var ps=$('ul li a',device.parentNode);//device.data.partitions; 


	for(var i=0;i<ps.length;i++){
		var data=$(ps[i])[0].data;
		if(!data)continue;
		var div=document.createElement('div');
		div.data=data;
		$(div)
			.addClass(data.type)
			.append('<div class="used" style="height:'+data.usedpercent+';"></div><table style="height:100%;" cellpadding="0" cellspacing="0"><tr><td align="center" valign="center"></td></tr></table>')
			.attr('path',data.path)
			.css({
				position:"absolute"
				,top:((data.start-1)/data.device.data.length*100).toFixed(4) +"%"
				,height:(data.length/data.device.data.length*100).toFixed(4) +"%"
			})
			.appendTo($PS);
	}
	$('div',$PS).each(function(){
		if($(this).hasClass('primary')||$(this).hasClass('logic')){
			$('td',this).html(this.data.path + ( (this.data.fs=="")?"":" ("+this.data.fs+")" ));
		}
		if($(this).hasClass('freespace')||$(this).hasClass('freelogic')){
			$('td',this).html('Free Space');
		}
		$(this).click(function(){
			$("a[path="+this.data.path+"]",window.$TREE).click();
		});
	});
	$PS.append('<div class="pointer"></div>');
}

function toErase(){

	if (!$("#ERASE").hasClass('enabled') ||
		!confirm($.l10n.__('DiskManager_alert_erase')) ||
		!confirm($.l10n.__('DiskManager_alert_data_lost')))
		return;

	var p = $("a.selected",window.$TREE)[0];
	var args = {
		url:		"nas/delete/partitions",
		data: {
			path:	p.data.path
		},
		nodepath:	p.data.path
	};

	$("#waiting").show();
	AjaxCall(args);
}

function createPartition(){

	var p = $("a.selected",window.$TREE)[0];
	toCalculatePartition();
	var $pt = $("#partitionsize");
	var pt = $pt[0];
	var length = parseInt($pt.val()*1024*1024/p.data.sectorsize);
	if (length > pt.data.length)	length=pt.data.length;

	var args = {
		url:		"nas/add/partition",
		data: {
			path:	p.data.device.data.path,
			start:	p.data.start,
			length:	length
		},
		nodepath:	p.data.device.data.path
	};

	$("#waiting").show();
	AjaxCall(args);
}

function deletePartition(){

	if (!$('#DELETE').hasClass('enabled'))	return;
	var p = $("a.selected",window.$TREE)[0];

	if (!confirm($.l10n.__('DiskManager_alert_deletepartition')) ||
		!confirm($.l10n.__('DiskManager_alert_data_lost')))
		return;

	var args = {
		url:		"nas/delete/partition",
		data: {
			path:	p.data.path
		},
		nodepath:   p.data.device.data.path
	};

	$("#waiting").show();
	AjaxCall(args);
}

function formatPartition(){

	if (!toValidateFormat())	return;

	if (confirm($.l10n.__('DiskManager_alert_toformat')) &&
		confirm($.l10n.__('DiskManager_alert_data_lost'))) {

		var p = $("div.selected",window.$PARTITIONS)[0];
		var path = (p.data.path.indexOf('freespace') === 0)? p.data.device.data.path:p.data.path;

		var args = {
			url:		"nas/format/partition",
			data: {
				path:	path,
				fs:		$("#fslist").val(),
				label:	$("#volumelabel").val()
			},
			success:function(returndata) {
				if (window.top.checkAPIError(returndata)) {	$('#waiting').hide();return; }
				window.top.DiskManager.showFormat({path:path,win:window});
				$("#waiting").hide();
				//alert($('mkfs',data).text());
			},
			error:function(returndata) {
				alert ( $.l10n.__("DiskManager_text_restartwarning") );
				$("#waiting").hide();
			}	
		};

		$("#waiting").show();
		AjaxCall(args);
	}
}

function extendPartition(){

	var p = $("a.selected",window.$TREE)[0];
	var f = $("ul:has(a.selected)",window.$TREE)[0].childNodes;

	var found = false;
	var length = 0;

	for (var i = 0; i < f.length; i++) {
		if (p.isEqualNode(f[i].childNodes[0])) {
			if (i < f.length-1 && $(f[i+1].childNodes[0]).hasClass('freespace') ) {
				// found the freespace partition next to the selected partition
				found = true;
				length = f[i+1].childNodes[0].data.length;
			}
			break;
		}
	}
	if (!found)	return;

	length = length + p.data.length;	// length: number of sectors in this partition

	var args = {
		url:		"nas/extend/partition",
		data: {
			path:	p.data.path,
			start:	p.data.start,
			length:	length,
			fs:		p.data.fs,
			type:	p.data.type
		},
		// if there is filesystem inside partition, then display a new window to show its progress
		success:function(returndata) {
			if (window.top.checkAPIError(returndata)) {	$('#waiting').hide();return; }
			if (p.data.fs != '')	window.top.DiskManager.showProgress({path:p.data.path,title:'Extend Partition',win:window});
			parseData(returndata, p.data.path);
			$("#waiting").hide();
		}
	};

	$("#waiting").show();
	AjaxCall(args);
}

function mountPartition(){

	if (!toValidateMount())	return;

	var p = $("a.selected",window.$TREE)[0];
	var args = {
		url:	"nas/mount/partition",
		data: {
			path:		p.data.path,
			mountpoint:	$("#mountpoint").val(),
			static:		(p.data.device.data.connectiontype=='ata' || $("#mountpoint").val()=='home' ||
						$(p.data.device).hasClass('raiddevice')|| p.data.fs=='swap')? 'yes':'no',
		},
		success:function(returndata) {
			if (window.top.checkAPIError(returndata)) {	$('#waiting').hide();return; }
			if ($("#mountpoint").val() == 'home')	window.top.loadNASinfo();
			$("#waiting").hide();
			loadData();

			// FIX: reload MyNAS window if it is displayed
			if (window.top.MyNAS) {	// check if MyNAS has been called (opened), otherwise it is undefined
				if (window.top.MyNAS.mainWin.WIN.style.display=='block')	// MyNAS window is displayed
					window.top.loadApp('MyNAS');
				// else style.display is "none" when MyNAS is closed
			}
		}
	};

	$("#waiting").show();
	AjaxCall(args);
}

function unmountPartition(){

	if (!$("#UNMOUNT").hasClass('enabled'))	return;

	var p = $("a.selected",window.$TREE)[0];

	p.data.mountpoint.each(function(index){
		var mountpoint = $(this).text();
		var prefix = mountpoint.substring(0,5);
		// ignore /var/log, /var/lib/collectd/rrd, /var/lib/openmediavault/rrd
		if (prefix != '/var/') {
			var args = {
				url:			"nas/umount/partition",
				data: {
					path:		p.data.path,
					mountpoint:	mountpoint,
					static:		'yes'
				},
				success:function(returndata) {
					var long_prefix = mountpoint.substring(0,12);
					if (window.top.checkAPIError(returndata)) {	$('#waiting').hide();return; }
			    	// old: if(prefix != '/expo' && long_prefix != '/home/ftpdir'){
				    // The last one
			    	if (0 == index) {
						$("#waiting").hide();
						loadData();
						window.top.loadNASinfo();

						// FIX: reload MyNAS window if it is displayed
						if (window.top.MyNAS) {
							if (window.top.MyNAS.mainWin.WIN.style.display=='block')
								window.top.loadApp('MyNAS');
							// else style.display is "none" when MyNAS is closed
						}
					} // if (0 == index)
				}
			};

			$("#waiting").show();
			AjaxCall(args);
		}
	});
}


function clearRaid(){
	$('tr',window.grid).remove();	
}

function Raid_AddRaidListCheck(raid_device, p) {

	var size;
	var $trs = $('tr',window.grid)
	var exact = false;
	var needRepart = false;
	var needDelete = false;
	var level = $("level", raid_device[0].data.raid).text();
	var path = p.data.path;

	if (level != "linear") {
		//var member = $("raiddevice", $a[0].data.raid);
		size = parseInt($trs[0].getData().Size);
		if (p.data.size < size) {
			alert("size("+p.data.size+") is not big enough("+size+")");
			return false;
		}
		exact = true;
	}
	else {
		size = p.data.size;
	}

	if (path.indexOf('freespace') == 0) {
		var match = /\((.+)\)/.exec(path);
		path = match[1];
		needRepart = true;
	}
	// if it's a disk or a partition which of size larger than "size"
	else if (!p.data.device || p.data.size >= size + MIN_FREESPACE) {
		needRepart = true;
		needDelete = true;
	}

	if (path == raid_device[0].data.path) {
		alert("Cannot use it's own partition as member");
		return false;
	}
	else if (!needRepart)
		return true;
	else if (!confirm("Re-partition with "+(size/(1024*1024*1024)).toFixed(2)+" GB?"))
		return false;

	var args = {
		url:		"nas/add/partition",
		data: {
			path:		path,
			start:		p.data.start,
			length:		size/p.data.sectorsize,
			exactsize:	exact?	"true":"false"
		},
		nodepath:	raid_device[0].data.path
	};

	if (needDelete) {
		var args2 = $.extend(true, {}, args);
		if (!p.data.device)
			args.url = "nas/delete/partitions";
		else {
			args.url = "nas/delete/partition";
			args2.data.path = p.data.device.data.path;
		}

		args.data = {
			path:	path
		};
		args.success = function(returndata) {
			if (window.top.checkAPIError(returndata)) {	$('#waiting').hide();return; }
			AjaxCall(args2);
		};
	}

	$("#waiting").show();
	AjaxCall(args);

	return false;
}

function addPartitionToRaidList(p, drag){

	if (typeof(p) === 'object') {
		var $p = $(p);
		//TODO raiddevice cannot be raid member?
		if ($p.hasClass('raidlive') || $p.hasClass('raidpart') || $p.hasClass('hasraidpartr') ||
			$p.hasClass('raiddevice') || $p.hasClass('mounted') || $p.hasClass('hasmounted')) {
			alert($.l10n.__('DiskManager_alert_raid_israided'));
			return;
		}

		if ($('tr#'+p.data.path.replace(/\//g,''), window.grid).length>0 ) {
			alert($.l10n.__('DiskManager_alert_raid_partitionexist'));
			return;
		}

		if (p.data.device && $('tr#'+p.data.device.data.path.replace(/\//g,''), window.grid).length > 0) {
			return;
		}

		var $trs = $('tr',window.grid)
		var path = p.data.path;
		for (var i = 0, l = $trs.length; i < l; i++) {
			if ($trs[i].getData().Path.indexOf(path) === 0) {
				return;
			}
		}

		// if you are dropping into table of an existed raid device
		if (!!drag) {
			var $a = $("a.selected",window.$TREE);
			if ($a.hasClass('raiddevice')) {
				if (!Raid_AddRaidListCheck($a, p))
					return;
			}
		}
	}
	else {
		var $p = $("a[path="+p+"]", window.$TREE);
		if ($p.length>0)	p = $p[0];
	}
	
	if (typeof(p) === 'object') {
		window.grid.grid.addRow({
			id:			p.data.path.replace(/\//g,'')
			,Delete:	"<a class='icon s12 remove' path='"+p.data.path+"'></a>"
			,Path:		p.data.path
			,Size:		p.data.size+'('+formatBytes(p.data.size)+')'
		});
	}
	else {
		window.grid.grid.addRow({
			id:			p.replace(/\//g,'')
			,Delete:	"<a class='icon s12 remove' path='"+p+"'></a>"
			,Path:		p
			,Size:		''
		});
	}

	$("tr:last a.icon", window.grid).click(function(){
		var $d = $('a.selected', window.$TREE);
		if (!$d.hasClass('raiddevice')) {
			$(this.parentNode.parentNode.parentNode).remove();
 			return;
		}
		var d = $d[0]; 
		var l = $('level',d.data.raid).text();
		var ds = $('raiddevice',d.data.raid);
		var rd = [];

		for (var i=0, ii=ds.length; i<ii; i++) {
			rd.push($(ds[i]).text());
		}

		if ($.inArray($(this).attr('path'), rd) < 0) {
			$(this.parentNode.parentNode.parentNode).remove();
			return;
		}

		//raid4 5 6 10 ------
		if (l === 'raid1'||l === 'raid5') {
			if (confirm( $.l10n.__('DiskManager_alert_removeraidmember') ) ) {
				var args = {
					url:		"nas/remove/raid",
					data: {
						device:	d.data.path,
						path:	$(this).attr('path').split(' ')[0]
					},
				};
				$('#waiting').show();
				AjaxCall(args);
			}
		}
	});
}

/* Raid_CheckCandidate
 * ========================================
 * Check the Raid member candidates in the table
 * whether they need to do partition before createing Raid
 * If so, do partition immediately
 * Argument:
 *     onlyCheck: set to true to ignore repartition
 * Return Value:
 *     true if all candidates are ready else false
 */
function Raid_CheckCandidate(onlyCheck) {

	var $table = $("tr", window.grid);
	var level = $("#raidtypelist").val();
	var migration = false;

	if ($table.length == 0)
		return false;

	// check the number of candidates is enough for given raid level
	switch (level) {
		case 'linear':
		case '0':
		case '1':
			if ($table.length == 1) {
				if (confirm("Create Raid "+level+" in degraded mode to keep the old data?")) {
					var path = $table[0].getData().Path;
					var $a = $("a[path="+path+"]", window.$TREE);

					// allow to create raid 1 in degraded mode with one partition
					if ($a[0].data.device && level != '1') {
						alert("Cannot use partition if you want to keep your data, use entire disk instead");
						return false;
					}
					migration = true;
				}
				else {
					alert($.l10n.__('DiskManager_alert_leastnum').replace('{0}',2));
					return false;
				}
			}
			break;
		case '5':
			if ($table.length < 3) {
				alert($.l10n.__('DiskManager_alert_leastnum').replace('{0}',3));
				return false;
			}
			break;
		default:
			alert("Unknown Raid level: "+level);
	}

	var member_arr = [];
	var needRepart = false;
	var	minsize = parseInt($table[0].getData().Size);

	// find out whether we need to do extra partitioning
	// if so, set needRepart to True
	for (var i = 0; i < $table.length; i++) {
		var path = $table[i].getData().Path;
		var $a = $("a[path="+path+"]", window.$TREE);
		var start = $a[0].data.start;
		var length = parseInt($table[i].getData().Size);

		if (path.indexOf('freespace') == 0) {
			var match = /\((.+)\)/.exec(path);
			path = match[1]+"(F)";
			needRepart = true;
		}

		if (length < minsize)
			minsize = length;

		// if we want to automatically create partition while dealing with disk, uncomment lines below
		if (!$a[0].data.device && !migration) {
			path = path+"(W)";
			length = 0;
			needRepart = true;
		}

		member_arr.push(path+":"+start+":"+length);
	}

	// raid linear doesn't require same-size members
	if (level == "linear") {
		if (!needRepart)
			return true;
		else
			minsize = 0;
	}

	// find out if there any existed partition needed to be repartitioned
	for (var i = 0; i < $table.length; i++) {
        var info = member_arr[i].split(":");
        var $a = $("a[path="+info[0]+"]", window.$TREE);
		if ($a.length != 0 && $a[0].data.device && info[2] >= minsize + MIN_FREESPACE) {
			needRepart = true;
		}
	}

	if (!needRepart)
		return true;
	else if (onlyCheck) {
		alert("Check raid candidates failed");
		return false;
	}
	else if (minsize != 0 && !confirm("Re-partition with "+(minsize/(1024*1024*1024)).toFixed(2)+" GB?"))
		return false;

	var args = {
		url:			"nas/add/multipartitions",
		data: {
			member:		member_arr.join("&"),
			samesize:	(minsize==0)? false:true,
		},
		// overwrite success function to reload page and put the returned data into table
		success:function(raiddata) {
			var args = {
				url:	"nas/get/devices",
				success:function(returndata){
					if (window.top.checkAPIError(returndata)) {	$('#waiting').hide();return; }
					parseData(returndata);
					$('addpartitions', raiddata).each(function(){
						if ($('>path', this).length > 0) {
							addPartitionToRaidList($('>path', this).text())
						}
					});
					$('#waiting').hide();
					// redirection to createRaid has not been tested yet
					//createRaid();
				}
			};
			AjaxCall(args);
		}
	};

	$('#waiting').show();
	AjaxCall(args);

	return false;
}


function createRaid() {

	if (!Raid_CheckCandidate())
		return;

	if(confirm($.l10n.__('DiskManager_alert_raid_tocreate'))) {
		var disks = "";
		var number_of_disk = $("tr",window.grid).length;
		var level = $("#raidtypelist").val();
		var migration = ((level=="linear"||level=="0"||level=="1") && number_of_disk==1)?"yes":"no";

		if (migration=="yes" || confirm($.l10n.__('DiskManager_alert_data_lost'))) {
			$("tr",window.grid).each(function(){
				disks +="&disks="+this.getData().Path
			});

			var args = {
				url:	"nas/create/raid",
				data:	'level='+level
						+'&force=yes'
						+'&migration='+migration
						+disks,
				success: function(returndata) {
					if (window.top.checkAPIError(returndata)) {	$('#waiting').hide();return; }
					var mdpath = $('path', returndata).text();
					$("#waiting").hide();
					loadData(mdpath);
				}
			};

			$("#waiting").show();
			AjaxCall(args);
		}
	}
}

function destroyRaid(){

	if (confirm($.l10n.__('DiskManager_alert_raid_todestroy')) &&
		confirm($.l10n.__('DiskManager_alert_data_lost'))) {

		var p = $("a.selected",window.$TREE)[0];
		var args = {
			url:		"nas/destroy/raid",
			data: {
				device:	p.data.path
			},
		};

		$("#waiting").show();
		AjaxCall(args);
	}
}

function rebuildRaid(){

	var legal_level_change = ["0->5", "1->linear", "1->0", "1->5", "5->0"];

	var d = $('a.selected',window.$TREE)[0];
	var ds = $('raiddevice',d.data.raid);
	var rd = [];

	// TODO maybe we need to give a hint that the size of new comer shouldn't less than the original's

	if (!Raid_CheckCandidate(true))
		return;

	for (var i=0, ii=ds.length; i<ii; i++){
		rd.push($(ds[i]).text());
	}
    var new_devices = "";
	$("tr",window.grid).each(function(){
		var path = this.getData().Path;
		var path0 = path.split(' ')[0];
		if ($.inArray(path,rd)<0 && $.inArray(path0,rd)<0){
            if (new_devices == "")	new_devices = path0
			else					new_devices = new_devices+"&"+path0;
		}
	});
	var level = $('level',d.data.raid).text().replace('raid','');
	var new_level = $("#raidtypelist").val();

	if (level != new_level) {
		var level_change = level+'->'+new_level;
		if ($.inArray(level_change, legal_level_change) < 0) {
			alert('Rebuild from Raid '+level+' to Raid '+new_level+' is not permitted')
			return;
		}
	}
	else if (new_devices == "") {
		return;
	}

	var args = {
		url:		"nas/add/raid",
		data: {
			device:	d.data.path,
			path:	new_devices,
			level:	new_level
		},
		nodepath:	d.data.path,
	};

	$("#waiting").show();
	AjaxCall(args);
}


function detectRaid(){
	var args = {
		url:	"nas/active/raid",
		success:function(returndata) {
			$("#waiting").hide();
			//if(window.top.checkAPIError(data))return;
			if ($('nas error', returndata).length>0) {
				alert('No RAID found!');
			}
			loadData();
		},
	};

	$("#waiting").show();
	AjaxCall(args);
}


function showSmart(){
	if(!$("#SMART").hasClass('enabled'))return;
	var p=$("a.selected",window.$TREE)[0];
	window.top.DiskManager.showSmart(p.data.path);
}

function toValidateMount(){
	var $n=$("a.mounted",window.$TREE);
	for(var i=0;i<$n.length;i++){
		var ary=$n[i].data.mountpointtext.split(','); 
		if( $.inArray('/media/'+$('#mountpoint').val(),ary)>-1&&$('#mountpoint').val()!==''){
			alert($.l10n.__('DiskManager_alert_mountpointinuse').replace('{0}', $('#mountpoint').val()));
			return false;
		}
	};
	var a=$('a.selected',window.$TREE)[0]; 
	if (a.data.fs==='swap')
		return true;
	else if (a.data.device.data.external==='yes') {
		if ($(".homemounted", window.$TREE).length == 0) {
			alert($.l10n.__("DiskManager_text_nohome"));
			return false;
		}
		else
			return true;
	}
	else{
		var fields = [
		{
			method : 'regex',
			value : $('#mountpoint').val(), 
			element : $('#mountpoint')[0],
			param : '^[a-zA-Z0-9_]{1,16}$', 
			errParam : $.l10n.__('DiskManager_text_mountpoint')
		}
		];
		fields .push({
			method : 'required',
			value : $('#mountpoint').val(), 
			element : $('#mountpoint')[0],
			param : null, 
			errParam : $.l10n.__('DiskManager_text_mountpoint')
		});
		return validateFields(fields);
	}
}

function toValidateFormat(){
	//if(window.noswap&&$('#fslist').val()!=='swap'){
		//if( ! confirm($.l10n.__('DiskManager_text_noswap')) )return;
	//}
	var fields = [
		{
			method : 'regex',
			value : $('#volumelabel').val(), 
			element : $('#mountpoint')[0],
			param : '^[a-zA-Z0-9_]{0,16}$', 
			errParam : $.l10n.__('DiskManager_text_label')
		}
	];
	return validateFields(fields);	
}


function toCalculatePartition(){
	var $this=$("#partitionsize");
	var t=$this[0];
	var v=$this.val();
	
	if(/^\d+(\.\d+){0,1}\%/.test(v)){
		v=v.replace('%','')-0;
		if(v>100)v=100;
		v=v/100*t.data.length*t.data.sectorsize;
		$this.val( formatBytesNumber(v,2) );
	}else{
		if(isNaN(v))$("#partitionsize").val( formatBytesNumber(t.data.length*t.data.sectorsize,2) );
		else if(v*1024*1024-0>t.data.length*t.data.sectorsize) $("#partitionsize").val( formatBytesNumber(t.data.length*t.data.sectorsize,2) );
	}

	$('#partitions div.selected').css({height:   ( $this.val()*1024*1024/t.data.sectorsize/t.data.devicelength  *100)+'%'      });
	$('#partitions div.selected')[0].data.curlength= parseInt( $this.val()*1024*1024/t.data.sectorsize);
}


function showOption(){
	window.top.DiskManager.showOption();
}

function sortNumber(a,b){
	return a - b
}
