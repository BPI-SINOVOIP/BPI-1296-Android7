﻿$(function(){
	
	window.App="DiskManager";
	loadLang();
	loadData();
	bindEvent();
	$('#CLOSE').hide();
	$('#REFRESH').hide();
	window.win.close.onclick = function(){};
});

function bindEvent(){
	$('#REFRESH').click(function(){loadData();});
	$('#DETAIL').click(function(){
		if($('#result').is(':hidden')){
			$('#result').show();
			window.win.resize(null,$('#content').height()+$('#result').height()+100);
		}
		else{
			$('#result').hide();
			window.win.resize(null,$('#content').height()+50);
		}
	});
	window.start=new Date();
	window.loadtimer=window.setInterval(loadData,5000);
	window.timer=0;
	window.caltimer=window.setInterval(function(){
		window.timer++;
		if(window.v){
			var percent=parseInt((window.v*(new Date()-window.start)+window.completed)/window.size*100);
			if(isNaN(percent))percent=0;
			if(percent>99)percent=99;
			percent=percent+'%'
			$('#percent').html(percent);
			$('#completed').css({width:percent});
		}
	},1000);
}


function loadData(){	
	var device=window.win.fromWinObject;
	$('#waiting').show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/status/partition"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,path:device
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			//if(window.top.checkAPIError(data))return;
			parseData(data);			
		}
		,complete:function(){
			$('#waiting').hide();
		}
	});
}


function parseData(data){
	var retcode=$('retcode',data).text();
	var detail=$('detail',data).text();
	var processing='';
	var percent;
	if(retcode===''){
		processing= $.l10n.__('DiskManager_format_processing');
		if($('fs',data).text().indexOf('ext')===0){
			var number=detail.split('Writing inode tables:');
			number=number[1].split(/\n/);
			number=number[0].replace(/\s/g,'');
			if(number!==''){
				if(number==='done'){
					processing=$.l10n.__('DiskManager_format_almostdone');
					percent='99%';
				}
				else{
					number=number.split('/');
					if(!window.completed)window.completed=number[0]-0; 
					window.v=(number[0]-window.completed)/(new Date()-window.start);
					window.completed=number[0]-0;
					window.size=number[1]-0;
					window.start=new Date();
					window.timer=0;
					percent=parseInt(number[0]/number[1]*100);
					if(isNaN(percent))percent=0;
					if(percent>99)percent=99;
					percent=percent+'%';
				}
			}
		}
	}
	else{ 
		window.clearInterval(window.loadtimer);
		window.clearInterval(window.caltimer)
		if(retcode==='0'){
			if ($('#percent').text() === '100%') {
				return;
			}
			processing=$.l10n.__('DiskManager_format_done');
			percent='100%';
		}
		else{
			processing=$.l10n.__('DiskManager_format_fail');
			window.win.fromWin.$('#REFRESH').click();
		}

	    //$('#REFRESH').hide();
	    $('#CLOSE').click(function(){	window.win.closeWin();	});
	    $('#CLOSE').show();
		window.win.close.onclick = function(){window.win.close.obj.closeWin();};
	}
	$('#processing').html(processing);
	if(percent){
		$('#percent').html(percent);
		$('#completed').css({width:percent});
		if (percent === '100%') {
			window.win.fromWin.$('#REFRESH').click();
			window.top.loadNASinfo();
			alert($.l10n.__("DiskManager_alert_complete"));
		}
	}
	$('#result').html('<pre><code>'+detail+'</code></pre>');
}
