﻿$(function(){
	window.App="DiskManager";
	loadLang();
	bindEvent();

});




function bindEvent(){
	$("#OK").click(function(){
		var m=$('input:checked').attr('id');
		switch(m){
			case 'auto': window.top.DiskManager.auto();break;
//			case 'custom': window.top.DiskManager.custom();break;
			case 'advanced': window.top.DiskManager.advanced();break;
		}
		window.win.closeWin();
	});
}
