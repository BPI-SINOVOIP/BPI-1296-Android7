﻿$(function(){
	
	window.App="System";
	loadLang();	
	layout();
	bindEvent();
	loadData();
});

function layout(){
	$('body').layout({ 
			center__paneSelector:"#main"
		,	south__paneSelector:"#bottom" 
		,	south__size:60
		,	south__spacing_open:0
		,	contentSelector:".data"
		//,	center__onresize_end: function(){ $(window).resize();}
	}); 

}

function bindEvent(){
	$("#EJECT").click(function(){	toEject();	});
	$("#REFRESH").click(function(){	loadData();	});	
	$("#CANCEL").click(function(){		
		window.win.closeWin();
	});
}



function loadData(){
	var d=$('#devicelist a.selected')[0];
	if(d)d={device:($(d).hasClass('device')?'first':'last'), path:d.data.path};
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/devices"
		,cache:false
		,data:{
			hash:window.top.SessionID
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
			if(d)$("#devicelist a[path="+d.path+"]:"+d.device).click();
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000		
	});
}


function parseData(data){ 
	$("#devicelist").html('<ul class="disklist"></ul>');
	window.$TREE=$("#devicelist ul");
	window.$TREE.treeview({collapsed:false}); 
	$('device',data).each(function(){
		if($('length:first',this).text()!='0'
		    &&($('connectiontype',this).text()==='usb' || 
		       $('connectiontype',this).text()==='memstick')
		    &&$('mountpoint',this).length>0){
			var li=document.createElement("li");
			var a=document.createElement("a");
			a.data={		
				path:$(this).children('path').text()
				,serial:$(this).children('serial').text()
				,model:$(this).children('model').text()
				,connectiontype:$(this).children('connectiontype').text()
				,cylinder:parseInt($(this).children('cylinder').text())
				,head:parseInt($(this).children('head').text())
				,sector:parseInt($(this).children('sector').text())
				,length:parseInt($(this).children('length').text())
				,sectorsize:parseInt($(this).children('sectorsize').text())
				,partitions:$(this).children('partition')
				,raid:$(this).children('raid')
				,start:0
				,raidmember:$(this).children('raidmember').text()
				,type:$(this).children('type').text()
			};
			a.data.size=a.data.length*a.data.sectorsize;
			a.innerHTML=a.data.model;
			a.className="device";
			if(a.data.raidmember!=='')$(a).addClass('raidpart');
			a.setAttribute('path',a.data.path)
			var ul=document.createElement("ul");
			
			var l=a.data.length;
			var ps=a.data.partitions;
			
			for(var i=0;i<ps.length;i++){
				var p=$(ps[i])
				var data={		
					path:$('path',p).text()
					,available:$('available',p).text()
					,used:$('used',p).text()
					,usedpercent:$('usedpercent',p).text()
					,label:$('label',p).text()
					,mountpoint:$('mountpoint',p)
					,mountpointtext:''
					,start:parseInt($('start',p).text())
					,end:parseInt($('end',p).text())
					,length:parseInt($('length',p).text())
					,type:$('type',p).text()
					,flags:$('flags',p).text()
					,fs:$('fs',p).text()
					,raidmember:$('raidmember',p).text()
					,device:a
				};
				
				data.size=data.length*data.device.data.sectorsize;
				var pli=document.createElement("li");
				var pa=document.createElement("a");
				pa.data=data;
				
				pa.setAttribute('path',data.path)
				$(pa).addClass(data.type);
				if(data.mountpoint.length>0){
					$(pa).addClass('mounted');
					$(pa.data.device).addClass('hasmounted');
					$(data.mountpoint).each(function(){
						data.mountpointtext += '&mountpoint='+$(this).text()
					});
					$(pli).append(pa).appendTo(ul);
				}
				pa.innerHTML= ((pa.data.label=="")?pa.data.path : pa.data.label) +' ['+data.mountpointtext.replace(/&mountpoint=/g,'')+']';
			}
			a.partitions=ul;
			$(li).append(a).append(ul).appendTo(window.$TREE);
			window.$TREE.treeview({add:$(li)});
		}
		
	});
	

	$('a',window.$TREE).click(function(){
		$('a.selected',window.$TREE).removeClass('selected');
		$(this).addClass('selected'); 
	});	
	($('a:first',window.$TREE)).click();
	window.top.loadNASinfo();
}

			
function toEject(){
	var $d=($('a.selected',window.$TREE));
	if($d.length===0)return;
	var d=$d[0];
	if($d.hasClass('device')){
		var $p=$('ul li a',$d.parent());
		var m='';
		$p.each(function(){
			m += '&'+this.data.mountpointtext
		});
		unMount(m);
	}
	else{
		unMount(d.data.mountpointtext);
	}
	
}


function unMount(m){
	$("#waiting").show();
		$.ajax({
			url: window.top.remoteDataUrl+"nas/umount/partition"
			,cache:false
			,data:'static=yes&hash='+window.top.SessionID+m
			,type: "POST"
			,dataType:"xml"
			,success: function(data){
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return; 
				loadData();

				// FIX: reload MyNAS window if it is displayed
				if (window.top.MyNAS) {
					if (window.top.MyNAS.mainWin.WIN.style.display=='block')
						window.top.loadApp('MyNAS');
				} // if (window.top.MyNAS)
			}
			,error:function(data){
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}
			//,timeout:20000
			
		});
}
