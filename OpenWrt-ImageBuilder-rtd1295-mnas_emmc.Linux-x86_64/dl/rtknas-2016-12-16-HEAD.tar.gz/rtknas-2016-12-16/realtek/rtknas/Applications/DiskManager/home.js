﻿$(function(){
	window.App="DiskManager";
	layout();
	loadLang();
	loadData();
	bindEvent();

});


function layout(){
	$('body').layout({ 
			center__paneSelector:"#main"
		,	west__paneSelector:"#left" 
		,	west__size:200
		,	west__spacing_open:0
		,	south__paneSelector:"#bottom" 
		,	south__size:60
		,	south__spacing_open:0
		,	contentSelector:".data"
		//,	center__onresize_end: function(){ $(window).resize();}
	}); 
}
	

function bindEvent(){
	$("#MOUNT").click(function(){	mountPartition();	});
	$("#REFRESH").click(function(){	loadData();	});
	$("#DiskManager").click(function(){	showManager();	});
}

function loadData(){
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/devices"
		,cache:false
		,data:{
			hash:window.top.SessionID
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}
		,error:function(data){
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
	});
}


function parseData(data, node){
	window.noswap=true;
	if(node)node=$(node).attr('path');

	$("#devicelist").html('<ul class="disklist"></ul>');
	window.$TREE=$("#devicelist ul");
	window.$TREE.treeview({collapsed:false});
	if($('device',data).length===0){
		$('#MOUNT').hide();
		$("#devicelist ul").html('No disks available.');
		return;
	}
	$('#MOUNT').show();
	$('device',data).each(function(){
		if($('length:first',this).text()!='0'){
			var li=document.createElement("li");
			var a=document.createElement("a");
			a.data={		
				path:$(this).children('path').text()
				,serial:$(this).children('serial').text()
				,model:$(this).children('model').text()
				,connectiontype:$(this).children('connectiontype').text()
				,cylinder:$(this).children('cylinder').text()-0
				,head:$(this).children('head').text()-0
				,sector:$(this).children('sector').text()-0
				,length:$(this).children('length').text()-0
				,sectorsize:$(this).children('sectorsize').text()-0
				,partitions:$(this).children('partition')
				,raid:$(this).children('raid')
				,start:0
				,raidmember:$(this).children('raidmember').text()
				,type:$(this).children('type').text()
			};
			a.data.size=a.data.length*a.data.sectorsize;
			a.innerHTML=a.data.model; 
			a.className="device";
			if(a.data.raidmember!=='')$(a).addClass('raidpart');
			a.setAttribute('path',a.data.path)
			var ul=document.createElement("ul");
			var eul=document.createElement("ul");
			
			var l=a.data.length;
			var ps=a.data.partitions;
			
			
			for(var i=0;i<ps.length;i++){
				var p=$(ps[i])
				var data={		
					path:$('path',p).text()
					,available:$('available',p).text()
					,used:$('used',p).text()
					,usedpercent:$('usedpercent',p).text()
					,label:$('label',p).text()
					,mountpoint:$('mountpoint',p)
					,mountpointtext:[]
					,start:$('start',p).text()-0
					,end:$('end',p).text()-0
					,length:$('length',p).text()-0
					,type:$('type',p).text()
					,flags:$('flags',p).text()
					,fs:$('fs',p).text()
					,raidmember:$('raidmember',p).text()
					,device:a
				};

				if(data.fs==='')continue;

				if(data.type==='extended'){
					var extended_start=data.start;
					var extended_end=data.end;					
				}
				
				data.size=data.length*data.device.data.sectorsize;
				var pli=document.createElement("li");
				var pa=document.createElement("a");
				pa.data=data;
				pa.innerHTML= ((pa.data.label=="")?pa.data.path : pa.data.label) 
				//if(data.type==='extended')pa.innerHTML='<label domain="l10n" msgid="DiskManager_text_extended>'+$.l10n.__('DiskManager_text_extended')+'</label>';
				if(data.type==='extended')pa.innerHTML='Extended Partitions';
				else pa.innerHTML +=  ' [' + formatBytes(data.size) +']';
				pa.setAttribute('path',data.path)
				$(pa).addClass(data.type);
				if(data.mountpoint.length>0){
					$(pa).addClass('mounted');
					$(pa.data.device).addClass('hasmounted');
					$(data.mountpoint).each(function(){
						if($(this).text()==='/home'){$('#MOUNT').hide();};
						data.mountpointtext .push( $(this).text() );
					});
					pa.innerHTML +=  ' <b class="special">[' + data.mountpointtext.join(',') +']</b>';
				}
				if(data.fs==='swap'&&data.mountpointtext!=='')window.noswap=false;
				if(data.fs!=='')$(pa).addClass('formatted');
				if(data.raidmember!==''){
					$(pa).addClass('raidpart');
					$(a).addClass('hasraidmember');
				}
				if(a.data.raid.children().length>0)$(pa).addClass('raidpartition');
				if(data.type==='logic'){					
					if(data.fs!==''&&data.fs!=='swap')$(pli).append(pa).appendTo(eul);
				}
				else{
					if(data.fs!==''&&data.fs!=='swap')$(pli).append(pa).appendTo(ul);	
				}
				
				if(data.type==='extended'){
					$(pa).after(eul);
				}
		}
		
			
			
		a.partitions=ul;		
		$(li).append(a).append(ul).appendTo(window.$TREE);
		
	
		if(a.data.raid.children().length>0){
			$(a).addClass('raiddevice');
			if($('syncpercent',a.data.raid).length>0)$(a).append(' <span>[Rebuilding:'+$('syncpercent',a.data.raid).text()+']</span>')
			if(a.data.partitions.length>0)$(a).addClass('hasraidpartitions');				
		}
		window.$TREE.treeview({add:$(li)});
		
	}		
	
		
	});
	
	

	$('a',window.$TREE).click(function(){
		$('a.selected',window.$TREE).removeClass('selected');
		$(this).addClass('selected'); 
	});
	
	
	if(node){
		$('a[path='+node+']',window.$TREE).click();
	}
	else{
		$('a.device:first',window.$TREE).click();
	}
	
}



function mountPartition(){
	$("#waiting").show();
	toEject();
	var p=$("ul a.selected",window.$TREE)[0];
	if(!p)return;
	$.ajax({
		url: window.top.remoteDataUrl+"nas/mount/partition"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,path:p.data.path
			,mountpoint: 'home'
			,static:'yes'
		}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return; 			
			loadData();
			window.top.loadNASinfo();
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000		
	});
}


function toEject(){
	var $d=($('a.selected',window.$TREE));
	if($d.length===0)return;
	var d=$d[0];
	if(d.data.mountpointtext.length===0)return;
	if($d.hasClass('device')){
		var $p=$('ul li a',$d.parent());
		var m='';
		$p.each(function(){
			m += '&mountpoint='+this.data.mountpointtext.join('&mountpoint=');//
		});
		unMount(m);
	}
	else{
		unMount('&mountpoint='+d.data.mountpointtext.join('&mountpoint='));
	}
	
}


function unMount(m){
	$.ajax({
		url: window.top.remoteDataUrl+"nas/umount/partition"
		,cache:false
		,data:'static=yes&hash='+window.top.SessionID+m
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
		}
		,error:function(data){
		}
		//,timeout:20000		
	});
}


function showManager(){
	var _top=window.top;
	window.top.loadApp('DiskManager',function(){ window.top.DiskManager.main();})
	window.setTimeout(function(){window.win.closeWin();},500);
}