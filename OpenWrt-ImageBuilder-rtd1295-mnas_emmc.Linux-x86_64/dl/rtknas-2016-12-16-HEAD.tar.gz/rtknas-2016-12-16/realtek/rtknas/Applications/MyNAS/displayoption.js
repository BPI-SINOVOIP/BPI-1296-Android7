﻿$(function(){	
	window.App="MyNAS";
	bindEvent();
	loadLang();
	loadData();
});


function bindEvent(){
	$("#CANCEL").click(function(){		
		window.win.closeWin();
	});
	$("#APPLY,#check").click(toApply);
	$("#RESET").click(toReset);
}

function loadData(){
	window.xml=window.top.System.FolderConfig;
	window.json=window.top.System.FolderConfigJson;
	window.node=window.win.fromWinObject.node;
	window.nodexml=window.node.folderConfigXml;
	window.nodejson=window.node.folderConfigJson;
	if(window.json.global==='true'){
		window.x=window.xml;
		window.j=window.json;
		$('#check').attr('checked','checked');
	}else{
		window.x=window.nodexml;
		window.j=window.nodejson;
		$('#check').removeAttr('checked');
	}
	$('#size').text(window.j.size);
	$('#grid').text(window.j.grid);
	$('#text').text(window.j.text);

	$('#iconsize').slider('destory').slider({
		value:window.j.size,
		min: 48,
		max: 256,
		step: 4,
		slide: function( event, ui ) {
			$('#size').text(ui.value);
			toChange();
		},
		stop: function( event, ui ) {
			toApply();
		}
	});
	$('#gridsize').slider('destory').slider({
		value:window.j.grid,
		min: 0,
		max: 48,
		step: 1,
		slide: function( event, ui ) {
			$('#grid').text(ui.value);
			toChange();
		},
		stop: function( event, ui ) {
			toApply();
		}
	});
	$('#textsize').slider('destory').slider({
		value:window.j.text,
		min: 11,
		max: 22,
		step: 1,
		slide: function( event, ui ) {
			$('#text').text(ui.value);
			toChange();
		},
		stop: function( event, ui ) {
			toApply();
		}
	});
}






function toChange(){
	var fn=window.win.fromWinObject.change; 
	fn({
		size:$('#size').text()
		,grid:$('#grid').text()
		,text:$('#text').text()
		,global:$('#check').is(':checked')+''
	});
}





function toApply(){
	window.top.System.FolderConfigJson.global=$('#check').is(':checked')+'';
	window.win.fromWinObject.save();
}



function toReset(){
	var path=window.node.path;
	var url=path+'.folder.conf';
	if(path==='/dav/home/.trash/')url='/dav/home/.folder.trash.conf';
	if(path==='/Configuration/System/applications.xml')url='/dav/home/.folder.application.conf';

	window.top.webdav.DELETE({}, url , {});
	window.top.webdav.DELETE({}, '/dav/home/.folder.conf.xml' , {});
	window.top.System.loadFolderConfig(toDefault);
}


function toDefault(){
	window.top.MyNAS.loadFolderConfig(window.node, function(){loadData(); toChange();});
	//window.win.closeWin();
}