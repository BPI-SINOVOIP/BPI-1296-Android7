﻿$(function(){
	window.App="MyNAS";
	layout();
	bindEvent();
	loadLang();
	window.top.loadNASregister();
	loadData();	
});



function layout(){
	$('body').show().layout({ 
			center__paneSelector:"#main"
		,	north__paneSelector:"#top"  
		,	north__size:40
		,	north__spacing_open:0
		,	south__paneSelector:"#bottom"  
		,	south__size:80
		,	south__spacing_open:0
		,	contentSelector:".data"
		//,	center__onresize_end: function(){ $(window).resize(); }
	}); 
	$("#expiredate").datepicker({ dateFormat: 'yymmdd' });
}



function bindEvent(){
	$("#GENERATE").click(toGenerate);
	$("#ADVANCED").click(showAdvanced);
	$("#CANCEL").click(function(){window.win.closeWin();});
	$("#ADDITEM").click(toAdd);
	$("#CLOSE").click(function(){ $('#dialog').hide(); });
	$("#receiver").click(function(){window.top.System.addReceiver({app:window.win.fromWinObject.app||window.top.MyNAS, data:'email,phone', fn:addReceiver});})	
}


function showAdvanced(){
	var st=new Date(window.top.Dean.OS.Desktop.getSystemDateTime());
	st.setDate(st.getDate()+30);
	$("#expiredate").val(window.top.dateTimeToString(st,'YYYYMMDD'));
	$('#sharename').val('');
	$('input[name="previlige"]').removeAttr('checked','checked');
	$('input[name="previlige"]:first').attr('checked','checked');
	$('#dialog').show();
}



function noSend(){
	if($("#everyone").is(':checked')){
		$('#sharename').val('everyone').attr('disabled','disabled');
		$('#receiver,#senderTR, #subjectTR,#contentTR').hide();
	}else{
		$('#sharename').val('').removeAttr('disabled');
		$('#receiver,#senderTR, #subjectTR,#contentTR').show();		
	}
}


function loadData(){
	var path=window.win.fromWinObject.path; 
	$("#path")[0].path=path;
	try {var p=decodeURIComponent(path);}
	catch(e){var p=path;}	
	$("#path").val(p);
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/publish"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,path:path
			,guest:''
			,expire:'0'
			,rw:''
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}

function parseData(data){
	$('#all table').remove();
	$('#basic').show();
	//var dl=window.top.location.protocol+"//"+window.top.NASinfo.registername+'.'+$.l10n.__('global_link_domainname');
	var dl=window.top.location.protocol+"//"+window.top.NASinfo.registername;
	var everyone=false;
	$('record',data).each(function(){
		var uuid=$('uuid',this).text();				   
		var rw=$('rw',this).text();
		var guest=$('guest',this).text();
		var expiredate=$('expire',this).text();
		var link=dl+'/publish.html?uuid='+uuid+'&lang='+window.top.Lang;
		if(guest != 'everyone') link += '&user='+guest;
		var path='<a href="'+link+'" target="_blank" class="link">'+link+'</a>';
		var emailpath='<a href="'+link+'" target="_blank" class="link">'+getDisplayNameFromPath($("#path").text(),true)+'</a>';
		var $table=$('#basic table').clone();
		$('#all').append($table);
		$('.url',$table).html(path);
		$('.shareto',$table).html(guest);
		$('.expiredate label',$table).html(expiredate);
		$('.expiredate input',$table).val(expiredate);
		$('input',$table).attr('name',uuid);
		$('.previlige *',$table).show();
		$('.operations *',$table).show();
		var $readonly=$('.previlige input:first',$table);
		var $readwrite=$('.previlige input:last',$table);
		if(rw==='yes'){
			$readwrite.attr('checked','checked');
		}else{
			$readonly.attr('checked','checked');
		}
		$('.back, .ok',$table).hide();
		$('.edit,.remove',$table).show();
		$('.edit',$table).unbind('click').click(function(){
			if(window.editStatus)return;
			window.editStatus=true;
			$('.remove, .edit',$table).hide();
			$('.back, .ok',$table).show();
			$('.expiredate label',$table).hide();
			$('.expiredate input',$table).show();
			$('input',$table).removeAttr('disabled');
			$('.expiredate input',$table).datepicker({ dateFormat: 'yymmdd'});
		});
		$('.remove',$table).unbind('click').click(function(){
			window.editStatus=false;
			toDelete($table);
		});
		$('.back',$table).unbind('click').click(function(){
			window.editStatus=false;
			$('.remove, .edit',$table).show();
			$('.back, .ok',$table).hide();
			$('.expiredate label',$table).show();
			$('.expiredate input',$table).hide();
			$('.expiredate input',$table).val($('.expiredate label',$table).text());
			$('input',$table).attr('disabled','disabled');
			if(rw==='yes'){
				$readwrite.attr('checked','checked');
			}else{
				$readonly.attr('checked','checked');
			}
			$('.expiredate input',$table).datepicker('destroy');
		});
		$('.ok',$table).unbind('click').click(function(){
			window.editStatus=false;
			toSave($table);
			$('.back',$table).click();
		});
		/*$('.copy',$table).click(function(){
			$.clipboard( link );
		});*/
		var receiver=$('.shareto',$table).text().split(','),emailto=[],smsto=[];
		for(var i=0;i<receiver.length;i++){
			if(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i.test(receiver[i]))emailto.push(receiver[i]);
			if(/^\d+$/.test(receiver[i]))smsto.push(receiver[i]);
		}
		$('.email',$table).click(function(){
			window.top.System.sendEmail({email: emailto.join(','), content:emailpath});
		});
		if(window.top.Lang!=='zh-tw')$('.sms',$table).hide();
		else $('.sms',$table).show();
		$('.sms',$table).click(function(){
			window.top.System.sendSMS({email: smsto.join(','), content:emailpath});
		});
		if(guest==='everyone'){
			$('#all').prepend($table);
			$('#basic').hide();
			$('#GENERATE').hide();
			everyone=true;
		}
	});

	if($('record',data).length===0||!everyone){
		$('#basic').hide();
		var $table=$('#basic table');
		$('.url',$table).html('');
		$('.shareto',$table).html('');
		$('.previlige *',$table).removeAttr('checked').hide();
		$('.expiredate label',$table).html('');
		$('.expiredate input',$table).val('');
		$('.operations *',$table).hide();
		$('#GENERATE').show();
	}
}


function toGenerate(){ 
	var st=new Date(window.top.Dean.OS.Desktop.getSystemDateTime());
	st.setDate(st.getDate()+30);
	var data={
		hash:window.top.SessionID
		,path:$("#path")[0].path
		,guest:'everyone'
		,expire:window.top.dateTimeToString(st,'YYYYMMDD')
		,rw:'no'
	}
	var novalidate=true;
	toAdd(data,novalidate);
}


function toAdd(data,novalidate){
	if(!data)data={};
	if(!data.hash)data={};
	data=$.extend({
		hash:window.top.SessionID
		,path:$("#path")[0].path
		,guest:$("#sharename").val()
		,expire:$("#expiredate").val()
		,rw:$("input[name='previlige']:checked").val()
	},data);
	if(data.path==='/'||data.path==='.')return;
	if(!novalidate&&!toValidate())return;
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/publish"
		,cache:false
		,data:data
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
			$('#dialog').hide();
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});		
			
}




function toSave($table){
	var expire=$('.expiredate input',$table).val();
	if(!toValidadeExpire(expire))return;
	var data={
		hash:window.top.SessionID
		,path:$("#path")[0].path
		,guest:$('.shareto',$table).text()
		,expire:expire
		,rw:$(".previlige input:checked",$table).val()
	};
	if(data.path==='/'||data.path==='.')return;
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/publish"
		,cache:false
		,data:data
		,type: "POST"
		,dataTpe:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});	
}



function toDelete($table){
	if(!confirm($.l10n.__('MyNAS_share_alert_delshare'))) return;	
	var data={
		hash:window.top.SessionID
		,path:$("#path")[0].path
		,guest:$('.shareto',$table).text()
		,expire:'0'
		,rw:''
	};
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/publish"
		,cache:false
		,data:data
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			parseData(data);
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});				
}


function addReceiver(r){	
	var v=$("#sharename").val();
	$("#sharename").val(  v + ( (/,$/.test(v)||v==='')?'':',') + r.join(',') );
}


function toValidate(){	
	if(!toValidadeExpire($('#expiredate').val()))return false;
	var fields = [
		{
			method : 'required',
			value : $('#sharename').val(), 
			element : $('#sharename')[0],
			param : null, 
			errParam : $.l10n.__('MyNAS_share_text_shareto')
		}
		,{
			method : 'required',
			value : $('#expiredate').val(), 
			element : $('#expiredate')[0],
			param : null, 
			errParam : $.l10n.__('MyNAS_share_text_expire')
		}
	];
	return validateFields(fields);
}

function toValidadeExpire(v){
	var st=window.top.Dean.OS.Desktop.getSystemDateTime();
	var t=[v.slice(0,4),v.slice(4,6),v.slice(6,8)];
	t=t.join('/'); 
	t=new Date(t);
	if(t<=st){
		alert($.l10n.__('MyNAS_share_alert_expire'));
		return false;
	}
	return true;
}


function toRefresh(){
	if(window.win.fromWinObject.fn) try{window.win.fromWinObject.fn.apply();}catch(e){}
}
