﻿$(function(){
	window.App="System";
	loadLang();
	loadData();
	$("#OK").click(OK);
})



function loadData(){
		window.top.$('.win.MyNASFormUploadWin, .win.MyNASGridUploadWin').each(function(){this.obj.closeWin();});
		var GearsInstalled=false;
		var GearsSupportted=false;
		var HTML5Supportted=false;
		if( ($.browser.mozilla&&$.browser.version>='1.5'&&$.browser.version<'3.7')  ||   ($.browser.msie&&$.browser.version>='6.0') ||   ($.browser.safari&&$.browser.version>='3.11')  ||  ($.browser.chrome&&$.browser.version<'12')){
			var GearsSupportted=true;
		}
		if(window.top.google && window.top.google.gears)GearsInstalled=true;
		if(window.top.FileReader||($.browser.safari&&$.browser.version>='5.0'))HTML5Supportted=true;
		if(GearsSupportted){
			if(GearsInstalled){
				$('#gears').removeAttr('disabled');		
			}
			else{
				$('#GearsSupportted').show();
			}
		}
		else{				
			$('#GearsSupporttedNot').show();
		}
		if(HTML5Supportted){
			$('#html5').removeAttr('disabled');
		}
		else{
			$('#HTML5SupporttedNot').show();
		}
		
		var c=getLoginUserCookies('uploadmethod');
		if(c){
			$('#check').attr('checked','checked');
			$("#"+c).attr('checked','checked');
		}
		else{$('#check').removeAttr('checked');}
}

function OK(){	
	window.top.$('body').unbind('drop dragover dragenter dragleave');
	try{window.top.$('body')[0].unbind();}catch(e){}
	window.top.UploadMethod=$("input[name='rd']:checked").val();
	if(window.top.UploadMethod==='gears')window.top.GEARS.loaded=null;
	if(window.top.UploadMethod==='html5')window.top.HTML5UPLOAD.loaded=null;
	if($('#check').is(':checked')){setLoginUserCookies({'uploadmethod':window.top.UploadMethod});}
	else {delLoginUserCookies('uploadmethod');} 
	if(window.win.fromWinObject){
		window.win.fromWinObject.apply();
	}
	else {
		if(window.top.uploadproxy)window.top.System.toUpload(window.top.uploadproxy.path,window.top.uploadproxy.force);
	}
	window.win.closeWin();		
}