﻿$(function(){
	window.App="MyNAS"; 
	window.paths=window.win.fromWinObject;
	layout();
	loadLang();	
	bindEvent();
});

function layout(){
	var lis=$(window.paths).clone();
	if($.browser.msie){
		var html='';
		for(var i=0,l=lis.length;i<l;i++){
			html+='<li class="'+lis[i].className+'">'+lis[i].innerHTML+'</li>';
		}
		$('#list').html(html);
	}
	else{
		$('#list').append(lis);
	}
	$('#list li').removeClass('selected');
}

function bindEvent(){
	$("#APPLY").click(isFileExist);
	$("#CANCEL").click(function(){		
		window.win.closeWin();
	});
}

function toApply(){
	if(!toValidate())return;
	var l=window.paths.length;
	var p='';
	while(l--) p += '&path='+ (window.paths[l].path); 
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/download/zip"
		,cache:false
		,data:'hash='+window.top.SessionID + p + '&name=' + encodeURIComponent($('#name').val()+'.zip') + '&encoding=' + $('#zfe').val()
		,type: "POST"
		,dataType:"xml"		
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			var l=$('location',data).text();
			$('#download').attr('href',l).show();	
			try{window.top.MyNAS.mainWin.content.$REFRESH.click();}catch(e){}
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
		
	});
}

function toValidate(){
	var fields = [
		{
			method : 'required',
			value : $('#name').val(), 
			element : $('#name')[0],
			param : null, 
			errParam : $.l10n.__('global_text_filename')
		}
	]
	
	if(!validateFields(fields)||!validateFileName($('#name').val())) return false;
	return true;	
}


function isFileExist(){
	// Check file existence on current folder - parent folder on first element
	var path=window.paths[0].path.replace(/\/[^\/]*\/?$/, '')+'/'+encodeURIComponent($('#name').val()+'.zip');
	window.top.System.isFileExist({
		path:path
		,app:window.top.MyNAS
		,fn:toApply
		,cfm:true
	});
}