﻿$(function(){
	window.App="MyNAS"; 
	bindEvent();
	loadLang();	
	loadData();
});

function bindEvent(){
	$("#CLOSE").click(function(){	window.win.closeWin();	});
	$("#REFRESH").click(function(){ window.location.reload();	});
	$("#APPLY").click(function(){ apply(); });
}

function apply(){
	var destination = document.getElementById('path').value;
	if(!validateFileName(destination)) return;
	if(decodeURI(window.win.fromWinObject.displayname) === destination) window.win.closeWin();
	var source  = window.win.fromWinObject.path.indexOf(encodeURIComponent(window.win.fromWinObject.displayname));
	source = window.win.fromWinObject.path.substr(0, source);
	destination = source+ encodeURIComponent(destination);

	window.top.MyNAS.showProgress({
		app:window.top.MyNAS
		,source:window.win.fromWinObject.path
		,newname:destination
		,targetpath:source
		,sourcepath:source
		,method:'MOVE'
	});
	window.win.closeWin();
}

function loadData(){
	var path=window.win.fromWinObject.path; 
	var type=(/\/$/.test(path))?'folder':'file';
	if(window.top.NASinfo){
	    //var dl=window.top.location.protocol+"//"+window.top.NASinfo.registername+'.'+$.l10n.__('global_link_domainname');
	    var dl=window.top.location.protocol+"//"+window.top.NASinfo.registername;
	}
	else dl=window.top.location.protocol+"//"+window.top.location.host;
	if(type==='file'){
		dl=dl+window.win.fromWinObject.visitpath;
		$('#thumbnail').attr('src',window.win.fromWinObject.thumbnail);
		getFileInfo(path);
	}
	else{
		dl=dl+decodeURI(path);		
		$('#thumbnail').attr('src',window.top.urlpath+'Applications/MyNAS/icons/folder.png');
		getFolderInfo(path);
	}
	//$('#link').html('<a href="'+dl+'" target="_blank">'+dl+'</a>');	
	$('#path').val(decodeURI(window.win.fromWinObject.displayname));
	getOriginalPath(path);	
}



function getFileInfo(path){
	if(path.indexOf('?')<0)path=path+'?session='+window.top.SessionID+'&login='+window.top.user;
	$("#waiting").show();
	$.ajax({
		url: path+"&exif"
		,type: "HEAD"
		,cache:false
		,complete:function(XMLHttpRequest, textStatus){
			$("#waiting").hide();
			var headers = XMLHttpRequest.getAllResponseHeaders().split("\n");
			var l = headers.length;
			for (var key=0;key<l;key++) {
				if (headers[key].length != 0) {
					header = headers[key].split(":");
					//if(header[0].indexOf('X-')==0)
					$('#data').append('<tr><th>'+header[0].replace('X-','')+'</th><td>'+headers[key].replace(header[0],'')+'</td></tr>');
				}
			}
		}
		//,timeout:20000
	});
}


function getFolderInfo(path){
	$("#waiting").show();
	window.top.webdav.MKCOL({}, window.top.root+'home/.trash/', {});
	var option = {
		depth: "0"
		,operation: "allprop"
	};
	var handler = {
		onSuccess: function(result){
			var prop=['D:getcontenttype','D:getcontentlength','D:creationdate','D:getlastmodified','R:write'];
			var name=['global_text_type','global_text_size','global_text_creationdate','global_text_lastmodified','global_text_property'];
			for(var i=0,l=prop.length;i<l;i++){
				$('#data').append('<tr><th domain="l10n" msgid="'+name[i]+'">'+$.l10n.__(name[i])+'</th><td>'+$('[nodeName="'+prop[i]+'"]',result.content).text()+'</td>');
			}
		}
		,onComplete: function(){
			$("#waiting").hide();
		}
	};  
	window.top.webdav.PROPFIND(handler, path, option);
}


function getOriginalPath(path){

	if(/^\/dav\/home\/\.trash\//.test(path)){
		$("#path").attr('readonly', true);
		$("#path").attr('onkeyup', null);
		var p=path.split('_');
		p=p[0];
		p=p.replace(/^\/dav\/home\/\.trash\//,'/dav/home/.trash/.');
		$.ajax({
			url: p
			,type:'GET'
			,data:{hash:window.top.SessionID}
			,dataType: "text"
			,success:function(data){
				$('#path').val(decodeURI(window.win.fromWinObject.displayname));
			}
		});
	}
}
