﻿$(function(){
	window.App="MyNAS"; 
	loadLang();	
	layout();
	var o=window.win.fromWinObject;
	if(!o.type)o.type='open';
	window.app=o.app;
	$("body").explorer({path:o.path, filetype:o.filter.split('|'), layout:'dialog',type:o.type,savename:o.savename,single:o.single});
})


function layout(){
	window.Layout=$('body').layout({ 
			center__paneSelector:"#main"
		,	north__paneSelector:"#status"
		,	north__size:32
		,	north__spacing_open:0
		,	west__paneSelector:"#left" 
		,	west__size:200
		,	west__spacing_open:0
		,	west__spacing_closed:0
		,	west__minSize:200
		,	south__paneSelector:"#bottom"  
		,	south__size:120
		,	south__spacing_open:0
		,	center__minWidth:400
		,	contentSelector:".data"
	});
}
