﻿$(function(){
	window.App="System"; 
	loadLang();	
	layout();
	bindEvent();
});

function layout(){
	window.o=window.win.fromWinObject;
	$('#path').html($('#path').html().replace('{0}',window.o.filename));
	if(window.o.tasks)$('#remind').show();
	else $('#remind').hide();
}

function bindEvent(){
	$("#REPLACE").click(toReplace);
	$("#CANCEL").click(toCancel);
	window.onbeforeunload=function(){
		if(!window.clicked){			
			setRemind('cancel');
			if(window.o.cancel)window.o.cancel();
		};
		//return true;
	};
}



function toReplace(){
	window.clicked=true;
	setRemind('replace');
	if(window.o.fn)window.o.fn();
	window.win.closeWin();
}



function toCancel(){
	window.clicked=true;
	setRemind('cancel');
	if(window.o.cancel)window.o.cancel();
	window.win.closeWin();
}


function setRemind(str){
	if(window.o.tasks){
		if($('#check').is(':checked'))window.o.tasks.remember=str;
		else window.o.tasks.remember='no';
	}

}