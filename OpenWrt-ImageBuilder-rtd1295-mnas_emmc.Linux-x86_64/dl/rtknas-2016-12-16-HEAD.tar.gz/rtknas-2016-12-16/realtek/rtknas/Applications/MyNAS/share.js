﻿$(function(){	
	window.App="MyNAS";
	layout();
	bindEvent();
	loadLang();
	loadData();
});


function layout(){
	$("#users").append("<table id='userlist'></table");
	$("#userlist").flexigrid({
		singleSelect:true
		,colModel : [
				 {display: '', name : 'check', width : 12, sortable : false, align: 'left'}
				,{display: '<label domain="l10n" msgid="global_text_username"></label>', name : 'username', width : 80, sortable : false, align: 'left'}
				,{display: '<label domain="l10n" msgid="global_text_readonly"></label>', name : 'readonly', width : 60, sortable : false, align: 'left'}
				,{display: '<label domain="l10n" msgid="global_text_readwrite"></label>', name : 'fullcontrol', width : 80, sortable : false, align: 'left'}
				]
		});
	$(window).resize();
}


function bindEvent(){
	$("#share").click(function(){
		showShare();
	});
	
	$("#APPLY").click(function(){		
		APPLY();
	});
	
	
	$("#CANCEL").click(function(){		
		window.win.closeWin();
	});
}

function loadData(){
	window.$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/get/users"
		,type: "POST"
		,cache:false
		,data: {
			hash:window.top.SessionID
			,date:new Date()
		}
		,dataType: "xml"
		,success: function(data){
			window.$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			$("name",data).each(function (){		
				var name=$(this).text();
				if(name!==window.top.user&&name!=='admin'){
					$("#userlist")[0].grid.addRow({
						id:name
						,check:"<input type='checkbox'/>"
						,username:name
						,readonly:"<input type='radio' value='readonly' name='"+name+"'/>"
						,fullcontrol:"<input type='radio' value='readwrite' checked='checked' name='"+name+"'/>"
					});
				}
			});			
			loadShare();
	}
	,error: function(data) {
		window.$("#waiting").hide();
		alert ($.l10n.__("global_alert_getdataerror")); 
	}
	//,timeout: 20000
	});
}


function loadShare(){
	var path=window.win.fromWinObject.path; 
	$("#path")[0].path=path;
	try {var p=decodeURIComponent($("#path")[0].path);}
	catch(e){var p=$("#path")[0].path;}	
	$("#path").html(p);
	var name=getDisplayNameFromPath(path);
	$("#sharename").val(name);
		
	$('#waiting').show();	
	$.ajax({
	   url: window.top.remoteDataUrl+"nas/get/folder/owner"
	   ,cache:false
	   ,type: "POST"
	   ,data: {
		   hash:window.top.SessionID
		},
	   dataType: "xml",
	   success: function(data){
			$('#waiting').hide();
			if(window.top.checkAPIError(data))return;	
			var s=[];				
			$("[nodeName='D:response']",data).each(function (){
				s.push(this);	
			});	
			var info;
			for(var i=0;i<s.length;i++){ 
				if($("[nodeName='D:href']",s[i]).text()===path){
					info=s[i];
					break;
				}
			}
			showShareinfo(info);
		},
	   error: function(data) { 			   
			$('#waiting').hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//timeout:20000
	});

}

function showShareinfo(info){
	 if(info){
		 window.isShared=true; 
		 $("#share").attr("checked",'checked');
		 var data={
			 path:$("[nodeName='D:href']",info).text()
			 ,name:$("[nodeName='D:displayname']",info).text()
			 ,users:$("[nodeName='R:sharer']",info)
		};
		var p=data.path;
		$("#sharename").val(data.name);	 	
		$(data.users).each(function (){
			var username=$(this).text();
			var privilege=$(this).attr('write');
			var $TR=$("#userlist tr#"+username);
			$("input:checkbox",$TR).attr('checked','checked');
			$("input:radio[value='"+privilege+"']", $TR).attr('checked','checked');
		});
		
	}
	else{
		window.isShared=false;		
		$("table.param input").attr("disabled","disabled");
	}
}

function showShare(){
	if($("#share").attr("checked")){
		$("table.param input").attr("disabled","");
	}
	else{
		$("table.param input").attr("disabled","disabled");
	}
}




function APPLY(){
	if(window.isShared){
		if($("#share").attr("checked")){
			if(!toValidate())return;
			toEdit();
		}
		else{
			toDelete();
		}
	}
	else{
		if($("#share").attr("checked")){
			if(!toValidate())return;
			toAdd();
		}
		else{
			window.win.closeWin();
		}
	}
}






function toAdd(){
	$("#waiting").show();	
	var path=$("#path")[0].path;
	$.ajax({
	   url: window.top.remoteDataUrl+"nas/add/folder"
	   ,type: "POST"
	   ,cache:false
	   ,data: 
		"hash="+ window.top.SessionID
		+"&name="+ encodeURIComponent($("#sharename").val())
		+"&path="+ path
		+window.sharers
		+window.writes
	   ,dataType: "xml"
	   ,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			window.isShared=true;
			toRefresh(path);
		}
	   ,error: function(data) { 		   
			$("#waiting").hide();
			alert ($.l10n.__("global_alert_getdataerror")); 
		}
		//timeout:20000
	});	
}



function toEdit(){
	$("#waiting").show();
	var path=$("#path")[0].path;
	$.ajax({
	   url: window.top.remoteDataUrl+"nas/edit/folder"
	   ,type: "POST"
	   ,cache:false
	   ,data: 
			"hash="+ window.top.SessionID
		   +"&name="+ encodeURIComponent($("#sharename").val())
		   +"&path="+ path
		   +window.sharers
		   +window.writes
	   ,dataType: "xml"
	   ,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;			
			toRefresh(path);
		}
	   ,error: function(data) { 		   
			$("#waiting").hide();
			alert ($.l10n.__("global_alert_getdataerror")); 
		}
		//timeout:20000
	});
}


function toDelete(){
	$("#waiting").show();	
	var path=$("#path")[0].path;
	$.ajax({
	   url: window.top.remoteDataUrl+"nas/del/folder"
	   ,type: "POST"
	   ,cache:false
	   ,data: "hash="+ window.top.SessionID+"&path="+path
	   ,dataType: "xml"
	   ,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			window.isShared=false;
			toRefresh(path);
		}
	   ,error: function(data) { 		   
			$("#waiting").hide();
			alert ($.l10n.__("global_alert_getdataerror")); 
		}
		//timeout:20000
	});
	
}



function toValidate(){
	var checkboxs=$("#userlist input:checkbox:checked");
	if(checkboxs.length==0){
		alert( $.l10n.__("MyMAS_share_alert_nouser"));
		return false;
	}
	if($("#sharename").val().replace(/\s/g,'')==''||!validateFileName($("#sharename").val())){		
		alert( $.l10n.__("global_alert_inputerror"));
		return false;
	}
	window.sharers='';
	window.writes='';
	for(var i=0;i<checkboxs.length;i++){
		var tr=checkboxs[i].parentNode.parentNode.parentNode;
		window.sharers += "&sharer="+ encodeURIComponent(tr.id);
		window.writes += "&write="+ encodeURIComponent($("input:radio:checked",tr).val());
	}
	return true;
}


function toRefresh(path){
		if(window.top.MyNAS)window.top.MyNAS.refreshWin(path);
		if(window.win.fromWinObject.fn)window.win.fromWinObject.fn.apply();
}