﻿$(function(){
	var permission=getRequest('user');
	if(!permission || 'everyone'===permission) window.root='/dav/';
	else window.root='/webdav/';

	window.top.Dean={OS:{Win:Win}};
	window.App="MyNAS";
	if(getRequest("lang"))window.Lang=getRequest("lang");
	window.urlpath=(window.location.protocol+"//"+window.location.host+window.location.pathname).replace("/Applications/MyNAS/show.html","/");	
	window.shortpath=(window.location.protocol+"//"+window.location.host+window.location.pathname).replace("/Applications/MyNAS/show.html","");
	window.remoteDataUrl='/';
	window.user=getRequest('uuid');
	window.uploadproxy={path:null,force:false};
	layout();
	bindEvent();
	loadLang();
	setLang({app:'System'});
	loadApp('System');
	loadApp('MyNAS',function(){ window.top.MyNAS.mainWin={content:document.body}; });
	loadApp('MediaPlayer',function(){  });
	loadApp('ImageViewer',function(){  });
	loadNASinfo();
});


function layout(){
	$('body').layout({ 
			center__paneSelector:"#main"
		,	north__paneSelector:"#top"  
		,	north__size:60
		,	north__spacing_open:0
		,	west__paneSelector:"#left" 
		,	west__size:200
		,	west__spacing_open:5
		,	west__spacing_closed:5
		,	west__minSize:200
		,	south__paneSelector:"#bottom"  
		,	south__size:24
		,	south__spacing_open:0
		,	center__minWidth:400
		,	contentSelector:".data"
		,	center__onresize_end: function(){ $(window).resize(); }
	}); 	
	
	window.top.webdav = new window.top.Webdav({url:''});	
	$("body").explorer();
}


function bindEvent(){		
	document.oncontextmenu=function (){return false;} 
	$(document.documentElement).keydown(function(event){
	   window.keyEvent=event;
	}).keyup(function(event){
		window.keyEvent=event;
	});
	
	$("#logo").click();	
	$("#lang").change(function(){
		loadLang(this.value);
		var url = window.top.document.URL;
		url = url.split("&lang=");
		window.top.document.location.href = url[0] + '&lang=' + this.value;
	});
	$("#lang option[value='"+window.Lang.toLowerCase()+"']").attr("selected","selected");
}


function loadNASinfo(){
	if(window.top.NASinfo){
		window.NASinfo1=window.top.NASinfo;
	}else{ 
	$("#waiting").show();
		$.ajax({
			url: window.top.remoteDataUrl+"nas/get/register"
			,cache:false
			,type: "POST"
			,dataType:"xml"
			,success: function(data){
				$("#waiting").hide();
				if(window.top.checkAPIError(data))return;
					window.NASinfo={
						registername:$('register',data).text()
					};
					window.top.document.title=window.NASinfo.registername;
				}
			,error:function(data){
				$("#waiting").hide();
			}
		});	
	}
}

function loadApp(app,fn){
	if(!window[app]){
		window[app]={setMenu:function(){}};
		window[app].onLoad=fn;
		$('body').append('<iframe src="../'+app+'/init.html" style="display:none;"></iframe>');
	}else{
		fn.apply();
	}
}
