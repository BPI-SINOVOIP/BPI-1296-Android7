﻿$(function(){
	window.App="MyNAS"; 
	loadLang();
	loadData();
});

function close(){
	window.top.MyNAS.refreshWin(window.successed);
	window.top.Dean.OS.Desktop.setTrashIcon('full');
	window.win.closeWin();
}

function loadData(){
	var o=window.win.fromWinObject;
	window.obj=o;
	window.processed=-1;
	window.successed={method:o.method, sourcepath:o.sourcepath, targetpath:o.targetpath, data:[]};
	window.complete=0;
	window.error=0;
	var s=o.source;
	var n=o.newname;
	var trashpath=window.top.root+'home/.trash/';
	if(o.method==='MOVE'&&o.targetpath===trashpath){
		window.win.close.onclick=function(){close();};
	}
	if(typeof(s)==='object'){
		window.total=s.length;
		doNext();
	}
	else{
		window.total=1;
		toDo(o.method,s,o.sourcepath,o.targetpath,n);
	}
}



function completed(){
	var trashpath=window.top.root+'home/.trash/';
	$('#completed').css({width:(window.complete/window.total*100)+'%'});
	if(window.complete>=window.total&&window.successed.data.length>=0){ 
		if(window.top.MyNAS){
			window.top.MyNAS.refreshWin(window.successed);
			if(window.obj.method==='MOVE'&&window.obj.targetpath===trashpath){
				window.top.Dean.OS.Desktop.setTrashIcon('full');
			}
		}
		if(window.error===0)window.setTimeout( function(){window.win.closeWin();}, 1000);
	}

}



function doNext(){
	var trashpath=window.top.root+'home/.trash/';
	completed();
	window.processed++;
	var o=window.obj;
	if(window.processed>=o.source.length)return;
	var s=o.source[window.processed];
	var newname;
	if(o.newname)newname=o.newname[window.processed];
	//if(!newname)newname=getDisplayNameFromPath(s,true);
	$('#path').html(decodeURIComponent(o.targetpath.replace(/^\/dav\//,'/')+getDisplayNameFromPath(s,true)));
	if((!window.remember||window.remember==='no'||window.remember==='cancel')&&(o.method==='COPY'||(o.method==='MOVE'&&o.targetpath!==trashpath))){
		var dest=toDo(o.method,s,o.sourcepath,o.targetpath,newname,overwite,true);
		if(s===dest){
			window.complete++;
			doNext();
		}else{
			window.top.System.isFileExist({
			path:dest
			,app:window.top.MyNAS
			,tasks:window
			,fn:function(){
				var overwite=true;
				toDo(o.method,s,o.sourcepath,o.targetpath,newname,overwite);
				doNext();
			}
			,cancel:function(){
				window.complete++;
				doNext();
			}
			,cfm:window.remember==='cancel'?false:true
			});
		}
	}else{
		if(!window.remember){
			toDo(o.method,s,o.sourcepath,o.targetpath);
		}
		if(window.remember==='replace'){
			var overwite=true;
			toDo(o.method,s,o.sourcepath,o.targetpath,newname,overwite)
		}
		doNext();
	}
}


function toDo(method,file,sourcepath,targetpath,newname,overwite,trying){ 
	var trashpath=window.top.root+'home/.trash/';
	var option = {
		depth: "infinity"
		,overwrite: true//overwite?true:false
		,locktoken: ''					
	};
	var handler = {
		onComplete: function(result){
			window.complete++;
			var status=result.status;
			if(status >= 200 && status < 300){
			$('#completed').css({width:(window.complete/window.total*100)+'%'});
			if(targetpath===trashpath) $('#path').html(decodeURIComponent(targetpath.replace(/^\/dav\//,'/')+getDisplayNameFromPath(file,true)));
			//$('#source').html('');
			if(window.top.MyNAS.mainWin)var E=window.top.MyNAS.mainWin.content.g;
			if(window.top.MyNAS.trashWin)var R=window.top.MyNAS.trashWin.content.g;
			if(method==='DELETE'){
				if(sourcepath===trashpath){ if(R){R.deletefile(file);} }
				else { if(E){E.deletefile(file);}}
			}else {
				if(sourcepath===targetpath){
					if(E)E.changexml(file,newname);
				}else{
					//try{((sourcepath===trashpath)?R:E).movexml(method,sourcepath,targetpath,file,newname,option.destination.replace(window.top.hostpath,'/'));}catch(e){}
				}
			}
			}
			completed();
		}
	}
	var filename=getDisplayNameFromPath(file,true);
	var fileheader=(targetpath===trashpath)?new Date().getTime()+'_':'';
	if(fileheader!==''&&method==='MOVE'){ 
		window.top.webdav.PUT({}, targetpath + '.' + fileheader.replace('_',''), {content:file,content_type:'text/plain'} );
	}

	//$('#source').html(getDisplayNameFromPath(file,true));
	if(method!=='DELETE'){
		if(newname){
			option.destination=newname;
		}else{
		if(sourcepath===trashpath){ 
			option.destination=targetpath+filename.replace(filename.split('_')[0]+'_',''); 
		}
			else if(targetpath===trashpath) {option.destination=targetpath+fileheader+filename;}
			else {option.destination=targetpath+filename;}
		}
	}
	
	if(/\/$/.test(file)){
		option.destination=option.destination+'/';
		handler.onSuccess=function(result){
			window.successed.data.push({method:method, file:file,sourcepath:sourcepath, targetpath:targetpath,newname:newname,destnation:option.destination});
			if(sourcepath===trashpath){ 
				window.top.webdav.DELETE({}, trashpath+filename.split('_')[0], {});
			}
			delShare(file);
			delPublish(file);
		};
	}else{
		var dest=option.destination;
		handler.onSuccess=function(result){
			window.successed.data.push({method:method, file:file,sourcepath:sourcepath, targetpath:targetpath,newname:newname,destnation:option.destination});
			if( sourcepath===trashpath ){
				window.top.webdav.DELETE({}, trashpath+filename.split('_')[0], {});
			}
			var tw=getThumbPath(file);
			var thumbnail=tw.thumbnail;
			var webview=tw.webview;


			if(method==='DELETE'){
				window.top.webdav.DELETE({}, thumbnail, {});
				window.top.webdav.DELETE({}, webview, {});
				if(/\/$/.test(file))delShare(file);
				delPublish(file);
				return;
			}

			var ntw=getThumbPath(dest);			
			window.top.webdav.MKCOL({}, targetpath+'.thumbnail/', {});
			window.top.webdav.MKCOL({}, targetpath+'.webview/', {});

			var nthumbnail=window.top.location.protocol+"//"+window.top.location.host+ntw.thumbnail;
			var nwebview=window.top.location.protocol+"//"+window.top.location.host+ntw.webview;

			var thumbnailoption = {
				destination:nthumbnail
				,depth: "infinity"
				,overwrite: overwite?true:false
				,locktoken: ''					
			};
			var webviewoption = {
				destination:nwebview
				,depth: "infinity"
				,overwrite: overwite?true:false
				,locktoken: ''					
			};
			if(method==='COPY'){
				window.top.webdav.COPY({}, thumbnail, thumbnailoption);
				window.top.webdav.COPY({}, webview, webviewoption);
			}
			if(method==='MOVE'){
				window.top.webdav.MOVE({}, thumbnail, thumbnailoption);
				window.top.webdav.MOVE({}, webview, webviewoption);
				delPublish(file);
			}
		};
	}
	handler.onError=function(result){
		window.error++;
		$('#result').show().append('<div class="failed">'+decodeURIComponent(filename)+'</div>');
	};
	if(trying){
		return option.destination;
	}
	if(option.destination)option.destination=window.top.location.protocol+"//"+window.top.location.host+'/'+option.destination.replace(/^\//,'');
	window.top.webdav[method](handler, file, option);
}


function delShare(path){
	$.ajax({
		url: window.top.remoteDataUrl+"nas/del/folder"
		,cache:false
		,type: "POST"
		,data: {
			hash: window.top.SessionID
			,path:path
		}
		,dataType: "xml"
	});
}


function delPublish(path){
	$.ajax({
		url: window.top.remoteDataUrl+"nas/unpublish"
		,cache:false
		,data: {
			hash: window.top.SessionID
			,path:path
		}
		,dataType: "xml"
	});
}
