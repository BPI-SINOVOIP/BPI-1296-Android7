﻿$(function(){
	window.App="MyNAS";
	loadLang();
	bindEvent();
	filearray = new Array();
});


function bindEvent(){
	window.path=window.win.fromWinObject.path;
	window.force=window.win.fromWinObject.force;
	window.fn=window.win.fromWinObject.fn;

	if(!window.path||window.path==='null'||window.path===''){
		if(window.top.MyNAS.mainWin){
			var c=window.top.MyNAS.mainWin.content;
		}
		else{
			var c=window.top.$('body')[0];
		}
		if(c.$UPLOAD&&c.$UPLOAD.hasClass('enabled'))window.top.uploadproxy.path=c.$curTreeNode[0].path;
		window.top.uploadproxy.force=false;
		window.path=window.top.uploadproxy.path;
		window.force=false;
	}

	$("#APPLY").click(function(){
		toUpload();
	});
	$("#CANCEL").click(function(){
		window.top.curWin.closeWin();
	});
	$("#DELETE").click(function(){
		var s = document.getElementById('selectedfile');
		var deleteitem = s.selectedIndex;
		s.remove(deleteitem);
		filearray.splice(deleteitem, 1);
		var clearfile = $("#file");
		clearfile.replaceWith(clearfile = clearfile.val('').clone(true));
	});
}

function toUpload(){
	if(filearray.length==0) return;

	window.top.HTML5UPLOAD.addTasks(filearray, window.path, false, null);
	try{window.top.MyNAS.refreshWin(window.path);}catch(e){}
}

function showfilename(){
	var thefile = document.getElementById('file');
	var s = document.getElementById('selectedfile');
	var new_option;
	for(var i=0;i<thefile.files.length;i++){
		if(!validateNameWithoutColon(thefile.files[i].name))return;
		new_option = new Option(thefile.files[i].name);
		s.options.add(new_option);
		filearray.push(thefile.files[i]);
	}
}

function validateNameWithoutColon(s){
	if(!s || s.length>241) {
		alert ($.l10n.__('global_validate_lengtherror'));
		return false;
	}
	if(s.replace(/\s/g,'')=="")return false;
	if(/.*[*\|\\"<>\?\/].*/.exec(s) || /^\./.exec(s) ){
	        alert ($.l10n.__('global_alert_invalidfilename') );
	        return false
	}
        return true;
}
