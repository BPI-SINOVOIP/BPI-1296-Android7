﻿$(function(){
	window.App="MyNAS"; 
	loadLang();	
	layout();
	bindEvent();
	var p=getRequest('path');
	$("body").explorer({path:p, layout:'dir'});
});




function layout(){
	window.Layout=$('body').layout({ 
			center__paneSelector:"#main"
		,	south__paneSelector:"#bottom"  
		,	south__size:80
		,	south__spacing_open:0
		,	center__minWidth:400
		,	contentSelector:".data"
	});
}


function bindEvent(){	
	$("#CANCEL").click(function(){		
		window.win.closeWin();
	});	
}