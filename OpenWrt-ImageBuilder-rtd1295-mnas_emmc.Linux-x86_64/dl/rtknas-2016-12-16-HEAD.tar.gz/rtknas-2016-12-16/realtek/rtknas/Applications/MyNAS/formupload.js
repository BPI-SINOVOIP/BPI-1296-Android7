$(function(){
	window.App="MyNAS";
	loadLang();
	bindEvent();
});


function bindEvent(){
	window.path=window.win.fromWinObject.path;
	window.force=window.win.fromWinObject.force;
	window.fn=window.win.fromWinObject.fn;

	if(!window.path||window.path==='null'||window.path===''){
		if(window.top.MyNAS.mainWin){ 
			var c=window.top.MyNAS.mainWin.content; 
		}
		else{
			var c=window.top.$('body')[0];
		}
		if(c.$UPLOAD&&c.$UPLOAD.hasClass('enabled'))window.top.uploadproxy.path=c.$curTreeNode[0].path; 
		window.top.uploadproxy.force=false;
		window.path=window.top.uploadproxy.path;
		window.force=false;
	}	

	$("#APPLY").click(function(){	
		toUpload();	
	});
	$("#OPTIONS").click(function(){	
		showOptions();	
	});
}

function toUpload(){
	var filename=$('#file').val();
	filename=filename.split('\\');
	filename=filename[filename.length-1];
	if(filename==='')return;
	window.url=window.path+encodeURIComponent(filename);
	$('#waiting').show();
	//ht 20140811 : add drop (> 2GB) files
	//---
	var input, file;
	var filesize = 0;

        // (Can't use `typeof FileReader === "function"` because apparently
        // it comes back as "object" on some browsers. So just see if it's there
        // at all.)
        if (!window.FileReader) {
        //add for IE8 & IE9, but need open ActiveX in client side first
   	        var obj = new ActiveXObject("Scripting.FileSystemObject");        
	        filesize = obj.getFile(document.getElementById('file').value).size;
	    
	        if(filesize > 2147483648) //IE 8,9 only support upload 2G
                {
		      $('#waiting').hide();
		      alert(  $.l10n.__('global_alert_systemerror').replace('{0}', 'File size:' +filesize+'.  Upload File size is over 2GB!' ) );	
		      return;
                }
        }
	else
	{
   		input = document.getElementById('file');
   		if (!input) {
		      alert(  $.l10n.__('global_alert_systemerror').replace('{0}', 'Um, could not find the fileinput element.') );
   		}
   		else if (!input.files) {
		      alert(  $.l10n.__('global_alert_systemerror').replace('{0}', 'This browser does not seem to support the "files" property of file inputs.') );
   		}
   		else if (!input.files[0]) {
		      alert(  $.l10n.__('global_alert_systemerror').replace('{0}', 'Please select a file before clicking "Load"') );
   		}
   		else {
   		      file = input.files[0];
		      filesize = file.size;
  		}
  		
  		if(filesize > 4294967295) //max length = 4G - 1
                {
   		    $('#waiting').hide();
   		    alert(  $.l10n.__('global_alert_systemerror').replace('{0}', 'File size:' +filesize+'.  Upload File size is over 4GB!' ) );	
   		    return;
                }
	}

	
	//---
	//drop file if uploaded file size is larger than storage available size
	if(filesize > window.top.availablesize){
	        $('#waiting').hide();
		alert(  $.l10n.__('global_alert_systemerror').replace('{0}', 'Upload file size is larger than storage available size') );
	        return;
	}

	if(window.force==='true'){
		doUpload();
	
	}else{
		window.top.System.isFileExist({
			path:window.url
			,app:window.top.MyNAS
			,tasks:this.tasks
			,fn:function(){	
				var overwite=true;
				doUpload();
			}
			,cancel:function(){
				$('#waiting').hide();
			}
			,cfm:true
		});
	}
	
}


function doUpload(){
	$('#form')[0].action=window.url+'?hash='+window.top.SessionID+'&streaming=false&script=true&output=json&callback=window.parent.callback';
	window.start=new Date();
	$('#form').submit();
	
}

function callback(data){
	window.end=new Date();
	$('#waiting').hide();
	if(data.status==='201'||data.status==='204'||data.status==='1223'||data.status==='200'||status==='412'){
		if(window.fn)window.fn();
		try{window.top.MyNAS.refreshWin(window.path);}catch(e){}
		window.setTimeout(function(){window.win.closeWin();},500);
	}
	else{
		alert(  $.l10n.__('global_alert_systemerror').replace('{0}', ' status='+data.status + ' wrong file format!') );		
	}
}

function showOptions(){ 	
	if(window.top.$('.win.MyNASFormUploadWin').length>1)alert($.l10n.__('MyMAS_upload_option_alert'));
	else window.top.MyNAS.showUploadOption();
}

