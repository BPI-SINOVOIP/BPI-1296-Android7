﻿$(function(){
	window.App="MediaPlayer";
	var o=(window.win)?window.win.fromWinObject:null;
	var path=getRequest('path');
	var auto=getRequest('auto');
	auto=(auto=='false')?false:true;
	if(path&&path!=='')o={path:path, auto:auto};
	//if(window.top.MediaPlayer)window.top.MediaPlayer.player({path:path,type:type});
	window.playlistindex=0;
	window.playlistfolder='/dav/home/Playlists/';
	createFolder();
	loadLang();
	loadData(o); 
});

function loadData(o){
	try{
		clearInterval(window.wmpinterval);
		clearInterval(window.realinterval);
		var player=document.getElementById('media').childNodes[0];
		if(player.controls){player.controls.stop();}
	}catch(e){}
	if(!o){
		return;
	}
	if(!o.path){
		return;
	}
	var path=o.path;
	
	if(typeof(path)==='object'){ 
		loadPaths(path);
		window.loop=false;
		return;
	}
	window.loop=true;
	play(o);
}


function play(o){
	if(!window.top.MediaPlayer){
		window.top.loadApp('MediaPlayer',function(){play(o);});
		return;
	}
	var path=o.path;
	var auto=o.auto;
	if(!path)return;
	if(typeof(auto)==='undefined')auto=true;
	path=path.split('?')[0];
	path=path.replace('download=true','').replace('&download=','').replace('&quote=true','');
	var type=o.type; 
	try{
		if(window.playlistindex>0) window.parent.$('#PLAYPREV').addClass('enabled');
		else window.parent.$('#PLAYPREV').removeClass('enabled');
		if(window.playlistindex<window.playlist.length-1)window.parent.$('#PLAYNEXT').addClass('enabled');
		else window.parent.$('#PLAYNEXT').removeClass('enabled');
	}catch(e){}
		
	var title=path.split('/');
	title=title[title.length-1];
	title=title.split('?');
	title=decodeURIComponent(title[0]);	
	try{if(window.win.app.options.id==="MediaPlayer")window.win.setTitle(title);}catch(e){}
	path=(path.indexOf('?')>-1)?path:path+'?session='+window.top.SessionID+'&login='+window.top.user;

	if(title.lastIndexOf('.')<0){
		ext="undefined";
	}
	else{
		ext=title.toLowerCase().split('.');
		ext=ext[ext.length-1];	
	}
	if(!type||type==='')type=ext;
	//if(o.ext)ext=o.ext;
	

	if (/\((iPhone|iPad|iPod|Android)/i.test(navigator.userAgent)) {
		playinbrowser(path,auto);
		return;
	}

	if(window.top.System.MediaPlayerConfig){
		var data=window.top.System.MediaPlayerConfig;
		var quicktimes=$('quicktime',data).text().split(',');
		var flashs=$('flash',data).text().split(','); 
		var mediaplayers=$('mediaplayer',data).text().split(','); 
		var realplayers=$('realplayer',data).text().split(','); 
		var browsers=$('browser',data).text().split(','); 
		var html5s=$('html5',data).text().split(','); 
		if($.inArray(ext,quicktimes)>-1){ 
			if(!hasPlugin('QuickTime'))return;
		}
		if($.inArray(ext,flashs)>-1){
			if(!hasPlugin('Shockwave Flash'))return;
		}
		if($.inArray(ext,mediaplayers)>-1){
			if(!hasPlugin('Windows Media Player','MediaPlayer.MediaPlayer.1'))return;
		}
		if($.inArray(ext,realplayers)>-1){
			if(!hasPlugin('RealPlayer','rmocx.RealPlayer G2 Control'))return;
		}
		if($.inArray(ext,quicktimes)>-1||$.inArray(ext,flashs)>-1||$.inArray(ext,mediaplayers)>-1||$.inArray(ext,realplayers)>-1){
			$('body').empty().html('<a href="'+path+'" id="media"></a><div id="title">'+title+'</div>');
			$('#title').fadeOut(5000); 	
			$("#media").media({					  
				params: { 
					//src:path
					width: "100%"				
					,height: "100%"
					,controls:"imagewindow,controlpanel"
					,center:false
					,maintainaspect:true
					,scale:"ASPECT"
					,nojava:true
					,showcontrols:true
					,bgcolor:"#000000"
					,kioskmode:true
					,autosize:false
					,displaysize:"4"
					,stretchtofit:true
					,allowfullscreen:true
					,allowscript:true
					,autostart:auto
					,autoplay:auto
					,enablejavascript:true
					,loop:((window.loop)?'true':'false')
					,postdomevents:'true'
					,flashvars:'autostart='+auto+'&logo.hide=true'
				}
			});
			window.setTimeout(function(){
				var player=document.getElementById('media').childNodes[0];
				qtListener(player, 'qt_ended', playnext, false);
				wmpListener(player, playnext );
				realListener(player, playnext);
			},500);	
		}
		else if($.inArray(ext,browsers)>-1){
			playinbrowser(path,auto);
			
		}
		else if($.inArray(ext,html5s)>-1){
			$('body').html('<video id="player" width="100%" height="100%" controls autoplay="'+auto+'"><source src="'+path+'"></source></video>');	
			var p=document.getElementById('player');
			p.addEventListener('ended',playnext, false);
		}
		else {
			playinbrowser(path,auto);
			
		}
	
	}else{
		playinbrowser(path,auto);
	}
	if(window.top.webdav&&window.top.SessionID){
		toSave(path);
	}

}

function playinbrowser(path,auto){
	//check IE
	if(window.ActiveXObject || "ActiveXObject" in window){
		if(parseFloat($.browser.version) < 9) //IE8-
			$('body').html('<iframe id="player" width="100%" height="100%" frameborder="0" src="'+path+'"></iframe>');
		else{
			//IE9+
			if(ext !== "mp4")
				window.open(path + "&download=true","_blank");
			else
				$('body').html('<video id="player" preload controls autoplay="'+auto+'" style="outline:none; position: absolute;left: 50%;top: 50%; -ms-transform: translate(-50%, -50%);"><source src="'+path+'" ></source></video>');
		}
	}
	else{
		$('body').html('<iframe id="player" width="100%" height="100%" frameborder="0" src="'+path+'"></iframe>');}
	var w=document.getElementById('player').contentWindow;
	w.onload=function(){
		var eb=w.document.getElementsByTagName('embed');
		var vd=w.document.getElementsByTagName('video');
		if(vd.length>0){vd[0].addEventListener('ended', playnext, false);}
	}	
}


function playerReady(obj) {
	player = document.getElementById('media'); 
	player.addModelListener('STATE', 'flashListener');
};


function flashListener(obj){
	if (obj["newstate"] == "COMPLETED"){
		window.setTimeout(function(){
			playnext();
		},10);
	}  
}

function playnext(){
	try{
		clearInterval(window.wmpinterval);
		clearInterval(window.realinterval);
		var player=document.getElementById('media').childNodes[0];
		if(player.controls){player.controls.stop();}
	}catch(e){}
	window.playlistindex=window.playlistindex+1;
	if(window.playlistindex>=window.playlist.length)window.playlistindex=window.playlist.length;
	if(window.playlistindex<window.playlist.length){
		play({path:window.playlist[window.playlistindex]});
	}
	
}

function playprev(){
	try{
		clearInterval(window.wmpinterval);
		clearInterval(window.realinterval);
		var player=document.getElementById('media').childNodes[0];
		if(player.controls){player.controls.stop();}
	}catch(e){}
	window.playlistindex=window.playlistindex-1; 
	if(window.playlistindex<0)window.playlistindex=0;
	if(window.playlistindex>-1){
		play({path:window.playlist[window.playlistindex]});
	}
}

function wmpListener(obj,  handler){
	window.wmpinterval=setInterval(function(){
		try{
			if(obj.playState==1){
				clearInterval(window.wmpinterval);
				handler.apply();
			}
		}catch(e){clearInterval(window.wmpinterval);}
	},500);			
}

function realListener(obj, handler){
		window.realinterval=setInterval(function(){
			try{
				if(obj.GetPlayState()==0){
					clearInterval(window.realinterval);
					handler.apply();
				}
			}catch(e){clearInterval(window.realinterval);}
		},500);	
}



function qtListener(obj, evt, handler, captures){
        if ( document.addEventListener ){
		obj.removeEventListener(evt, handler, captures);
		obj.addEventListener(evt, handler, captures);
	}
        else{
            obj.detachEvent('on' + evt, handler);
            obj.attachEvent('on' + evt, handler);
	}
}


function loadPaths(path){
	window.playlist=[];
	window.playlistindex=0;
	for(var i=0, l=path.length;i<l;i++){ 
			window.playlist.push(path[i]);
	};
	var o={
		path:window.playlist[window.playlistindex]
		,type:''
	};
	play(o);
}





function toSave(item){
	var path=window.playlistfolder+'Recent.plist'; 
	$.ajax({
		   url: path
		   ,data:{session:window.top.SessionID, login:window.top.user}
		   ,type: "GET"
		   ,cache: false
		   ,dataType: "xml"
		   ,success: function(data){
				toAddItem(path,item,data);
			}
		   ,error: function(data) {
				toAddItem(path,item)
			}
	});
}



function toAddItem(path,item,data){
	var exsit=false;
	var p=item;
	p=p.split('?')[0];

	if(data){
		$('location',data).each(function(){
			if($(this).text()===p)exsit=true;
		});
		if(exsit)return;
	}	
	var t=p.split('/');
	t=t[t.length-1];
	var track=('<track><location>' + p + '</location><creator></creator><album></album><title>' + t + '</title><annotation></annotation><duration></duration><info></info></track>');
	if(data){
		$('tracklist',data).appendXml(track);
		var xml= $(data).xml();
		if(!/^<\?xml/.test(xml))xml='<?xml version="1.0" encoding="UTF-8"?>'+xml;
	}
	else{
		xml='<?xml version="1.0" encoding="UTF-8"?><playlist version="1" xmlns="http://xspf.org/ns/0/"><tracklist>'+track+'</tracklist></playlist>';
	}
	var options = {
            content:xml
            ,content_type:  'text/xml'                 
    };
	var handler = {
		onComplete: function(result){$("#waiting").hide();}
	}; 
	window.top.webdav.PUT(handler, path, options);
	
}


function createFolder(){
	try{window.top.webdav.MKCOL({}, window.playlistfolder, {}); }catch(e){}
}



function hasPlugin(plugin,activeX){
	if (!activeX) activeX = plugin + "." + plugin;
	var f=false,n=navigator; 
	try{
		if (n.plugins && n.plugins.length){
			for (var ii=0;ii<n.plugins.length;ii++ ){
				if (n.plugins[ii].name.indexOf(plugin)!=-1){
					f=n.plugins[ii].description;
					break;
				}
			}
		}
		else if (window.ActiveXObject){
				if(plugin==='Shockwave Flash') f=new ActiveXObject("ShockwaveFlash.ShockwaveFlash.10");
				else f=new ActiveXObject(activeX); 
		}
	}catch(e){}
	if(!f){
		var a=''; 
		switch(plugin){
			case 'QuickTime':
				a='http://www.apple.com/quicktime/download/';
			break;
			case 'Shockwave Flash':
				a='http://www.adobe.com/go/getflashplayer';
			break;
			case 'Windows Media Player':
				a='http://www.microsoft.com/Windows/MediaPlayer/';
			break;
			case 'RealPlayer':
				a='http://www.real.com/player/';
			break;
		}
		a='<br/><a href="'+a+'" target="_blank">'+a+'</a>';
		$('body').html('');
		var div=document.createElement('div');
		$(div)
		.addClass('data')
		.html($.l10n.__('MediaPlayer_alert_noplugin').replace('{0}', '<b> '+plugin+' </b>'))
		.append(a)
		.appendTo($('body'));
	}
	return f;
}
