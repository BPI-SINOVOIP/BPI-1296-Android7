﻿$(function(){	 
	window.App="MediaPlayer";
	layout();
	loadLang();
	bindEvent();
	loadData();
});


function layout(){
	$('#main').html('<table id="grid"></table>');
	$('#grid').flexigrid({
		singleSelect:false
		,colModel : [
				{display: '<label domain="l10n" msgid="MediaPlayer_text_name"></label>', name : 'name', width : 150, sortable : false, align: 'left'}
				,{display: '<label domain="l10n" msgid="MediaPlayer_text_location"></label>', name : 'location', width : 300, sortable : false, align: 'left'}
				,{display: '<label domain="l10n" msgid="MediaPlayer_text_duration"></label>', name : 'duration', width : 60, sortable : false, align: 'left'}
				,{display: '<label domain="l10n" msgid="MediaPlayer_text_artist"></label>', name : 'artist', width : 100, sortable : false, align: 'left'}
				,{display: '<label domain="l10n" msgid="MediaPlayer_text_album"></label>', name : 'album', width : 100, sortable : false, align: 'left'}
				,{display: '<label domain="l10n" msgid="MediaPlayer_text_comments"></label>', name : 'comments', width : 80, sortable : false, align: 'left'}
				]
		}); 
	
	$('body').layout({ 
			center__paneSelector:"#main"
		,	north__paneSelector:"#top"  
		,	north__size:60
		,	north__spacing_open:0
		,	west__paneSelector:"#left" 
		,	west__size:200
		,	west__spacing_open:5
		,	south__paneSelector:"#bottom" 
		,	south__size:22
		,	south__spacing_open:0
		,	contentSelector:".data"
		,	center__onresize_end: function(){ $(window).resize();}//$('#grid')[0].grid.Resize(); 
	}); 
	
	$('#toolbar').toolbar();
	
	window.player=$('#player')[0].contentWindow;
	$(window).resize(function(){
		 resizePlayer();
	});
	$('#player')[0].isHidden=false;
	showPlayWindow();
}



//-----------------------------------------------------------------------------------------------------------------------
function bindEvent(){	
	var win=window.win.mask;
	window.top.$(win)
		.droppable('destroy')
		.droppable({
			accept:'#main li.media'
			,drop: function(event, ui) {
					var curWin=window.win;
					var $C;
					if(curWin.id=='App_MyNAS_Win_main')$C=window.top.MyNAS.mainWin.content.$C;
					if(curWin.id=='App_AlbumMaker_Win_main')$C=window.top.AlbumMaker.mainWin.content.$C; 
					var items=(ui.draggable.hasClass('media'))?[ui.draggable[0]]:null;
					if(ui.draggable.hasClass('selected')){
						var lis=window.top.$('li.selected.media',$C); 
						if(lis.length>0){
							items=null;
							items=lis; 
						}
					}
					if (!items)return;
					var itempaths=[]; 
					for(var i=0;i<items.length;i++){
						itempaths.push(items[i].path);
					}; 
					toAddItem(itempaths);
		}
		,hoverClass: 'drophover'
	});
	document.oncontextmenu=function (){return false;} 
	window.menu=[
			{text:"<label domain='l10n' msgid='global_menu_selectall'>"+$.l10n.__('global_menu_selectall')+"</label>", action:"toSelectAll"}
			,{text:"<label domain='l10n' msgid='global_menu_selectnone'>"+$.l10n.__('global_menu_selectnone')+"</label>", action:"toSelectNone"},{text:"|"}
			,{text:"<label domain='l10n' msgid='MediaPlayer_toolbar_playlist'>"+$.l10n.__('MediaPlayer_toolbar_play')+"</label>", action:"toPlay"}
			,{text:"<label domain='l10n' msgid='MediaPlayer_toolbar_additem'>"+$.l10n.__('MediaPlayer_toolbar_additem')+"</label>", action:"toAdd"},{text:"|"}
			,{text:"<label domain='l10n' msgid='global_button_copy'>"+$.l10n.__('global_button_copy')+"</label>", action:"toCopy"}
			,{text:"<label domain='l10n' msgid='global_button_cut'>"+$.l10n.__('global_button_cut')+"</label>", action:"toCut"}
			,{text:"<label domain='l10n' msgid='global_buttonr_paste'>"+$.l10n.__('global_button_paste')+"</label>", action:"toPaste"}
			,{text:"<label domain='l10n' msgid='global_button_delete'>"+$.l10n.__('global_button_delete')+"</label>", action:"toDelete"},{text:"|"}
			,{text:"<label domain='l10n' msgid='global_button_refresh'>"+$.l10n.__('global_button_refresh')+"</label>", action:"toRefresh"}
		];
	

	$("#REFRESH").click(function(){ toRefresh(); });
	$("#PLAYWINDOW").click(function(){ showPlayWindow();});
	$("#PLAY").click(function(){ toPlay(); });
	$("#PLAYPREV").click(function(){ toPlayPrev(); });
	$("#PLAYNEXT").click(function(){ toPlayNext(); });
	$("#ADDLIST").click(function(){ toAddList(); });
	$("#DELLIST").click(function(){ toDelList(); });
	$("#EDITLIST").click(function(){ toEditList(); });
	$("#ADD").click(function(){ toAdd(); });
	$("#COPY").click(function(){ toCopy(); });
	$("#CUT").click(function(){ toCut(); });
	$("#PASTE").click(function(){ toPaste(); });
	$("#DELETE").click(function(){ toDelete(); });	

	window.playlistfolder=window.top.root+'home/Playlists/';
}

function showPlayWindow(){
	var p=$('#player')[0];
	if(p.isHidden){
		p.isHidden=false;
		resizePlayer();
		$('#PLAY').removeClass('enabled');
		try{window.player.$('#media').css({top:0});}catch(e){}
	}
	else{
		p.isHidden=true;
		$(p).css({top:'1000%'});
		if(!$('#playlist a.selected').hasClass('ROOT'))$('#PLAY').addClass('enabled');
		try{window.player.$('#media').css({top:'1000%'});}catch(e){}
	}
	resizePlayer();
}

function resizePlayer(){
	if(!$('#player')[0].isHidden)$('#player').css({top:$('#top').height(), height:$('body').height()-$('#top').height()});
	
}

function loadData(){
		$("#waiting").show();
		var option = {
			depth: "1"
			,operation: "allprop"
				};
		var handler = {
			//onSuccess: function(result){	alert('Request SUCCEEDED with status = ' + result.status + ': ' + result.statusstring);	}
			onError: function(result){
				window.top.webdav.MKCOL({onSuccess:function(){loadData();}}, window.playlistfolder, {});
				$("#waiting").hide();
				//alert($.l10n.__('global_webdav_requestfail').replace('{0}', result.status).replace('{1}', result.statusstring))
			}
			,onSuccess: function(result){
				$("#waiting").hide();
				var data=result.content; 
				showData(data);
			}
		};
		window.top.webdav.PROPFIND(handler, window.playlistfolder, option);
}


function showData(data){
	$('#playlist').html('<ul><li><a class="ROOT" domain="l10n" msgid="MediaPlayer_text_playlistfolder">'+$.l10n.__('MediaPlayer_text_playlistfolder')+'</a><ul></ul></li></ul>');
	$('#playlist ul:first').treeview({collapsed:false});
	var ul = $('#playlist ul ul');
	$("[nodeName='D:response']",data).each(function (){
		var collection=($("[nodeName='D:collection']",this).length>0)?'dir':'file';
		if(collection=='file'){
			var path= $("[nodeName='D:href']",this).text();
			var name=getDisplayNameFromPath(path);
			if(/.*\.plist$/.test(name.toLowerCase())){
				var li = document.createElement('li');
				var a = document.createElement('a');
				//a.data={};
				var p=(name.toLowerCase()).lastIndexOf('.plist')
				a.innerHTML=name.slice(0,p);
				if(a.innerHTML=="Recent"){
					$(a).attr('domain','l10n').attr('msgid','MediaPlayer_text_recentplay');
					a.innerHTML=$.l10n.__('MediaPlayer_text_recentplay');
				}
				a.path=path;
				a.setAttribute('path',path);
				$(a).addClass("unknown");
				$(li).append(a).appendTo(ul);
			}
		}		
	});
	
	
	
	$("#playlist a").click(function(){
		$("#playlist a.selected").removeClass('selected');
		$(this).addClass('selected');
		$('#grid tr').remove();
		enableToolbar();
		if(!$(this).hasClass('ROOT')){
			if($(this).hasClass('unsave')){
				$(this).removeClass('unsave')
				Save(this);
			}else{
				if($(this).hasClass('unknown')){
					loadContent();
				}
				else{
					showContent();
				}
			}
		}
		else{
			if($(this).hasClass('unknown')){
				loadData();
			}
		}
	}).droppable({
		accept:"#grid div"
		,drop: function(event, ui){ 
			if( $(this).hasClass('ROOT') )return;	
			var items=[ui.draggable[0].parentNode.parentNode];
			if( $(items[0]).hasClass('trSelected')){
				var trs=$('#grid tr.trSelected');
				if(trs.length>0)items=trs;
			}
			if (!items)return;
			var itempaths=[];
			for(var i=0;i<items.length;i++){
					itempaths.push(items[i].path);
			}; 
			toAddItem(itempaths,$(this));
		}
	});
	
	if(window.curList){
		$("#playlist a[path="+window.playlistfolder+encodeURIComponent(window.curList)+".plist]").click();
	}
	else{
		$('#playlist a.ROOT').click();
		$("#playlist a.unknown:first").click();
	}
	
}

function enableToolbar(){
	//$('#top li').removeClass('enabled');
	$('#REFRESH,#ADDLIST,#PLAYWINDOW').addClass('enabled');
	if($('#playlist a.selected').hasClass('ROOT'))$('#DELLIST,#EDITLIST,#PLAY,#ADD').removeClass('enabled');
	else $('#DELLIST,#EDITLIST,#PLAY,#ADD').addClass('enabled');
	if($('#grid tr.trSelected').length>0)$('#COPY,#CUT,#DELETE,#PLAYSELECTED').addClass('enabled');
	else $('#COPY,#CUT,#DELETE,#PLAYSELECTED').removeClass('enabled');
	if($('#PASTE')[0].clip&&$('#PASTE')[0].clip!=$('#playlist a.selected')[0].path)$('#PASTE').addClass('enabled');
}


function loadContent(){
		$("#waiting").show();
		
		var a=$('#playlist a.selected')[0];
		var path=a.path;
		$.ajax({
		   url: path
		   ,type: "GET"
		   ,cache:false
		   ,data: {
			   login:window.top.user
			}
		   ,cache: false
		   ,dataType: "xml"
		   ,success: function(data){
				$("#waiting").hide();
				a.data=data;
				$(a).removeClass('unknown');
				showContent();
			}
		   ,error: function(data) {
				$("#waiting").hide();
				alert ( $.l10n.__("global_alert_getdataerror") );
			}
		   //,timeout: 10000
		 });
}






function showContent(){
	var data=$('#playlist a.selected')[0].data;
	var i=0;
	$("track",data).each(function (){
		i++;
		$("#grid")[0].grid.addRow({
			id:i
			,name:decodeURIComponent($('title',this).text())
			,duration:$('duration',this).text()
			,artist:$('creator',this).text()
			,album:$('album',this).text()
			,comments:$('annotation',this).text()			
			,location:decodeURI($('location',this).text())
		});
		var tr=$("#grid tr:last")[0]
		tr.path=$('location',this).text();
		tr.name=$('title',this).text();
		tr.xmlNode=this;
		
		//$('#__ContextMenu').remove();
		$("#grid tr:last").click(function(){
			enableToolbar();
		}).dblclick(function(){
			//window.top.MediaPlayer.player(this.path);
			$('#grid tr.trSelected').removeClass('trSelected');
			$(this).addClass('trSelected');
			$('#PLAY').click();
		}).contextMenu({
				menu:window.menu
				,id:"__ContextMenu"
				,callback:function(action, el, pos){
					window[action](el);
				}
		});
		$("#grid tr:last div").draggable({
			helper: 'clone'
			,appendTo: '#dragging'
			,cursor:'move'
			,revert:true
		}).droppable({
				accept:"#grid tr:last div"
				,drop: function(event, ui) {				
					var drag=ui.draggable[0].parentNode.parentNode;
					var drop=this.parentNode.parentNode;
					var trs=$('#grid tr');
					var idrag,idrop;
					for (var i=0,l=trs.length;i<l;i++){
						if(trs[i]==drag)idrag=i;
						if(trs[i]==drop)idrop=i;
						if(idrag&&idrop)break;
					}
					
					if(idrag>idrop){
						$(drop).before(drag);
						$(drop.xmlNode).before(drag.xmlNode)
					}
					else{
						$(drop).after(drag);
						$(drop.xmlNode).after(drag.xmlNode)
					}
					$(drag).addClass('trSelected');
					writeToData(data);
				}
				,hoverClass: 'drophover'
			});

									
	});	
	
	
	
}

function writeToData(data){
	var a=$('#playlist a.selected')[0];
	a.data=data;
	$(a).addClass('unsave unknown');
	Save(a);
}

function toAddItem(items,a){ 
	if(!a)a=$('#playlist a.selected');
	if(a.hasClass('ROOT'))return;
	a=a[0];
	var path=a.path;
	var data=a.data;
	if(!data)return;
	
	var l=items.length;
	while(l--){
		try{
			var p=items[l];  
			p=(p.indexOf('?')>-1)?p.split('?')[0]:p;
			$('location',a.data).each(function(){
				if($(this).text()===p){
					items.splice(l,1);
				}
			});
		}catch(e){}
	}
	
	if(items.length==0)return; 
	var l=items.length;
	while(l--){
		var p=items[l]; 
		p=(p.indexOf('?')>-1)?p.split('?')[0]:p;
		var t=p.split('/');
		t=t[t.length-1]; 
		var track='<track><location><![CDATA['+p+']]></location><creator></creator><album></album><title>'+t+'</title><annotation></annotation><duration></duration><image></image><info></info></track>';
		$('tracklist',data).appendXml(track);
	}
	a.data=data; 
	Save(a);
}


function toRefresh(){
	$('#playlist a.selected').addClass('unknown');
	$('#playlist a.selected').click();
}


function toAdd(){
	if(!$("#ADD").hasClass('enabled'))return;
	window.top.System.opendialog({
		app:window.top.MediaPlayer
		,filter:'media'
		,handler:toAddItem
	});
}


function toAddList(name){
	if(!$('#ADDLIST').hasClass('enabled'))return;
	if(!name) name=prompt( $.l10n.__("MediaPlayer_toolbar_addlist"),$.l10n.__("MediaPlayer_text_newlist"));
	if(!name||name=="")return;
	name=name.replace(/(^\s*)|(\s*$)/g, '');
	if(!validateFileName(name))return;
	var a=$('#playlist a');
	var l=a.length;
	var path= window.playlistfolder+encodeURIComponent(name) +'.plist'
	while(l--){
		if(a[l].path==path){
			alert($.l10n.__('MediaPlayer_alert_listexsit'));
			return;
			break;
		}
	}
	$("#waiting").show();
	var options = {
            content: '<?xml version="1.0" encoding="UTF-8"?><playlist version="1" xmlns="http://xspf.org/ns/0/"><tracklist></tracklist></playlist>'
            ,content_type:  'text/xml'                   
    };
	var handler = {
			//onSuccess: function(result){	alert('Request SUCCEEDED with status = ' + result.status + ': ' + result.statusstring);	}
			onError: function(result){
				$("#waiting").hide();
				//alert($.l10n.__('global_webdav_requestfail').replace('{0}', result.status).replace('{1}', result.statusstring))
			}
			,onComplete: function(result){
				$("#waiting").hide();
				window.curList=name;
				$('#playlist a.ROOT').addClass('unknown').click();
			}
		};
	window.top.webdav.PUT(handler, path, options);
	
}

function toEditList(){
	if(!$('#EDITLIST').hasClass('enabled'))return;
	var A=$('#playlist a.selected');
	var path=A[0].path;
	var name=prompt( '', A.html());
	if(!name||name=="")return;
	name=name.replace(/(^\s*)|(\s*$)/g, '');
	if(!validateFileName(name))return;	
	var a=$('#playlist a');
	var l=a.length;
	var listpath= window.playlistfolder+encodeURIComponent(name) +'.plist'
	while(l--){
		if(a[l].path==listpath){
			alert($.l10n.__('MediaPlayer_alert_listexsit'));
			return;
			break;
		}
	}
	var destination=window.top.location.protocol+"//"+window.top.location.host+window.playlistfolder+ encodeURIComponent(name) +'.plist'
	$("#waiting").show();	
	var options = {
		depth: "infinity"
		,destination: destination
		,overwrite: true						
	};
	var handler = {
			//onSuccess: function(result){	alert('Request SUCCEEDED with status = ' + result.status + ': ' + result.statusstring);	}
			onError: function(result){
				$("#waiting").hide();
				alert($.l10n.__('global_webdav_requestfail').replace('{0}', result.status).replace('{1}', result.statusstring))
			}
			,onComplete: function(result){
				$("#waiting").hide();
				window.curList=name;
				$('#playlist a.ROOT').addClass('unknown').click();
			}
		};
	window.top.webdav.MOVE(handler, path, options);
	
}



function toDelList(){
	if(!$('#DELLIST').hasClass('enabled'))return;
	if(!confirm($.l10n.__('MediaPlayer_alert_dellist')))return;
	var a=$('#playlist a.selected')[0];
	var path=a.path;
	
	$("#waiting").show();		
	var options = {
		depth: "infinity"					
	};
	var handler = {
			//onSuccess: function(result){	alert('Request SUCCEEDED with status = ' + result.status + ': ' + result.statusstring);	}
			onError: function(result){
				$("#waiting").hide();
				alert($.l10n.__('global_webdav_requestfail').replace('{0}', result.status).replace('{1}', result.statusstring))
			}
			,onComplete: function(result){
				$("#waiting").hide();
				$('#playlist a.ROOT').addClass('unknown').click();
			}
		}; 
	window.top.webdav.DELETE(handler, path, options); 
	
}

function toCopy(){
	if(!$('#COPY').hasClass('enabled'))return;
	var a=$('#playlist a.selected')[0];
	var trs=$('#grid tr.trSelected');
	var l=trs.length;
	var items=[];
	while (l--){
		var n=trs[l].xmlNode;
		items.push(n);		
	}
	$('#PASTE')[0].clip={from: a, items: items, cut: false};	
}

function toCut(){
	if(!$('#CUT').hasClass('enabled'))return;
	var a=$('#playlist a.selected')[0];
	var trs=$('#grid tr.trSelected');
	var l=trs.length;
	var items=[];
	while (l--){
		var n=trs[l].xmlNode;
		items.push(n);
		
	}
	$('#PASTE')[0].clip={from: a, items: items, cut: true};	
}

function toPaste(){
	if(!$('#PASTE').hasClass('enabled'))return;
	var a=$('#playlist a.selected')[0];
	var data=a.data;	
	var clip=$('#PASTE')[0].clip;
	var items=clip.items;
	l=items.length;
	if(l==0)return;
	var l=items.length;
	while(l--){
		var exsit=false;
		$('location',a.data).each(function(){
			if($(this).text()===$('location',items[l]).text())exsit=true;
		});
		if(!exsit)$('tracklist',a.data).appendXml($(items[l]).xml());
	}
	Save(a);
	if(clip.cut){
		$('#PASTE').removeClass('enabled');
		var a=clip.from;
		var data=a.data;
		var l=items.length;
		while(l--){
			$(items[l]).remove();
		}
		a.data=data;
		Save(a);
		$('#PASTE')[0].clip=null;
	}
}


function toDelete(){
	if(!$('#DELETE').hasClass('enabled'))return;
	if(!confirm($.l10n.__('MediaPlayer_alert_delitems')))return;
	var a=$('#playlist a.selected')[0];
	var data=a.data;
	var trs=$('#grid tr.trSelected');
	var l=trs.length;
	while (l--){
		/*var path=trs[l].path;
		$('track',data).each(function(){
			if($('location',this).text()==path)$(this).remove();
		});*/
		$(trs[l].xmlNode).remove();
		
	}
	a.data=data;
	Save(a);
}


function Save(a){
	$("#waiting").show();
	var xml=$(a.data).xml();
	if(!/^<\?xml/.test(xml))xml='<?xml version="1.0" encoding="UTF-8"?>'+xml;
	var options = {
            content: xml
            ,content_type:  'text/xml'              
	};
	var handler = {
			//onSuccess: function(result){	alert('Request SUCCEEDED with status = ' + result.status + ': ' + result.statusstring);	}
			onError: function(result){
				$("#waiting").hide();
				//alert($.l10n.__('global_webdav_requestfail').replace('{0}', result.status).replace('{1}', result.statusstring))
			}
			,onComplete: function(result){
				$("#waiting").hide();
				if(a==$('#playlist a.selected')[0])$(a).click();
			}
		};
	window.top.webdav.PUT(handler, a.path, options);
}

function toPlay(){
	if(!$('#PLAY').hasClass('enabled'))return;
	var islist=true;
	var trs=$('#grid tr.trSelected');

	if(trs.length==1){
		var rowIndex=trs.closest('tr').index();
		islist=false;
	}
	if(trs.length==0)
		trs=$('#grid tr');

	var items=[];
	if(islist){
		for(var i=0,l=trs.length;i<l;i++){
			items.push(trs[i].path);
		}
	}
	else{
		trs_list=$('#grid tr');
		for(var i=rowIndex,l=trs_list.length;i<l;i++){
			items.push(trs_list[i].path);
		}
		for(var i=0,l=trs_list.length;i<rowIndex;i++){
			items.push(trs_list[i].path);
		}
	}
	if(items.length==0)return;
	//window.top.MediaPlayer.player(items);
	showPlayWindow();
	$('#PLAY').removeClass('enabled');
	if(items.length>1)$('#PLAYNEXT').addClass('enabled');
	window.player.loadData({path:items});
}

function toPlayPrev(){
	if(!$('#PLAYPREV').hasClass('enabled'))return;
	window.player.playprev();
}
function toPlayNext(){
	if(!$('#PLAYNEXT').hasClass('enabled'))return;
	window.player.playnext();
}

function toSelectAll(){
	$('#grid tr').addClass('trSelected');
	enableToolbar();
}

function toSelectNone(){
	$('#grid tr.trSelected').removeClass('trSelected');
	enableToolbar();
}
