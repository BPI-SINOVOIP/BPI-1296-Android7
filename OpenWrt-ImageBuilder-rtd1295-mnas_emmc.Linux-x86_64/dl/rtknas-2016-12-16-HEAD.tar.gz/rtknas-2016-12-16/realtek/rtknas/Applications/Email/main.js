﻿$(function(){
	window.App="Email";
	loadLang();
	bindEvent();
	getSender();
	loadData();	
	layout();
});

function layout(){
	$('body').layout({ 
			center__paneSelector:"#main"
		,	north__paneSelector:"#top"  
		,	north__size:150
		,	north__spacing_open:0
		,	center__minWidth:400
		,	contentSelector:".data"
		,	center__onresize_end: function(){ patch(); }
	}); 
	window.editor=new TINY.editor.edit('editor',{
		id:'editor',
		width:"100%",
		height:"100%",
		cssclass:'te',
		controlclass:'tecontrol',
		rowclass:'teheader',
		dividerclass:'tedivider',
		controls:['bold','italic','underline','strikethrough','|','subscript','superscript','|',
				  'orderedlist','unorderedlist','|','outdent','indent','|','leftalign',
				  'centeralign','rightalign','blockjustify','|','unformat','|','undo','redo','n',
				  'font','size','style','|','image','hr','link','unlink','|','cut','copy','paste','print'],
		fonts:['Verdana','Arial','Georgia','Trebuchet MS'],
		xhtml:true,
		bodyid:'editorbody',
		toggle:{text:'',activetext:'',cssclass:'toggle'}
	});
	patch();
}

function bindEvent(){
	$("#APPLY").click(function(){	toSend();	});
	$("#receiver").click(function(){	window.top.System.addReceiver({fn:addReceiver,data:'email'});});
	$("#sender").change(function(){	setSender();	});
	
}
	
	
function loadData(o){
	if(!o)o=window.win.fromWinObject; 
	if(!o)return;
	if(o.email)$("#address").val(o.email);
	if(!o.path){
		writeContent();
		return;
	};
	for(var i=0;i<o.path.length;i++){
		window.top.System.toPublish({path:o.path[i].path, filename:o.path[i].displayname, guest:'Email', callback:writeContent});
	}
}


function writeContent(filename,uuid){ 	
	//var dl=window.top.location.protocol+"//"+window.top.NASinfo.registername+'.'+$.l10n.__('global_link_domainname')+'/';	
	var dl=window.top.location.protocol+"//"+window.top.NASinfo.registername+'/';
	if($("#editor").val()===''){
		var o=window.win.fromWinObject;
		var s=(o.content)?o.content:'';
		var album=dl+"album.html?author="+window.top.user;
		s += '<br/>'+ $.l10n.__("global_text_visitalbum")+" <br/><a href='"+album+"'>"+album+"</a>";
		$("#editor").val(s);
	}
	if(!filename||!uuid)return;
	var p=dl+'publish.html?uuid='+uuid; 
	var s='<a href="'+p+'" target="_blank"/>'+filename+'</a><br/>';
	s = s + $("#editor").val(); 
	$("#editor").val( s );
	window.editor.e.body.innerHTML=s;
	
};

function addReceiver(r){ 
	var v=$("#address").val();
	$("#address").val(  v + ( (/,$/.test(v)||v==='')?'':',') + r.join(',') );
}



function toSend(){ 
	if(!toValidate())return;
	$("#waiting").show();
	$.ajax({
		url: window.top.remoteDataUrl+"nas/send/email"
		,cache:false
		,data:{
			hash:window.top.SessionID
			,subject:$("#subject").val()
			,body:window.editor.e.body.innerHTML
			,sender:$('#sender').val()
			,receiver:$("#address").val()
		}
		,type: "POST"
		,dataType:"xml"		
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			alert ( $.l10n.__("Email_alert_sendok") );
		}
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
		//,timeout:20000
		
	});
}

function toValidate(){
	if($("#address").val()==""){
		alert($.l10n.__("global_alert_inputerror")+'\n'+$.l10n.__('Email_text_to'));
		$("#address").focus();
		return false;
	}
	if($("#subject").val()==""){
		alert($.l10n.__("global_alert_inputerror")+'\n:'+$.l10n.__('global_text_subject'));
		$("#subject").focus();
		return false;
	}
	return true;
}

function getSender(){
	window.top.System.getEmailInfo(function(username){
		$('#sender').val(username);
		window.top.System.getSavedEmailInfo(function(data){
			$('#sender').val($('sender',data).text());
			if($('> configuration',data).length>0)$('#sender')[0].data=data;
		});
	});
}

function setSender(){
	try{if(window.top.NASinfo.storage.writable==='no')return;}catch(e){}
	var path=window.top.root+'home/.email.conf';
	var data=$('#sender')[0].data; 
	if(!data){
		data='<?xml version="1.0" encoding="UTF-8"?><configuration><sender><![CDATA['+$('#sender').val()+']]></sender></configuration>';
	}else{
		$('sender',data).text($('#sender').val());
		data=xmlToString(data); 
	}
	var options = {
		content: data.replace(/\sxmlns=\"http:\/\/www\.w3\.org\/1999\/xhtml\"/g,'')
		,content_type:  'text/xml'                 
    };
	window.top.webdav.PUT({}, path, options);
}


function patch(){
	var h=$('div.te').height()-$('div.teheader').height()*2-4;
	$('div.te iframe').parent().height(h);
}
