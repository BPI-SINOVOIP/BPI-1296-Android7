﻿$(function(){	
	window.App="ImageViewer";
	loadLang();
	layout();
	loadData(window.win.fromWinObject);
	bindEvent(); 
});




function layout(){
	$('body').layout({ 
			center__paneSelector:"#main"
		,	north__paneSelector:"#top"  
		,	north__size:60
		,	north__spacing_open:0
		,	east__paneSelector:"#right"  
		,	east__size:185
		,	east__spacing_open:5
		,	contentSelector:".data"
	}); 
	$('#toolbar').toolbar();
	if(!window.top.Dean){
		var l=document.getElementsByTagName("link");
		for (i=0;i<l.length;i++){
			var h1=l[i].getAttribute("href");
			var h2=h1.replace('Default','Default/album');
			l[i].setAttribute("href",h2);
		}
	}
}

function loadData(o){
	window.folder=o.folder;
	var $curTreeNode=window.folder.$curTreeNode;
	$("#list").empty();
	var path=window.folder.$list; 
	if(window.slideInterval)window.clearInterval(window.slideInterval); 
	if($.browser.msie){
		$("#list").html('<ul class="iconlist">'+$(path).html()+'</ul>');
	}
	else{
		$(path).clone().appendTo($("#list"));
		$("#list ul:first")[0].className="iconlist";
	}
	$('#list li:not(.image)').remove();
	if($("#list li div.readonly").length>0||( /^\/dav\/album\//.test($("#list li").attr('path'))&&!window.top.SessionID)){$('#list').addClass('readonly');}
	$("#list li").each(function(){
		this.thumbnailimg=$('div.img img',this)[0];
		this.thumbnail=$(this).attr('thumbnail');
		$("div.img div",this).remove();	
		this.style.cssText='';	
		$('a',this)[0].style.cssText='';
		$('div.img',this)[0].style.cssText='';
		$('div.text span.name label',this)[0].style.cssText='';
		$('div.img').css({fontSize:1, lineHeight:$('div.img').height()+'px'});
	}).click(function(){
		var li=this;
		$("#list li.selected").removeClass('selected');
		$(this).addClass('selected');	
		var timg=new Image();
		this.thumbnailimg=timg;
		timg.$container=$('div.img',this);
		timg.onload=function(){
			timg.$container.html(timg);
		}
		$('div.img',this).empty().html('<img src="../../Library/blank.gif" class="loading"/>'); 
		timg.src=this.thumbnail+($(this).attr('change')?'&'+(new Date().getTime()):'');
		var img=new Image();
		this.viewimg=img;
		img.className="slideimage webview";
		img.style.cssText="opacity:0;filter:alpha(opacity=0);";
		img.$container=$("#pic");
		img.onload=function(){
			img.ow=img.width;img.oh=img.height;img.portion=img.ow/img.oh;
			img.$container.empty().append(img);
			$(img).addClass('original');
			fitImage();
		}
		$("#pic").empty().html('<img src="../../Library/blank.gif" style="width:100px;height:100px;" class="loading"/>');
		img.src=$(this).attr('webview')+'&_='+new Date().getTime();
		//img.src=$(this).attr('webview');
		img.lowsrc=$(this).attr('thumbnail');
		$(img).animate({opacity: 1},500);
		enableToolbar();
	});
	$(window).resize(function(){if($("#pic img").hasClass('original'))window.setTimeout(fitImage,250);});
	$("#list li.selected:first").click();
	try{$("#list")[0].scrollTop=$("#list li.selected:first")[0].offsetTop;}catch(e){};	
	$('#list').scroll(scrollview).scroll();
}

function fitImage(){
	var $img=$("#pic img");
	img=$img[0];
	if(!img)return;
	var mw=$('#main').width()-10, mh=$('#main').height()-10, mp=mw/mh;
	if(img.ow>mw||img.oh>mh){
		if(img.ow>mw){var ww=mw,hh=mw/img.portion;if(hh>mh){hh=mh;ww=hh*img.portion;}}
		else{var hh=mh,ww=hh*img.portion;if(ww>mw){ww=mw;hh=ww/img.portion;}}
		img.width=ww;img.height=hh;
	}
}


function enableToolbar(){
	if($("#top li.SLIDESHOW").hasClass('selected'))return;
	$("#top li.ROTATEC, #top li.ROTATECC, #top li.ZOOMOUT, #top li.ZOOMIN, #top li.SLIDESHOW, #top li.FULLVIEW").addClass('enabled');
	var $li=$("#list li.selected");
	var p=$li.prev();
	var n=$li.next();
	if(p.length==0)$("#top li.BACK").removeClass('enabled');
	else $("#top li.BACK").addClass('enabled');
	if(n.length==0)$("#top li.FORWARD").removeClass('enabled');
	else $("#top li.FORWARD").addClass('enabled');
	if($('#list').hasClass('readonly') ){
		$("#top li.ROTATEC, #top li.ROTATECC").removeClass('enabled').hide();
	}
	else{
		$("#top li.ROTATEC, #top li.ROTATECC").addClass('enabled').show();
	}
	if(window.top.App!=="System"&&window.top.App!=="MyNAS"){$("#top li.ROTATEC, #top li.ROTATECC").removeClass('enabled').hide();}
}

function bindEvent(){
	$("#top li.FULLVIEW").click(function(){
		if(!$(this).hasClass('enabled'))return;
		toView();
	});
	
	$("#top li.BACK").click(function(){
		if(!$(this).hasClass('enabled'))return;
		$("#list li.selected").prev().click();
	});
	
	
	$("#top li.FORWARD").click(function(){
		if(!$(this).hasClass('enabled'))return;
		$("#list li.selected").next().click();
	});
	
	
	
	$("#top li.ZOOMIN").click(function(){
		if(!$(this).hasClass('enabled'))return;
		toZoomIn();
	});
	
	$("#top li.ZOOMOUT").click(function(){
		if(!$(this).hasClass('enabled'))return;
		toZoomOut();
	});
	
	
	$("#top li.ROTATEC").click(function(){
		if(!$(this).hasClass('enabled'))return;
		rotateImage(-90);
		
	});
	
	$("#top li.ROTATECC").click(function(){
		if(!$(this).hasClass('enabled'))return;
		rotateImage(90);
	});
	$("#top li.SLIDESHOW").click(function(){
		$(this).toggleClass('selected');
		if($(this).hasClass('selected')){
			$("#top li").removeClass('enabled');
			window.slideInterval=window.setInterval(function(){slideShow();},6000);
		}
		else {
			window.clearInterval(window.slideInterval);
			$("#list li.selected").click();
		}
	});
}



function toZoomIn(){
		var $img=$("#pic img");
		$img.removeClass('original');
		var img=$img[0];
		if($img.hasClass('webview')&&$img.width()>=img.ow&&$img.height()>=img.oh){
			$('#waiting').show();
			img=new Image();
			
			img.onload=function(){
				$('#waiting').hide();
				$(img).width($img.width()).height($img.height());
				$(img).css({width:$img.width()*1.5, height:$img.height()*1.5});
				$('#pic').empty().append(img);	
				
			}
			//img.src=$("#list li.selected").attr('path')+'?hash='+window.top.SessionID+'&login='+window.top.user+'&_='+new Date().getTime();
			img.src=$("#list li.selected").attr('webview')+'?hash='+window.top.SessionID+'&login='+window.top.user+'&_='+new Date().getTime();
			img.className="slideimage";
			$('div.img',this).empty().html('<img src="../../Library/blank.gif" class="loading"/>'); 

		}else{
			$img.css({width:$img.width()*1.5, height:$img.height()*1.5});
		}
}

function toZoomOut(){
		var $img=$("#pic img");
		$img.removeClass('original');
		var img=$img[0];		
		var w=$img.width()/1.5;
		var h=$img.height()/1.5;
		if(w<10||h<10)return;
		$img.css({width:w, height:h});
}



function rotateImage(d){	
	var path=$("#list li.selected").attr('path');
	var $li=$("#list li.selected");
	var c=(d===90)?90:-90;	
	$("#waiting").show();
	$.ajax({
	   url: path
	   ,type: "GET"
	   ,cache:false
	   ,data: {
		   hash:window.top.SessionID
		   ,rotate:c
		   ,nocontent:''
		}
	   ,complete: function(XMLHttpRequest, textStatus){
			$("#waiting").hide();
			if(XMLHttpRequest.status===204||XMLHttpRequest.status===200||XMLHttpRequest.status===1223){
				refreshImages($li);
				
			}			
			else{
				alert($.l10n.__('ImageViewer_alert_rotateerror'));
			}
		}		
		//,timeout: 10000
	 });

}





function refreshImages($li){
	$('#waiting').show();
	var ct=window.folder.g.changefile($li.attr('path'));
	$li.attr('change',ct).click();
	$('#waiting').hide();
	window.setTimeout(function(){
		var t=$($li)[0].thumbnailimg,v=$($li)[0].viewimg;
		t.onload();
		v.onload();
	},5000);
}


function slideShow(){
	var n=$("#list li.selected").next();
	if(n.length==0)n=$("#list li:first");
	n.click();
	$("#list")[0].scrollTop=n[0].offsetTop;
}


function scrollview(){
	var $list=$('#list');
	var top=$list.scrollTop();
	var lis=$('li.unload:visible',$list);	
		var l=lis.length;
		for(var i=0;i<l;i++){ 
		var li=lis[i];
		if(li.offsetTop+li.offsetHeight>=top){
			li.thumbnailimg.src=li.thumbnail;
			$(li).removeClass('unload');
		}
		if(li.offsetTop>=$list.height()+top)break;
	}
			
}
