﻿$(function(){	
	window.App="ImageViewer";
	loadLang();
	layout();
	bindEvent(); 
	loadData();
});




function layout(){
	$('body').layout({ 
			center__paneSelector:"#main"
		,	north__paneSelector:"#top"  
		,	north__size:60
		,	north__spacing_open:0
		,	contentSelector:".data"
	}); 
	$('#toolbar').toolbar();
}

function loadData(){
	$("#pic").empty().html('<img src="../../Library/blank.gif" style="width:100px;height:100px;" class="loading"/>'); 
	var path=window.win.fromWinObject.path; 
	var img=new Image();
	img.onload=function(){
		this.ow=this.width;
		this.oh=this.height;
		$('#pic').data({width:this.width,height:this.height}).empty().append(img);
	}
	img.src=path+'?hash='+window.top.SessionID+'&webview';
	$(img).attr('path',path).addClass('webview');
	window.win.setTitle(decodeURI( path.replace(/^\/dav\//,'/') ) );
}


function bindEvent(){
	$("li",'#top').addClass('enabled');
	$("#top li.ZOOMIN").click(function(){
		if(!$(this).hasClass('enabled'))return;
		toZoomIn();
	});
	
	$("#top li.ZOOMOUT").click(function(){
		if(!$(this).hasClass('enabled'))return;
		toZoomOut();
	});
}



function toZoomIn(){
		var $img=$("#pic img");
		var img=$img[0];
		if($img.hasClass('webview')&&$img.width()>=img.ow&&$img.height()>=img.oh){
			$('#waiting').show();
			img=new Image();
			img.onload=function(){
				$('#waiting').hide();
				var w=$('#pic').data.width,h=$('#pic').data.height;
				$(img).css({width:w*1.5, height:h*1.5});
				$('#pic').data({width:w,height:h}).empty().append(img);	
				
			}
			img.src=$("#pic img").attr('path')+'?hash='+window.top.SessionID+'&login='+window.top.user+'&_='+new Date().getTime();
			img.className="slideimage";
			$('#pic').empty().html('<img src="../../Library/blank.gif" class="loading" />'); 

		}else{
			var w=$img.width()*1.5,h=$img.height()*1.5;
			$img.css({width:w, height:h});
			$('#pic').data({width:w,height:h});
		}
}

function toZoomOut(){
		var $img=$("#pic img");
		var img=$img[0];		
		var w=$img.width()/1.5;
		var h=$img.height()/1.5;
		if(w<10||h<10)return;
		$img.css({width:w, height:h});
		$('#pic').data({width:w,height:h});
}