﻿$(function(){	
	window.App="Statistic";
	loadLang();

	bindEvent(); 
	loadData();
});

var hour_cpu='yes', day_cpu='no', week_cpu='no', month_cpu='no', year_cpu='no';
var hour_load='yes', day_load='no', week_load='no', month_load='no', year_load='no';
var hour_memory='yes', day_memory='no', week_memory='no', month_memory='no', year_memory='no';
var hour_interface='yes', day_interface='no', week_interface='no', month_interface='no', year_interface='no';
var hour_temp='yes', day_temp='no', week_temp='no', month_temp='no', year_temp='no';

function bindEvent(){
	$("#APPLY").click(function(){ 
		getsetting('cpu');
		loadData_d('cpu');
		});	
	$("#REFRESH").click(function(){	refresh('cpu');	});	

	$("#lAPPLY").click(function(){	
		getsetting('load');
		loadData_d('load');
		});	
	$("#lREFRESH").click(function(){ refresh('load');	});	

	$("#mAPPLY").click(function(){	
		getsetting('memory');
		loadData_d('memory');
		});	
	$("#mREFRESH").click(function(){ refresh('memory');	});
	
	$("#iAPPLY").click(function(){	
		getsetting('interface');
		loadData_d('interface');
		});	
	$("#iREFRESH").click(function(){ refresh('interface');	});

	$("#tAPPLY").click(function(){	
		getsetting('temp');
		loadData_d('temp');
		});	
	$("#tREFRESH").click(function(){ refresh('temp');	});		
}


function getsetting(type){
     if (type == 'cpu'){
	hour_cpu = ($("#ihour").attr('checked'))?'yes':'no';
	day_cpu = ($("#iday").attr('checked'))?'yes':'no';
	week_cpu = ($("#iweek").attr('checked'))?'yes':'no';
	month_cpu = ($("#imonth").attr('checked'))?'yes':'no';
	year_cpu = ($("#iyear").attr('checked'))?'yes':'no' =='yes';
     } else if (type == 'load'){
	hour_load = ($("#ihourload").attr('checked'))?'yes':'no';
	day_load = ($("#idayload").attr('checked'))?'yes':'no';
	week_load = ($("#iweekload").attr('checked'))?'yes':'no';
	month_load = ($("#imonthload").attr('checked'))?'yes':'no';
	year_load = ($("#iyearload").attr('checked'))?'yes':'no' =='yes';
     } else if (type == 'memory'){
	hour_memory = ($("#ihourmemory").attr('checked'))?'yes':'no';
	day_memory = ($("#idaymemory").attr('checked'))?'yes':'no';
	week_memory = ($("#iweekmemory").attr('checked'))?'yes':'no';
	month_memory = ($("#imonthmemory").attr('checked'))?'yes':'no';
	year_memory = ($("#iyearmemory").attr('checked'))?'yes':'no' =='yes';
     } else if (type == 'interface'){
	hour_interface = ($("#ihourinterface").attr('checked'))?'yes':'no';
	day_interface = ($("#idayinterface").attr('checked'))?'yes':'no';
	week_interface = ($("#iweekinterface").attr('checked'))?'yes':'no';
	month_interface = ($("#imonthinterface").attr('checked'))?'yes':'no';
	year_interface = ($("#iyearinterface").attr('checked'))?'yes':'no' =='yes';
     } else if (type == 'temp'){
	hour_temp = ($("#ihourtemp").attr('checked'))?'yes':'no';
	day_temp = ($("#idaytemp").attr('checked'))?'yes':'no';
	week_temp = ($("#iweektemp").attr('checked'))?'yes':'no';
	month_temp = ($("#imonthtemp").attr('checked'))?'yes':'no';
	year_temp = ($("#iyeartemp").attr('checked'))?'yes':'no' =='yes';
     }
}

function refresh(type){
  var hour = 'no';
  var day = 'no';
  var week = 'no';
  var month = 'no';
  var year = 'no';
  var hour_refresh, day_refresh, week_refresh, month_refresh, year_refresh;
  
  if (type=='cpu') {hour_refresh = hour_cpu; day_refresh = day_cpu;week_refresh = week_cpu;month_refresh = month_cpu;year_refresh = year_cpu;  }  
  else if (type=='load') {hour_refresh = hour_load; day_refresh = day_load;week_refresh = week_load;month_refresh = month_load;year_refresh = year_load;  }   
  else if (type=='memory') {hour_refresh = hour_memory; day_refresh = day_memory;week_refresh = week_memory;month_refresh = month_memory;year_refresh = year_memory;  }   
  else if (type=='interface') {hour_refresh = hour_interface; day_refresh = day_interface;week_refresh = week_interface;month_refresh = month_interface;year_refresh = year_interface;  }   
  else if (type=='temp') {hour_refresh = hour_temp; day_refresh = day_temp;week_refresh = week_temp;month_refresh = month_temp;year_refresh = year_temp;  }  

  var type_tmp = type;
  if (type=='cpu') {type_tmp = '';}
  
  if (hour_refresh =='yes') { hour ='yes';
     if (!$("#ihour"+type_tmp).attr('checked')){$("#ihour"+type_tmp).attr('checked', 'checked');}} 
  else {($("#ihour"+type_tmp).attr('checked'))?$("#ihour"+type_tmp).removeAttr('checked'):'yes';}
  if (day_refresh =='yes') { day ='yes';
     if (!$("#iday"+type_tmp).attr('checked')){$("#iday"+type_tmp).attr('checked', 'checked');}}
  else {($("#iday"+type_tmp).attr('checked'))?$("#iday"+type_tmp).removeAttr('checked'):'yes';}
  if (week_refresh =='yes') { week ='yes';
     if (!$("#iweek"+type_tmp).attr('checked')){$("#imonth"+type_tmp).attr('checked', 'checked');}}
  else {($("#iweek"+type_tmp).attr('checked'))?$("#iweek"+type_tmp).removeAttr('checked'):'yes';}
  if (month_refresh =='yes') { month ='yes';
     if (!$("#imonth"+type_tmp).attr('checked')){$("#imonth"+type_tmp).attr('checked','checked');}}
  else {($("#imonth"+type_tmp).attr('checked'))?$("#imonth"+type_tmp).removeAttr('checked'):'yes';}
  if (year_refresh =='yes') { year ='yes';
     if (!$("#iyear"+type_tmp).attr('checked')){$("#iyear"+type_tmp).attr('checked', 'checked');}}
  else {($("#iyear"+type_tmp).attr('checked'))?$("#iyear"+type_tmp).removeAttr('checked'):'yes';}

   $("#waiting").show();
   $.ajax({
		url: window.top.remoteDataUrl+"nas/statistic/refresh"
		,cache:false
		,data:{
			hash:window.top.SessionID
                        ,hour:hour
                        ,day:day
                        ,week:week
                        ,month:month
                        ,year:year
			}
		,type: "POST"
		,dataType:"xml"
		,success: function(data){
			$("#waiting").hide();
			if(window.top.checkAPIError(data))return;
			loadData_d(type);
		}		
		,error:function(data){
			$("#waiting").hide();
			alert ( $.l10n.__("global_alert_getdataerror") );
		}
	});
}

function loadData(){
        loadData_d('cpu');
	loadData_d('load');
	loadData_d('memory');
	loadData_d('interface');
	loadData_d('temp');
}

function loadNew(path, type){
	   $.ajax({
		url: window.top.remoteDataUrl+path
		,type: "HEAD"
		,success: function(data){
			if(window.top.checkAPIError(data))return;
		}		
		,error:function(data){
			refresh(type)
		}
	});
}


function loadPng(type1, type2){
        var pad='-';
        if (type1=="cpu"){
           pad = '-0-';}
        else if (type1 == "interface"){
           pad = '-eth0-';}
        var tmp_type1 = type1;
        if (type1=="temp"){
           tmp_type1 = 'temperature';}
        var a='<img id="'+type1+type2.substr(0,1)+'" src="/statistic/'+tmp_type1+pad+type2+'.png'+'?time='+new Date()+'&session='+window.top.SessionID+'&login='+window.top.user+'"></img>';
        if (type1 =='cpu'){
					$("#"+type2+"container").html('<div style="width:350px;height:221px;margin:0 2px;display: inline-block;" id="'+type2+'containerone"></div><div style="width:350px;height:221px;margin:0 2px;display: inline-block;" id="'+type2+'containersecond"></div>');
					loadNew("statistic/"+tmp_type1+pad+type2+".png", type1);
					$("#"+type2+"containerone").html(a); 
					a = '<img id="'+type1+type2.substr(0,1)+'1'+'" src="/statistic/'+tmp_type1+'-1-'+type2+'.png'+'?time='+new Date()+'&session='+window.top.SessionID+'&login='+window.top.user+'"></img>';
					loadNew("statistic/"+tmp_type1+'-1-'+type2+".png", type1);
					$("#"+type2+"containersecond").html(a);}
         else{
                               	loadNew("statistic/"+tmp_type1+pad+type2+".png", type1);$("#"+type2+"container"+type1).html(a);}
	 
}


function loadData_d(type){
$("#waiting").show();
	var tmp_type=type;
	if (type=='cpu'){tmp_type='';}
	if ($("#ihour"+tmp_type).attr('checked')){
		loadPng(type, 'hour');
	}else {$('#hourcontainer'+tmp_type).html("");}
	if ($("#iday"+tmp_type).attr('checked')){
		loadPng(type, 'day');
	}else {$('#daycontainer'+tmp_type).html("");}
	if ($("#iweek"+tmp_type).attr('checked')){
		loadPng(type, 'week');
	}else {$('#weekcontainer'+tmp_type).html("");}
	if ($("#imonth"+tmp_type).attr('checked')){
		loadPng(type, 'month');
	}else {$('#monthcontainer'+tmp_type).html("");}
	if ($("#iyear"+tmp_type).attr('checked')){
		loadPng(type, 'year');
	}else {$('#yearcontainer'+tmp_type).html("");}
$("#waiting").hide();
}
