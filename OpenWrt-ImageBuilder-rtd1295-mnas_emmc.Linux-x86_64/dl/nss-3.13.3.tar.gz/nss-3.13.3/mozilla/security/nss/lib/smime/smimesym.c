extern void SEC_PKCS7DecodeItem();
extern void SEC_PKCS7DestroyContentInfo();

smime_CMDExports() {
	SEC_PKCS7DecodeItem();
	SEC_PKCS7DestroyContentInfo();
}

